# Changelog

All notable changes to this project will be documented in this file.

## [0.9.0](https://github.com/cloudflare/pingora/compare/0.8.0...0.9.0) - 2026-09-04

### ✨ Highlights

- Reworked connection pooling with sharded storage and a true global LRU, addressing stale entries and race windows.
- Added an upstream module system that applies before upstream compression.
- More handling of HTTP parsing and framing edge cases, including non-origin-form request-target preservation, and hop-by-hop header sanitization, obsolete line-fold normalization, stricter request-target validation, and bounded default HTTP/2 limits.
- Split Prometheus integration into the pingora-prometheus crate and made Prometheus optional.
- Improved graceful shutdown and upgrade behavior, including responsive load-balancer shutdown, descriptor lifecycle fixes, and lower shutdown-notification contention.

### ⚠️ Potential Breaking Changes

- Minimum supported Rust version moves to 1.85 for some crates. pingora-foundations declares an MSRV of 1.88.
- RequestHeader and ResponseHeader no longer implement DerefMut because unrestricted mutation could violate internal invariants.
- Removed async_write_vec APIs; consumers should use tokio::io::AsyncWriteExt::write_all_buf.
- Prometheus integration moved from pingora-core to the separate pingora-prometheus crate; Prometheus is optional.
- tracing is now optional in pingora-cache.
- Upgraded to the boring-rs 5.x API.
- PeerOptions::curve now uses Cow.
- Upstream requests strip hop-by-hop and Connection-nominated headers by default; legacy behavior requires explicit compatibility settings.
- Default HTTP/2 server limits are bounded rather than unbounded.
- Removed the unused LruShard Default implementation and lifted Default bounds on sharded cache structures.
- Removed the CacheKey namespace parameter.
- PurgeOutcome enum gains an Expired variant.
- ForcedFreshness and hit-status reporting gain ForceExpiredServeStale variant.

### 🚀 Features — Proxy & Sessions

- Add abort-on-close session configurability.
- Support HTTP/1.1 downstream request pipelining.
- Add cancel-safe body and header writer primitives (proxy tasks) to prevent stalled cache misses from applying backpressure.
- Add an upstream module system and allow modules to adjust after receiving upstream response headers.
- Add proxy warning-log suppression hooks.
- Add keepalive-pool callbacks for tracking connection ages.
- Expose HTTP/1.x request-body bytes accepted by the upstream writer.
- Report point-in-time available HTTP/2 stream capacity.

### 🚀 Features — TLS

- Add ability to configure an offload thread pool for downstream TLS handshakes.
- Add Acceptor::from_server_config for runtime-built rustls ServerConfig values and in-memory key material.
- Export TLS keying material, including from pingora-s2n.
- Add per-peer CA configuration.
- Add a pre-TLS callback for PROXY protocol support.
- Expose the rustls certificate type.
- Add curve and second-keyshare settings to HttpPeer hashing.
- Avoid compiling aws-lc-rs when the ring provider is selected.

### 🚀 Features — Server, Runtime & Load Balancing

- Allow sharing backends across load-balancing selectors.
- Add graceful-upgrade signalling between old and new processes.
- Add per-listener L4 buffer configuration and socket send/receive buffer settings.
- Add Tokio blocking-pool configuration, poll-time histograms, and an alternative timer runtime knob.
- Allow proxy services to override runtime options.
- Add a working-directory option for daemon mode.
- Enable adding user context between sessions on the same connection with HttpPersistentSettings.
- Add socket-cookie access and TCP/TLS establishment timing fields.
- Make HTTP/2 stream and connection windows configurable.

### 🚀 Features — Caching (alpha)

- Add deferred cache-admission policy hooks.
- Implement DCZ dictionary compression and vary on available-dictionary.
- Add CacheMeta freshness updates and expiration-at-time support.
- Support optionally flooring fractional delta-seconds for RFC 9111 handling.
- Preserve Vary provenance across stale refreshes.
- Make cache-lock retries configurable and bounded.
- Add an opt-in purge mode that expires an asset while retaining its body for conditional revalidation and stale serving.
- Use power-of-two selection for eviction balancing.
- Add peek_lru, update_or_admit, and non-promoting set_weight operations in lru.
- Allow adjusting LRU weight limits and reserving capacity.

### 🔒 Security & Hardening

- HTTP ambiguity hardening: centralize raw request-target classification so path and authority validation share one parser; reject ambiguous request authorities on ingress and egress; reject forbidden CR/LF bytes in HTTP/2 :path; and reject delimiter bytes in request lines as defense in depth.
- Sanitize hop-by-hop upstream request headers.
- Preserve non-origin-form request targets without mangling the URI.
- Normalize forwarded responses with obsolete HTTP/1.1 response-header line folding.
- Bound default HTTP/2 server limits to reduce memory-exhaustion exposure.
- Avoid a process abort while appending oversized header maps by returning an InvalidHTTPHeader error.
- Fix some unchecked integer conversions.
- Explicitly prevent reuse of HTTP/1 connections after incomplete responses.
- Update Prometheus for a security advisory.
- Replaced unmaintained daemonize crate with daemonix and updated nix to 0.31.x.

### 🐛 Bug Fixes

- Fix connection-pool and PoolNode race windows and remove empty entries.
- Fixed a potential stall on HTTP/1 response-header reads upon forwarding request bodies via a cancel safety fix.
- Stop waiting on HTTP/2 upstream work after the downstream ends and close timed-out HTTP/2 connections.
- Drain in-flight HTTP/2 streams during shutdown and retry stream creation on a fresh connection when appropriate.
- Prevent HTTP/1 upstream reuse after failed writes or incomplete responses.
- Discard retry buffers after truncation and avoid unnecessary HTTP/2 accept allocations.
- Skip h2c preface detection on TLS streams.
- Do not initialize a body reader for HEAD informational responses.
- Correct HTTP/1 session body-byte accounting.
- Fix listener-fd inheritance and close transfer sockets during graceful upgrade; mark received listener fds close-on-exec.
- Remove the duplicate graceful-shutdown sleep and improve load-balancer shutdown responsiveness.
- Shard proxy shutdown notifications to reduce lock contention and close a lost-wakeup race during graceful shutdown.

### ⚙️ Miscellaneous

- pingora-timeout now uses Tokio timeouts for (configurably) long intervals to avoid memory accumulation.
- Split pingora-prometheus into a separate crate.
- Forward WriteBuf::chunks_vectored to the wrapped buffer.
- Replace custom ASCII-trimming helpers with stabilized standard-library methods.
- Update the MSRV lane and use cargo check for MSRV validation.
- Improve documentation examples for connection tracing and basic setup.
- Preserve bound ports in digests after TLS failures.
- Return an error for divergent multipart cache progress and remove a panic from maybe_cache_meta.
- Various flaky test fixes.

## [0.8.0](https://github.com/cloudflare/pingora/compare/0.7.0...0.8.0) - 2026-03-02


**🚀 Features**

* Add support for client certificate verification in mTLS configuration.
* Add upstream\_write\_pending\_time to Session for upload diagnostics.
* Pipe subrequests utility: creates a state machine to treat subrequests as a "pipe," enabling direct sending of request body and writing of response tasks, with a handler for error propagation and support for reusing a preset or captured input body for chained subrequests.
* Add the ability to limit the number of times a downstream connection can be reused
* Add a system for specifying and using service-level dependencies
* Add a builder for pingora proxy service, e.g. to specify ServerOptions.

**🐛 Bug Fixes**

* Fix various Windows compiler issues.
* Handle custom ALPNs in s2n impl of ALPN::to\_wire\_protocols() to fix s2n compile issues.
* Fix: don't use “all” permissions for socket.
* Fix a bug with the ketama load balancing where configurations were not persisted after updates.
* Ensure http1 downstream session is not reused on more body bytes than expected.
* Send RST\_STREAM CANCEL on application read timeouts for h2 client.
* Start close-delimited body mode after 101 is received for WebSocket upgrades. `UpgradedBody` is now an explicit HttpTask.
* Avoid close delimit mode on http/1.0 req.
* Reject invalid content-length http/1 requests to eliminate ambiguous request framing.
* Validate invalid content-length on http/1 resp by default, and removes content-length from the response if transfer-encoding is present, per RFC.
* Correct the custom protocol code for shutdown: changed the numeric code passed on shutdown to 0 to indicate an explicit shutdown rather than a transport error.

**⚙️ Miscellaneous Tasks**

* Remove `CacheKey::default` impl, users of caching should implement `cache_key_callback` themselves
* Allow server bootstrapping to take place in the context of services with dependents and dependencies
* Don't consider "bytes=" a valid range header: added an early check for an empty/whitespace-only range-set after the `bytes=` prefix, returning 416 Range Not Satisfiable, consistent with RFC 9110 14.1.2.
* Strip {content, transfer}-encoding from 416s to mirror the behavior for 304 Not Modified responses.
* Disable CONNECT method proxying by default, with an option to enable via server options; unsupported requests will now be automatically rejected.

## [0.7.0](https://github.com/cloudflare/pingora/compare/0.6.0...0.7.0) - 2026-01-30

### Highlights

- Extensible SslDigest to save user-defined TLS context
- Add ConnectionFilter trait for early TCP connection filtering

### 🚀 Features

- Add ConnectionFilter trait for early TCP connection filtering
- Introduce a virtual L4 stream abstraction
- Add support for verify_cert and verify_hostname using rustls
- Exposes the HttpProxy struct to allow external crates to customize the proxy logic.
- Exposes a new_mtls method for creating a HttpProxy with a client_cert_key to enable mtls peers.
- Add SSLKEYLOGFILE support to rustls connector
- Allow spawning background subrequests from main session
- Allow Extensions in cache LockCore and user tracing
- Add body-bytes tracking across H1/H2 and proxy metrics
- Allow setting max_weight on MissFinishType::Appended
- Allow adding SslDigestExtensions on downstream and upstream
- Add Custom session support for encapsulated HTTP

### 🐛 Bug Fixes

- Use write timeout consistently for h2 body writes
- Prevent downstream error prior to header from canceling cache fill
- Fix debug log and new tests
- Fix size calculation for buffer capacity
- Fix cache admission on header only misses
- Fix duplicate zero-size chunk on cache hit
- Fix chunked trailer end parsing
- Lock age timeouts cause lock reacquisition
- Fix transfer fd compile error for non linux os

### Sec

- Removed atty
- Upgrade lru to >= 0.16.3 crate version because of RUSTSEC-2026-0002

### Everything Else

- Add tracing to log reason for not caching an asset on cache put
- Evict when asset count exceeds optional watermark
- Remove trailing comma from Display for HttpPeer
- Make ProxyHTTP::upstream_response_body_filter return an optional duration for rate limiting
- Restore daemonize STDOUT/STDERR when error log file is not specified
- Log task info when upstream header failed to send
- Check cache enablement to determine cache fill
- Update meta when revalidating before lock release
- Add ForceFresh status to cache hit filter
- Pass stale status to cache lock
- Bump max multipart ranges to 200
- Downgrade Expires header warn to debug log
- CI and effective msrv bump to 1.83
- Add default noop custom param to client Session
- Use static str in ErrorSource or ErrorType as_str
- Use bstr for formatting byte strings
- Tweak the implementation of and documentation of `connection_filter` feature
- Set h1.1 when proxying cacheable responses
- Add or remove accept-ranges on range header filter
- Update msrv in github ci, fixup .bleep
- Override request keepalive on process shutdown
- Add shutdown flag to proxy session
- Add ResponseHeader in pingora_http crate's prelude
- Add a configurable upgrade for pingora-ketama that reduces runtime cpu and memory
- Add to cache api spans
- Increase visibility of multirange items
- Use seek_multipart on body readers
- Log read error when reading trailers end
- Re-add the warning about cache-api volatility
- Default to close on downstream response before body finish
- Ensure idle_timeout is polled even if idle_timeout is unset so notify events are registered for h2 idle pool, filter out closed connections when retrieving from h2 in use pool.
- Add simple read test for invalid extra char in header end
- Allow customizing lock status on Custom NoCacheReasons
- Close h1 conn by default if req header unfinished
- Add configurable retries for upgrade sock connect/accept
- Deflake test by increasing write size
- Make the version restrictions on rmp and rmp-serde more strict to prevent forcing consumers to use 2024 edition
- Rewind preread bytes when parsing next H1 response
- Add epoch and epoch_override to CacheMeta

## [0.6.0](https://github.com/cloudflare/pingora/compare/0.5.0...0.6.0) - 2025-08-15

### Highlights
- This release bumps the minimum h2 crate dependency to guard against the [MadeYouReset]((https://blog.cloudflare.com/madeyoureset-an-http-2-vulnerability-thwarted-by-rapid-reset-mitigations/)) H2 attack


### 🚀 Features

- Log runtime names during Server shutdown
- Enabling tracking the execution phase of a server
- Allow using in-memory compression dicts
- Make H2Options configurable at HttpServer, HttpProxy
  Also adds HttpServerOptions to the HttpServer implementation, and
  updates the HttpEchoApp to use HttpServer for easier adhoc testing.

### 🐛 Bug Fixes

- Fix: read body without discard

### Everything Else

- Try loading each LRU shard individually and warn on errors
- Update LRU save to disk to be atomic
- Allow cache to spawn_async_purge
- Pass hit handler in hit filter
- Cache hit filter can mutate cache, allow resetting cache lock
- Persist keepalive_timeout between requests on same stream
- Properly check for H2 io ReadError retry types
- Add cache lock wait timeout for readers
- Fix CacheLock status timeout conditions
- Handle close on partial chunk head
- Allow optional to reset session timeouts
- Clippy fixes for 1.87, add 1.87 to GitHub CI
- Run `range_{header,body}_filter` after disabling cache
- Convert `InterpretCacheControl` members to `Duration`
- Disable downstream ranging on max file size
- Allow explicit infinite keepalive timeout to be respected
  Note that a necessary follow up is to refactor the infinite keepalive
  timeout to only apply to first read between requests on reused conns.
- Add method to disable keepalive if downstream is unfinished
- Discard extra upstream body and disable keepalive
- Explicitly disable keepalive on upstream connection when excess body
  (content-length) is detected.
- Add brief sleep to shutdown signal tests to avoid flake
- Allow override of cache lock timeouts
- Allow arbitrary bytes in CacheKey instead of just Strings
- Corrects out-of-order data return after multiple peek calls with different buffer sizes.
- Mark previously too large chunked assets as cacheable
- Boring/OpenSSL load cert chain from connector options
- Add initial support for multipart range requests
- Adds a callback to HttpHealthCheck for collecting detailed backend summary information
- Multipart range filter state fixes


### Docs

- Explanation of request_body_filter phase



## [0.5.0](https://github.com/cloudflare/pingora/compare/0.4.0...0.5.0) - 2025-05-09

### 🚀 Features

- [Add tweak_new_upstream_tcp_connection hook to invoke logic on new upstream TCP sockets prior to connection](https://github.com/cloudflare/pingora/commit/be4a023d18c2b061f64ad5efd0868f9498199c91)
- [Add ability to configure max retries for upstream proxy failures](https://github.com/cloudflare/pingora/commit/6c5d6021a6e67c971e835bef269655d0db94c2d1)
- [Allow tcp user timeout to be configurable](https://github.com/cloudflare/pingora/commit/e77ca63da58892281f36dcb97c51a8b1e882e2f6)
- [Add peer address to downstream handshake error logs](https://github.com/cloudflare/pingora/commit/3f9e0a2fae8feaea12a1a9687e6b4bf4616f66c5)
- [Allow proxy to set stream level downstream read timeout](https://github.com/cloudflare/pingora/commit/87ae8ce2e7883c0a924a776b193c8a4f858b9349)
- [Improve support for sending custom response headers and bodies for error messages](https://github.com/cloudflare/pingora/commit/a8a6e77eef2c0f4d2a45f00c5b0e316dd373f2f2)
- [Allow configuring multiple listener tasks per endpoint](https://github.com/cloudflare/pingora/commit/69254671148938f6bc467f6decc2fc89ee7f531e)
- [Add get_stale and get_stale_while_update for memory-cache](https://github.com/cloudflare/pingora/commit/bb28044cbe9ac9251940b8a313d970c7d15aaff6)

### 🐛 Bug Fixes

- [Fix deadloop if proxy_handle_upstream exits earlier than proxy_handle_downstream](https://github.com/cloudflare/pingora/commit/bb111aaa92b3753e650957df3a68f56b0cffc65d)
- [Check on h2 stream end if error occurred for forwarding HTTP tasks](https://github.com/cloudflare/pingora/commit/e18f41bb6ddb1d6354e824df3b91d77f3255bea2)
- [Check for content-length underflow on end of stream h2 header](https://github.com/cloudflare/pingora/commit/575d1aafd7c679a50a443701a4c55dcfdbc443b2)
- [Correctly send empty h2 data frames prior to capacity polling](https://github.com/cloudflare/pingora/commit/c54190432a2efea30c5a0187bb7d078d33570a43)
- [Signal that the response is done when body write finishes to avoid h1 downstream/h2 upstream errors](https://github.com/cloudflare/pingora/commit/5750e4279e75b1e764dcfc5530aa7a7cebe3abef)
- [Ignore h2 pipe error when finishing an H2 upstream](https://github.com/cloudflare/pingora/commit/8ad15031291eb5779e0e93e714eb969c4132f632)
- [Add finish_request_body() for HTTP healthchecks so that H2 healthchecks succeed](https://github.com/cloudflare/pingora/commit/67bc7cc170e754d335cc1d6d526f203c4345eceb)
- [Fix Windows compile errors by updating `impl<T> UniqueID` to use correct return type](https://github.com/cloudflare/pingora/commit/1756948df77d257bddf7ab798cc3fddf348a91c8)
- [Fixed compilation errors on Windows](https://github.com/cloudflare/pingora/commit/906cb90864bf6e441727083c9cbd4f6fb289d6f5)
- [Poll for H2 capacity before sending H2 body to propagate backpressure](https://github.com/cloudflare/pingora/commit/b6f24ff3725d9d8b6a740d87cad959d94befbe54)
- [Fix for write_error_response for http2 downstreams to set EOS](https://github.com/cloudflare/pingora/commit/c0fa5065812d87e6e404c5624b26cd99c5194079)
- [Always drain v1 request body before session reuse](https://github.com/cloudflare/pingora/commit/fda3317ec822678564d641e7cf1c9b77ee3759ff)
- [Fixes HTTP1 client reads to properly timeout on initial read](https://github.com/cloudflare/pingora/commit/3c7db34acb0d930ae7043290a88bc56c1cd77e45)
- [Fixes issue where if TLS client never sends any bytes, hangs forever](https://github.com/cloudflare/pingora/commit/d1bf0bcac98f943fd716278d674e7d10dce2223e)

### Everything Else

- [Add builder api for pingora listeners](https://github.com/cloudflare/pingora/commit/3f564af3ae56e898478e13e71d67d095d7f5dbbd)
- [Better handling for h1 requests that contain both transfer-encoding and content-length](https://github.com/cloudflare/pingora/commit/9287b82645be4a52b0b63530ba38aa0c7ddc4b77)
- [Allow setting raw path in request to support non-UTF8 use cases](https://github.com/cloudflare/pingora/commit/e6b823c5d89860bb97713fdf14f197f799aed6af)
- [Allow reusing session on errors prior to proxy upstream](https://github.com/cloudflare/pingora/commit/f8d01278a586c60392b1e3b92e5ed97a415d8fe7)
- [Avoid allocating large buffer in the accept() loop](https://github.com/cloudflare/pingora/commit/ef234f5baa45650be064c7dd34c2f17986361480)
- [Ensure HTTP/1.1 when forcing chunked encoding](https://github.com/cloudflare/pingora/commit/9281cab8eab1b545f15f0e387d2ba4cd2ca27364)
- [Reject if the HTTP header contains duplicated Content-Length values](https://github.com/cloudflare/pingora/commit/eef35768d11305d1293468a6c3ce91a3858dc0fc)
- [proxy_upstream_filter tries to reuse downstream by default](https://github.com/cloudflare/pingora/commit/86293e65b5c7d8a96f3a333a1f191766dc95bee5)
- [Allow building server that avoids std::process::exit during shutdown](https://github.com/cloudflare/pingora/commit/2d977d4eb808d8bcbc0ce87cabac4cf4854dfb80)
- [Update Sentry crate to 0.36](https://github.com/cloudflare/pingora/commit/01a1f9a65c51a4351c29d6961ea3164a6a811958)
- [Update the bounds on `MemoryCache` methods to accept broader key types](https://github.com/cloudflare/pingora/commit/d66923a9a41d00b326cef5dfb57d8c020d6a4abb)
- [Flush already received data if upstream write errors](https://github.com/cloudflare/pingora/commit/aa7c2f1a89a652137a987e5f5dbdab228c2f4d06)
- [Allow modules to receive HttpTask::Done, flush response compression on receiving Done task](https://github.com/cloudflare/pingora/commit/c82fb6ba57b95c256b58095881a33a9bc08f170a)
- API signature changes as part of experimental proxy cache support
- Note MSRV was effectively bumped to 1.82 from 1.72 due to a dependency update, though older compilers may still be able to build by pinning dependencies, e.g. `cargo update -p backtrace --precise 0.3.74`.

## [0.4.0](https://github.com/cloudflare/pingora/compare/0.3.0...0.4.0) - 2024-11-01

### 🚀 Features
- [Add preliminary rustls support](https://github.com/cloudflare/pingora/commit/354a6ee1e99b82e23fc0f27a37d8bf41e62b2dc5)
- [Add experimental support for windows](https://github.com/cloudflare/pingora/commit/4aadba12727afe6178f3b9fc2a3cad2223ac7b2e)
- [Add the option to use no TLS implementation](https://github.com/cloudflare/pingora/commit/d8f3ffae77ddc1edd285ab1d517a1b6748ce3d58)
- [Add support for gRPC-web module to bridge gRPC-web client requests to gRPC server requests](https://github.com/cloudflare/pingora/commit/9917177c646a0ab58197f15ec57a3bcbe1e0a201)
- [Add the support for h2c and http1 to coexist](https://github.com/cloudflare/pingora/commit/792d5fd3c14c1cd588b155ddf09c09a4c125a26b)
- [Add the support for custom L4 connector](https://github.com/cloudflare/pingora/commit/7c122e7f36de5c946ac960a1691c5dd41f26e6e6)
- [Support opaque extension field in Backend](https://github.com/cloudflare/pingora/commit/999e379064d2c1266a267abdf9f4f41b14bffcf5)
- [Add the ability to ignore informational responses when proxying downstream](https://github.com/cloudflare/pingora/commit/be97e35031cf4f5a01191f1848bdf491bd9f0d62)
- [Add un-gzip support and allow decompress by algorithm](https://github.com/cloudflare/pingora/commit/e1c6e57db3e613991eda3160d15f81e0669ea066)
- [Add the ability to observe backend health status](https://github.com/cloudflare/pingora/commit/8a0c73f174a27a87c54426a748c4818b10de9425)
- [Add the support for passing sentry release](https://github.com/cloudflare/pingora/commit/07a970e413009ee62fc4c15e0820ae1aa036af22)
- [Add the support for binding to local port ranges](https://github.com/cloudflare/pingora/commit/d1d7a87b761eeb4f71fcaa3f7c4ae8e32f1d93c8)
- [Support retrieving rx timestamp for TcpStream](https://github.com/cloudflare/pingora/commit/d811795938cee5a6eb7cd46399cef17210a0d0c5)

### 🐛 Bug Fixes
- [Handle bare IPv6 address in raw connect Host](https://github.com/cloudflare/pingora/commit/9f50e6ccb09db2940eec6fc170a1e9e9b14a95d0)
- [Set proper response headers when compression is enabled](https://github.com/cloudflare/pingora/commit/55049c4e7983055551b34feee397c736ffc912bb)
- [Check the current advertised h2 max streams](https://github.com/cloudflare/pingora/commit/7419b1967e7686b00aefb7bcd2a4dfe59b31e639)
- Other bug fixes and improvements


### ⚙️ Changes and Miscellaneous Tasks
- [Make sentry an optional feature](https://github.com/cloudflare/pingora/commit/ab1b717bf587723c1c537d6549a8f8096f0900d4)
- [Make timeouts Sync](https://github.com/cloudflare/pingora/commit/18db42cd2cb892432fd7896f0da7e9d19221214b)
- [Retry all h2 connection when encountering graceful shutdown](https://github.com/cloudflare/pingora/commit/11b5882a422774cffbd14d9a9ea7dfc9dc98b02c)
- [Make l4 module pub to expose Connect](https://github.com/cloudflare/pingora/commit/91702bb0c0c5e1f2d5e2f40a19a3f340bb5a6d82)
- [Auto snake case set-cookie header when downgrade to from h2 to http1.1](https://github.com/cloudflare/pingora/commit/2c6190c634f2a5dd2f00e8597902f2b735a9d84f)
- [shutdown h2 connection gracefully with GOAWAYs](https://github.com/cloudflare/pingora/commit/04d7cfeef6205d2cf33ad5704a363ee107250771)
- Other API signature updates

## [0.3.0](https://github.com/cloudflare/pingora/compare/0.2.0...0.3.0) - 2024-07-12

### 🚀 Features
- Add support for HTTP modules. This feature allows users to import modules written by 3rd parties.
- Add `request_body_filter`. Now request body can be inspected and modified.
- Add H2c support.
- Add TCP fast open support.
- Add support for server side TCP keep-alive.
- Add support to get TCP_INFO.
- Add support to set DSCP.
- Add `or_err()`/`or_err_with` API to convert `Options` to `pingora::Error`.
- Add `or_fail()` API to convert `impl std::error::Error` to `pingora::Error`.
- Add the API to track socket read and write pending time.
- Compression: allow setting level per algorithm.

### 🐛 Bug Fixes
- Fixed a panic when using multiple H2 streams in the same H2 connection to upstreams.
- Pingora now respects the `Connection` header it sends to upstream.
- Accept-Ranges header is now removed when response is compressed.
- Fix ipv6_only socket flag.
- A new H2 connection is opened now if the existing connection returns GOAWAY with graceful shutdown error.
- Fix a FD mismatch error when 0.0.0.0 is used as the upstream IP

### ⚙️ Changes and Miscellaneous Tasks
- Dependency: replace `structopt` with `clap`
- Rework the API of HTTP modules
- Optimize remove_header() API call
- UDS parsing now requires the path to have `unix:` prefix. The support for the path without prefix is deprecated and will be removed on the next release.
- Other minor API changes

## [0.2.0](https://github.com/cloudflare/pingora/compare/0.1.1...0.2.0) - 2024-05-10

### 🚀 Features
- Add support for downstream h2 trailers and add an upstream h2 response trailer filter
- Add the ability to set TCP recv buf size
- Add a convenience function to retrieve Session digest
- Add `body_bytes_read()` method to Session
- Add `cache_not_modified_filter`
- Add `SSLKEYLOG` support for tls upstream
- Add `Service<HttpProxy<T>>` constructor for providing name
- Add `purge_response` callback
- Make `pop_closed` pub, to simplify DIY drains

### 🐛 Bug Fixes
- Fixed gRPC trailer proxying
- Fixed `response_body_filter` `end_of_stream` always being false
- Fixed compile error in Rust <= 1.73
- Fixed non linux build
- Fixed the counting problem of used_weight data field in `LruUnit<T>`
- Fixed `cargo run --example server` missing cert
- Fixed error log string interpolation outside of proper context
- Fixed tinylfu test flake

### ⚙️ Changes and Miscellaneous Tasks
- API change: `Server::run_forever` now takes ownership and ensures exit semantics
- API change: `cleanup()` method of `ServerApp` trait is now async
- Behavior change: Always return `HttpTask::Body` on body done instead of `HttpTask::done`
- Behavior change: HTTP/1 reason phrase is now parsed and proxied
- Updated `h2` dependency for RUSTSEC-2024-0332
- Updated zstd dependencies
- Code optimization and refactor in a few crates
- More examples and docs

## [0.1.1](https://github.com/cloudflare/pingora/compare/0.1.0...0.1.1) - 2024-04-05

### 🚀 Features
- `Server::new` now accepts `Into<Option<T>>`
- Implemented client `HttpSession::get_keepalive_values` for Keep-Alive parsing
- Expose `ListenFds` and `Fds` to fix a voldemort types issue
- Expose config options in `ServerConf`, provide new `Server` constructor
- `upstream_response_filter` now runs on upstream 304 responses during cache revalidation
- Added `server_addr` and `client_addr` APIs to `Session`
- Allow body modification in `response_body_filter`
- Allow configuring grace period and graceful shutdown timeout
- Added TinyUFO sharded skip list storage option

### 🐛 Bug Fixes
- Fixed build failures with the `boringssl` feature
- Fixed compile warnings with nightly Rust
- Fixed an issue where Upgrade request bodies might not be handled correctly
- Fix compilation to only include openssl or boringssl rather than both
- Fix OS read errors so they are reported as `ReadError` rather than `ReadTimeout` when reading http/1.1 response headers

### ⚙️ Miscellaneous Tasks
- Performance improvements in `pingora-ketama`
- Added more TinyUFO benchmarks
- Added tests for `pingora-cache` purge
- Limit buffer size for `InvalidHTTPHeader` error logs
- Example code: improvements in pingora client, new LB cluster example
- Typo fixes and clarifications across comments and docs

## [0.1.0] - 2024-02-28
### Highlights
- First Public Release of Pingora 🎉
