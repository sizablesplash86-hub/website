// Copyright 2026 Cloudflare, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Extra information about the connection

use std::sync::Arc;
use std::time::{Duration, SystemTime};

use once_cell::sync::OnceCell;

use super::l4::ext::{get_original_dest, get_recv_buf, get_snd_buf, get_tcp_info, TCP_INFO};
use super::l4::socket::SocketAddr;
use super::raw_connect::ProxyDigest;
use super::tls::digest::SslDigest;

/// The information can be extracted from a connection
#[derive(Clone, Debug, Default)]
pub struct Digest {
    /// Information regarding the TLS of this connection if any
    pub ssl_digest: Option<Arc<SslDigest>>,
    /// Timing information
    pub timing_digest: Vec<Option<TimingDigest>>,
    /// information regarding the CONNECT proxy this connection uses.
    pub proxy_digest: Option<Arc<ProxyDigest>>,
    /// Information about underlying socket/fd of this connection
    pub socket_digest: Option<Arc<SocketDigest>>,
}

/// The interface to return protocol related information
pub trait ProtoDigest {
    fn get_digest(&self) -> Option<&Digest> {
        None
    }
}

/// Timing information for one layer of a connection.
#[derive(Clone, Debug)]
pub struct TimingDigest {
    /// When this connection layer was established.
    pub established_ts: SystemTime,
    /// Monotonic duration of this layer's establishment operation.
    ///
    /// This avoids estimating elapsed time by subtracting wall-clock [`Self::established_ts`]
    /// values. On the lowest transport-layer entry, it measures L4 connection establishment. On
    /// a TLS entry, it measures the actual TLS handshake and excludes TLS configuration setup.
    /// `None` means that the producer did not measure this operation.
    pub establishment_duration: Option<Duration>,
    /// Monotonic duration between submitting connection work to an offload runtime and that work
    /// beginning execution.
    ///
    /// This allows consumers to distinguish runtime scheduling delay from network connection
    /// latency. It is only set on the lowest transport-layer entry when connection establishment
    /// was offloaded. `None` means that no offload wait occurred or was measured.
    pub offload_wait_duration: Option<Duration>,
}

impl Default for TimingDigest {
    fn default() -> Self {
        TimingDigest {
            established_ts: SystemTime::UNIX_EPOCH,
            establishment_duration: None,
            offload_wait_duration: None,
        }
    }
}

#[derive(Debug)]
/// The interface to return socket-related information
pub struct SocketDigest {
    #[cfg(unix)]
    raw_fd: std::os::unix::io::RawFd,
    #[cfg(windows)]
    raw_sock: std::os::windows::io::RawSocket,
    /// Remote socket address
    pub peer_addr: OnceCell<Option<SocketAddr>>,
    /// Local socket address
    pub local_addr: OnceCell<Option<SocketAddr>>,
    /// Original destination address
    pub original_dst: OnceCell<Option<SocketAddr>>,
}

impl SocketDigest {
    #[cfg(unix)]
    pub fn from_raw_fd(raw_fd: std::os::unix::io::RawFd) -> SocketDigest {
        SocketDigest {
            raw_fd,
            peer_addr: OnceCell::new(),
            local_addr: OnceCell::new(),
            original_dst: OnceCell::new(),
        }
    }

    #[cfg(windows)]
    pub fn from_raw_socket(raw_sock: std::os::windows::io::RawSocket) -> SocketDigest {
        SocketDigest {
            raw_sock,
            peer_addr: OnceCell::new(),
            local_addr: OnceCell::new(),
            original_dst: OnceCell::new(),
        }
    }

    /// Return the kernel socket cookie for this connection.
    ///
    /// This is backed by Linux's `SO_COOKIE` socket option. On other Unix
    /// platforms this returns `Ok(0)`.
    #[cfg(unix)]
    pub fn socket_cookie(&self) -> std::io::Result<u64> {
        super::l4::ext::get_socket_cookie(self.raw_fd)
    }

    #[cfg(unix)]
    pub fn peer_addr(&self) -> Option<&SocketAddr> {
        self.peer_addr
            .get_or_init(|| SocketAddr::from_raw_fd(self.raw_fd, true))
            .as_ref()
    }

    #[cfg(windows)]
    pub fn peer_addr(&self) -> Option<&SocketAddr> {
        self.peer_addr
            .get_or_init(|| SocketAddr::from_raw_socket(self.raw_sock, true))
            .as_ref()
    }

    #[cfg(unix)]
    pub fn local_addr(&self) -> Option<&SocketAddr> {
        self.local_addr
            .get_or_init(|| SocketAddr::from_raw_fd(self.raw_fd, false))
            .as_ref()
    }

    #[cfg(windows)]
    pub fn local_addr(&self) -> Option<&SocketAddr> {
        self.local_addr
            .get_or_init(|| SocketAddr::from_raw_socket(self.raw_sock, false))
            .as_ref()
    }

    fn is_inet(&self) -> bool {
        self.local_addr().and_then(|p| p.as_inet()).is_some()
    }

    #[cfg(unix)]
    pub fn tcp_info(&self) -> Option<TCP_INFO> {
        if self.is_inet() {
            get_tcp_info(self.raw_fd).ok()
        } else {
            None
        }
    }

    #[cfg(windows)]
    pub fn tcp_info(&self) -> Option<TCP_INFO> {
        if self.is_inet() {
            get_tcp_info(self.raw_sock).ok()
        } else {
            None
        }
    }

    #[cfg(unix)]
    pub fn get_recv_buf(&self) -> Option<usize> {
        if self.is_inet() {
            get_recv_buf(self.raw_fd).ok()
        } else {
            None
        }
    }

    #[cfg(windows)]
    pub fn get_recv_buf(&self) -> Option<usize> {
        if self.is_inet() {
            get_recv_buf(self.raw_sock).ok()
        } else {
            None
        }
    }

    #[cfg(unix)]
    pub fn get_snd_buf(&self) -> Option<usize> {
        if self.is_inet() {
            get_snd_buf(self.raw_fd).ok()
        } else {
            None
        }
    }

    #[cfg(windows)]
    pub fn get_snd_buf(&self) -> Option<usize> {
        if self.is_inet() {
            get_snd_buf(self.raw_sock).ok()
        } else {
            None
        }
    }

    #[cfg(unix)]
    pub fn original_dst(&self) -> Option<&SocketAddr> {
        self.original_dst
            .get_or_init(|| {
                get_original_dest(self.raw_fd)
                    .ok()
                    .flatten()
                    .map(SocketAddr::Inet)
            })
            .as_ref()
    }

    #[cfg(windows)]
    pub fn original_dst(&self) -> Option<&SocketAddr> {
        self.original_dst
            .get_or_init(|| {
                get_original_dest(self.raw_sock)
                    .ok()
                    .flatten()
                    .map(SocketAddr::Inet)
            })
            .as_ref()
    }
}

/// The interface to return timing information
pub trait GetTimingDigest {
    /// Return the timing for each layer from the lowest layer to upper
    fn get_timing_digest(&self) -> Vec<Option<TimingDigest>>;
    fn get_read_pending_time(&self) -> Duration {
        Duration::ZERO
    }
    fn get_write_pending_time(&self) -> Duration {
        Duration::ZERO
    }
}

/// The interface to set or return proxy information
pub trait GetProxyDigest {
    fn get_proxy_digest(&self) -> Option<Arc<ProxyDigest>>;
    fn set_proxy_digest(&mut self, _digest: ProxyDigest) {}
}

/// The interface to set or return socket information
pub trait GetSocketDigest {
    fn get_socket_digest(&self) -> Option<Arc<SocketDigest>>;
    fn set_socket_digest(&mut self, _socket_digest: SocketDigest) {}
}

#[cfg(all(test, target_os = "linux"))]
mod tests {
    use super::SocketDigest;
    use std::os::unix::io::AsRawFd;

    #[test]
    fn socket_cookie_returns_cookie_for_tcp_socket() {
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let client = std::net::TcpStream::connect(listener.local_addr().unwrap()).unwrap();
        let (server, _) = listener.accept().unwrap();

        let client_digest = SocketDigest::from_raw_fd(client.as_raw_fd());
        let server_digest = SocketDigest::from_raw_fd(server.as_raw_fd());

        assert_ne!(client_digest.socket_cookie().unwrap(), 0);
        assert_ne!(server_digest.socket_cookie().unwrap(), 0);
    }

    #[test]
    fn socket_cookie_returns_cookie_for_unix_socket() {
        let (client, server) = std::os::unix::net::UnixStream::pair().unwrap();

        let client_digest = SocketDigest::from_raw_fd(client.as_raw_fd());
        let server_digest = SocketDigest::from_raw_fd(server.as_raw_fd());

        assert_ne!(client_digest.socket_cookie().unwrap(), 0);
        assert_ne!(server_digest.socket_cookie().unwrap(), 0);
    }
}
