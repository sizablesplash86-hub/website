// Copyright 2026 Cloudflare, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! HTTP/1.x server session

use bstr::ByteSlice;
use bytes::Bytes;
use bytes::{BufMut, BytesMut};
use http::header::{CONTENT_LENGTH, TRANSFER_ENCODING};
use http::HeaderValue;
use http::{header, header::AsHeaderName, Method, Version};
use log::{debug, trace, warn};
use once_cell::sync::Lazy;
use percent_encoding::{percent_encode, AsciiSet, CONTROLS};
use pingora_error::{Error, ErrorType::*, OrErr, Result};
use pingora_http::{IntoCaseHeaderName, RequestHeader, ResponseHeader};
use pingora_timeout::timeout;
use regex::bytes::Regex;
use std::any::Any;
use std::collections::VecDeque;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};

use super::body::{BodyReader, BodyWriter};
use super::common::*;
use super::header::HeaderWriter;
use crate::protocols::http::{
    authority::validate_request_authority, body_buffer::FixedBuffer, date, HttpTask,
    ReusableHttpStream,
};
use crate::protocols::{Digest, SocketAddr, Stream};
use crate::utils::{BufRef, KVRef};

/// Tracks which writer is currently processing a task.
///
/// This enables resuming writes after cancellation. Each variant stores the
/// minimal data needed for cleanup after write completes.
#[derive(Debug)]
enum ProxyTaskWriter {
    /// Currently writing a header task.
    /// Stores: (header for `response_written`, end_stream flag)
    WritingHeader(Box<ResponseHeader>, bool),
    /// Currently writing a body task (`Body` or `UpgradedBody`).
    /// Stores: (end_stream flag)
    WritingBody(bool),
    /// Currently finishing the body (writing last chunk + flush).
    FinishingBody,
}

/// State for the cancel-safe proxy task write API.
#[derive(Default)]
struct ProxyTaskState {
    /// Lazily initialized — `HeaderWriter::new()` heap-allocates.
    header_writer: Option<HeaderWriter>,
    tasks: VecDeque<HttpTask>,
    current_writer: Option<ProxyTaskWriter>,
}

impl ProxyTaskState {
    fn header_writer(&mut self) -> &mut HeaderWriter {
        self.header_writer.get_or_insert_with(HeaderWriter::new)
    }
}

/// The HTTP 1.x server session
pub struct HttpSession {
    underlying_stream: Stream,
    /// The buf that holds the raw request header + possibly a portion of request body
    /// Request body can appear here because they could arrive with the same read() that
    /// sends the request header.
    buf: Bytes,
    /// A slice reference to `buf` which points to the exact range of request header
    raw_header: Option<BufRef>,
    /// Request bytes read beyond the header, owned separately so they can move through the body
    /// reader and into the next pipelined session without copying.
    preread_body: Option<BytesMut>,
    /// A state machine to track how to read the request body
    body_reader: BodyReader,
    /// A state machine to track how to write the response body
    body_writer: BodyWriter,
    /// Cancel-safe proxy task state.
    proxy_task_state: ProxyTaskState,
    /// An internal buffer to buf multiple body writes to reduce the underlying syscalls
    body_write_buf: BytesMut,
    /// Track how many application (not on the wire) body bytes already sent
    body_bytes_sent: usize,
    /// Track how many application (not on the wire) body bytes already read
    body_bytes_read: usize,
    /// Whether to update headers like connection, Date
    update_resp_headers: bool,
    /// timeouts:
    keepalive_timeout: KeepaliveStatus,
    read_timeout: Option<Duration>,
    write_timeout: Option<Duration>,
    /// How long to wait to make downstream session reusable, if body needs to be drained.
    total_drain_timeout: Option<Duration>,
    /// A copy of the response that is already written to the client
    response_written: Option<Box<ResponseHeader>>,
    /// The parsed request header
    request_header: Option<Box<RequestHeader>>,
    /// An internal buffer that holds a copy of the request body up to a certain size
    retry_buffer: Option<FixedBuffer>,
    /// Whether this session is an upgraded session. This flag is calculated when sending the
    /// response header to the client.
    upgraded: bool,
    /// Digest to track underlying connection metrics
    digest: Box<Digest>,
    /// Minimum send rate to the client
    min_send_rate: Option<usize>,
    /// When this is enabled informational response headers will not be proxied downstream
    ignore_info_resp: bool,
    /// Disable keepalive if response is sent before downstream body is finished
    close_on_response_before_downstream_finish: bool,

    /// Number of times the upstream connection associated with this session can be reused
    /// after this session ends
    keepalive_reuses_remaining: Option<u32>,
    /// User-defined context carried across requests on the same keepalive connection.
    /// Set by [`HttpPersistentSettings::apply_to_session`](crate::apps::HttpPersistentSettings::apply_to_session),
    /// consumed by the proxy layer via [`take_connection_user_context`](Self::take_connection_user_context).
    connection_user_context: Option<Box<dyn Any + Send + Sync>>,
    /// Whether the client has closed the TCP connection (sent FIN / read returned 0).
    half_closed: bool,
    /// When true (default), a client close after the request body is surfaced as a
    /// `ConnectionClosed` error so the proxy aborts immediately. When false, the
    /// close is tolerated and `read_body_or_idle` stays pending so the proxy can
    /// finish delivering the upstream response (RFC 9112 Section 9.6).
    abort_on_close: bool,
    /// Whether the cancel-safe proxy task API is enabled for this session.
    /// Defaults to false. Can be enabled via [`set_proxy_tasks_enabled`](Self::set_proxy_tasks_enabled).
    proxy_tasks_enabled: bool,
    /// Whether HTTP/1.1 request pipelining is enabled for this session.
    /// Defaults to false. Can be enabled via [`set_pipelining_enabled`](Self::set_pipelining_enabled).
    /// See [`Self::set_pipelining_enabled`] for RFC 9112 §9.3.2 semantics.
    pipelining_enabled: bool,
    /// Pipelined bytes from the previous request on the same keep-alive connection,
    /// to be parsed as the start of this session's request. Consumed on the first
    /// call to [`Self::read_request`]. Set via [`Self::set_pipelined_prefix`] after
    /// the previous session's [`BodyReader::take_body_overread`] yielded bytes.
    pipelined_prefix: Option<BytesMut>,
    /// Set once the idle-branch of [`Self::read_body_or_idle`] has read the
    /// first bytes of a pipelined next request and pushed them onto the body
    /// reader's overread surface. Further idle polls on the same request
    /// return pending instead of re-reading the stream, so the body-pump
    /// `tokio::select!` loop can exit via its other branches while the
    /// stashed bytes travel through `reuse()` +
    /// [`super::super::HttpPersistentSettings`] into the next session.
    /// Scoped narrowly so it cannot affect FIN / `abort_on_close` semantics.
    pipelined_idle_bytes_stashed: bool,
}

impl HttpSession {
    /// Create a new http server session from an established (TCP or TLS) [`Stream`].
    /// The created session needs to call [`Self::read_request()`] first before performing
    /// any other operations.
    pub fn new(underlying_stream: Stream) -> Self {
        // TODO: maybe we should put digest in the connection itself
        let digest = Box::new(Digest {
            ssl_digest: underlying_stream.get_ssl_digest(),
            timing_digest: underlying_stream.get_timing_digest(),
            proxy_digest: underlying_stream.get_proxy_digest(),
            socket_digest: underlying_stream.get_socket_digest(),
        });

        HttpSession {
            underlying_stream,
            buf: Bytes::new(), // zero size, with be replaced by parsed header later
            raw_header: None,
            preread_body: None,
            body_reader: BodyReader::new(false),
            body_writer: BodyWriter::new(),
            proxy_task_state: ProxyTaskState::default(),
            body_write_buf: BytesMut::new(),
            keepalive_timeout: KeepaliveStatus::Off,
            update_resp_headers: true,
            response_written: None,
            request_header: None,
            read_timeout: Some(Duration::from_secs(60)),
            write_timeout: None,
            total_drain_timeout: None,
            body_bytes_sent: 0,
            body_bytes_read: 0,
            retry_buffer: None,
            upgraded: false,
            digest,
            min_send_rate: None,
            ignore_info_resp: false,
            // default on to avoid rejecting requests after body as pipelined
            close_on_response_before_downstream_finish: true,
            keepalive_reuses_remaining: None,
            connection_user_context: None,
            half_closed: false,
            abort_on_close: true,
            proxy_tasks_enabled: false,
            pipelining_enabled: false,
            pipelined_prefix: None,
            pipelined_idle_bytes_stashed: false,
        }
    }

    async fn read_request_buf(
        &mut self,
        buf: &mut BytesMut,
        already_read: usize,
    ) -> Result<Option<usize>> {
        let read_result = {
            let read_event = self.underlying_stream.read_buf(buf);
            match self.keepalive_timeout {
                KeepaliveStatus::Timeout(d) => match timeout(d, read_event).await {
                    Ok(res) => res,
                    Err(e) => {
                        debug!("keepalive timeout {d:?} reached, {e}");
                        return Ok(None);
                    }
                },
                KeepaliveStatus::Infinite => {
                    // FIXME: this should only apply to reads between requests
                    read_event.await
                }
                KeepaliveStatus::Off => match self.read_timeout {
                    Some(t) => match timeout(t, read_event).await {
                        Ok(res) => res,
                        Err(e) => {
                            debug!("read timeout {t:?} reached, {e}");
                            return Error::e_explain(ReadTimedout, format!("timeout: {t:?}"));
                        }
                    },
                    None => read_event.await,
                },
            }
        };

        match read_result {
            Ok(n_read) => {
                if n_read == 0 {
                    if already_read > 0 {
                        Error::e_explain(
                            ConnectionClosed,
                            format!(
                                "while reading request headers, bytes already read: {}",
                                already_read
                            ),
                        )
                    } else {
                        /* common when client decides to close a keepalived session */
                        debug!("Client prematurely closed connection with 0 byte sent");
                        Ok(None)
                    }
                } else {
                    Ok(Some(n_read))
                }
            }
            Err(e) => {
                if already_read > 0 {
                    Error::e_because(ReadError, "while reading request headers", e)
                } else {
                    /* nothing harmful since we have not ready any thing yet */
                    Ok(None)
                }
            }
        }
    }

    /// Read the request header. Return `Ok(Some(n))` where the read and parsing are successful.
    /// Return `Ok(None)` when the client closed the connection without sending any data, which
    /// is common on a reused connection.
    pub async fn read_request(&mut self) -> Result<Option<usize>> {
        const MAX_ERR_BUF_LEN: usize = 2048;

        self.buf.clear();
        // Account parsing a fully buffered request against Tokio's cooperative task budget. Do
        // this before taking the prefix so cancellation cannot discard bytes between sessions.
        if self
            .pipelined_prefix
            .as_ref()
            .is_some_and(|prefix| !prefix.is_empty())
        {
            tokio::task::consume_budget().await;
        }

        // If the caller (e.g. the proxy layer completing a pipelined request on
        // a reused keep-alive connection) handed us bytes that were read past
        // the end of the previous request's body, pre-fill our parse buffer so
        // the header parser sees them as the start of this request. The loop
        // below tries to parse first when we already have pipelined bytes —
        // a pipelined prefix can contain a complete request header, in which
        // case we must NOT issue another stream read (which would block).
        let mut buf = self
            .pipelined_prefix
            .take()
            .filter(|prefix| !prefix.is_empty())
            .unwrap_or_else(|| BytesMut::with_capacity(INIT_HEADER_BUF_SIZE));
        let mut already_read = buf.len();
        let mut skip_next_read = already_read != 0;
        let mut detached_suffix = None;
        loop {
            if already_read > MAX_HEADER_SIZE {
                /* NOTE: this check only blocks second read. The first large read is allowed
                since the buf is already allocated. The goal is to avoid slowly bloating
                this buffer */
                return Error::e_explain(
                    InvalidHTTPHeader,
                    format!("Request header larger than {MAX_HEADER_SIZE}"),
                );
            }

            // On the first iteration after a pipelined prefix was injected,
            // attempt to parse what we already have before issuing a stream
            // read. If the prefix contains a complete request header, a
            // subsequent read_buf() would block for data that may never come
            // (the client already pipelined everything it had to send for
            // this request and is waiting for our response).
            if skip_next_read {
                skip_next_read = false;
            } else if let Some(n) = self.read_request_buf(&mut buf, already_read).await? {
                already_read += n;
            } else {
                return Ok(None);
            }

            // Use loop as GOTO to retry escaped request buffer, not a real loop
            loop {
                let mut headers = [httparse::EMPTY_HEADER; MAX_HEADERS];
                let mut req = httparse::Request::new(&mut headers);
                let parsed = parse_req_buffer(&mut req, &buf);
                match parsed {
                    HeaderParseState::Complete(s) => {
                        self.raw_header = Some(BufRef(0, s));

                        // We have the header name and values we parsed to be just 0 copy Bytes
                        // referencing the original buf. That requires we convert the buf from
                        // BytesMut to Bytes. But `req` holds a reference to `buf`. So we use the
                        // `KVRef`s to record the offset of each piece of data, drop `req`, convert
                        // buf, the do the 0 copy update
                        let base = buf.as_ptr() as usize;
                        let mut header_refs = Vec::<KVRef>::with_capacity(req.headers.len());
                        // Note: req.headers has the correct number of headers
                        // while header_refs doesn't as it is still empty
                        let _num_headers = populate_headers(base, &mut header_refs, req.headers);

                        let mut request_header = Box::new(RequestHeader::build(
                            req.method.unwrap_or(""),
                            // we path httparse to allow unsafe bytes in the str
                            req.path.unwrap_or("").as_bytes(),
                            Some(req.headers.len()),
                        )?);

                        request_header.set_version(match req.version {
                            Some(1) => Version::HTTP_11,
                            Some(0) => Version::HTTP_10,
                            _ => Version::HTTP_09,
                        });

                        // Detach bytes beyond the header in O(1). Keeping them as owned BytesMut
                        // allows body parsing and subsequent pipelined sessions to continue
                        // splitting the same allocation instead of copying the shrinking suffix.
                        let preread_body = if s == buf.len() {
                            // Keep the common no-body/no-overread path on BytesMut's Vec-backed
                            // representation. split_off() would promote it to shared storage.
                            detached_suffix.take().unwrap_or_default()
                        } else {
                            let mut rest = buf.split_off(s);
                            if let Some(suffix) = detached_suffix.take() {
                                // The URI-escape path below detaches everything past the first
                                // CRLFCRLF, but httparse also accepts bare LF line endings, so the
                                // header can end before that. Stitch the leftover bytes back in
                                // front of the suffix instead of dropping them.
                                rest.unsplit(suffix);
                            }
                            rest
                        };
                        let buf = buf.freeze();

                        for header in header_refs {
                            let header_name = header.get_name_bytes(&buf);
                            let header_name = header_name.into_case_header_name();
                            let value_bytes = header.get_value_bytes(&buf);
                            // safe because this is from what we parsed
                            let header_value = unsafe {
                                http::HeaderValue::from_maybe_shared_unchecked(value_bytes)
                            };

                            request_header
                                .append_header(header_name, header_value)
                                .or_err(InvalidHTTPHeader, "while parsing request header")?;
                        }

                        let contains_transfer_encoding =
                            request_header.headers.contains_key(TRANSFER_ENCODING);
                        let contains_content_length =
                            request_header.headers.contains_key(CONTENT_LENGTH);

                        // Transfer encoding overrides content length, so when
                        // both are present, we can remove content length. This
                        // is per https://datatracker.ietf.org/doc/html/rfc9112#section-6.3
                        //
                        // RFC 9112 Section 6.1 (https://datatracker.ietf.org/doc/html/rfc9112#section-6.1-15)
                        // also requires us to disable keepalive when both headers are present.
                        let has_both_te_and_cl =
                            contains_content_length && contains_transfer_encoding;
                        if has_both_te_and_cl {
                            request_header.remove_header(&CONTENT_LENGTH);
                        }

                        self.buf = buf;
                        self.preread_body = Some(preread_body);
                        self.request_header = Some(request_header);

                        self.body_reader.reinit();
                        self.pipelined_idle_bytes_stashed = false;
                        self.response_written = None;
                        self.respect_keepalive();

                        // Disable keepalive if both Transfer-Encoding and Content-Length were present
                        if has_both_te_and_cl {
                            self.set_keepalive(None);
                        }
                        self.validate_request()?;

                        return Ok(Some(s));
                    }
                    HeaderParseState::Partial => {
                        break; /* continue the read loop */
                    }
                    HeaderParseState::Invalid(e) => match e {
                        httparse::Error::Token | httparse::Error::Version => {
                            // URI escaping rebuilds the current header. Detach any request body or
                            // pipelined suffix first so normalization never copies queued requests.
                            // `separator_start` is the index of the blank line itself, so the
                            // header ends just past it.
                            if detached_suffix.is_none() {
                                if let Some(header_end) =
                                    buf.find(HEADER_SECTION_END).map(|separator_start| {
                                        separator_start + HEADER_SECTION_END.len()
                                    })
                                {
                                    detached_suffix = Some(buf.split_off(header_end));
                                }
                            }
                            // try to escape URI
                            if let Some(new_buf) = escape_illegal_request_line(&buf) {
                                buf = new_buf;
                                already_read = buf.len();
                            } else {
                                debug!("Invalid request header from {:?}", self.underlying_stream);
                                buf.truncate(MAX_ERR_BUF_LEN);
                                return Error::e_because(
                                    InvalidHTTPHeader,
                                    format!("buf: {}", buf.escape_ascii()),
                                    e,
                                );
                            }
                        }
                        _ => {
                            debug!("Invalid request header from {:?}", self.underlying_stream);
                            buf.truncate(MAX_ERR_BUF_LEN);
                            return Error::e_because(
                                InvalidHTTPHeader,
                                format!("buf: {:?}", buf.as_bstr()),
                                e,
                            );
                        }
                    },
                }
            }
        }
    }

    /// Validate the request header read. This function must be called after the request header
    /// read.
    /// # Panics
    /// this function and most other functions will panic if called before [`Self::read_request()`]
    pub fn validate_request(&self) -> Result<()> {
        let req_header = self.req_header();

        // Reject an ambiguous authority before anything routes on it.
        validate_request_authority(req_header)?;

        // Validate/reconcile Content-Length per RFC 9110 section 8.6 (hyper
        // parity): identical duplicates and comma-combined identical values are
        // accepted and collapsed; differing or unparseable values are rejected.
        // This is a no-op when Transfer-Encoding is present (TE overrides CL).
        super::common::validate_content_length(&req_header.headers)?;

        if req_header.headers.contains_key(TRANSFER_ENCODING) {
            // Per [RFC 9112 Section 6.1-16](https://datatracker.ietf.org/doc/html/rfc9112#section-6.1-16),
            // HTTP/1.0 requests with Transfer-Encoding MUST be treated as having faulty framing.
            // We reject with 400 Bad Request and close the connection.
            if req_header.version == http::Version::HTTP_10 {
                return Error::e_explain(
                    InvalidHTTPHeader,
                    "HTTP/1.0 requests cannot include Transfer-Encoding header",
                );
            }
            // If chunked is not the final Transfer-Encoding, reject request
            // See https://datatracker.ietf.org/doc/html/rfc9112#section-6.3-2.4.3
            if !self.is_chunked_encoding() {
                return Error::e_explain(InvalidHTTPHeader, "non-chunked final Transfer-Encoding");
            }
        }

        Ok(())
    }

    /// Return a reference of the `RequestHeader` this session read
    /// # Panics
    /// this function and most other functions will panic if called before [`Self::read_request()`]
    pub fn req_header(&self) -> &RequestHeader {
        self.request_header
            .as_ref()
            .expect("Request header is not read yet")
    }

    /// Return a mutable reference of the `RequestHeader` this session read
    /// # Panics
    /// this function and most other functions will panic if called before [`Self::read_request()`]
    pub fn req_header_mut(&mut self) -> &mut RequestHeader {
        self.request_header
            .as_mut()
            .expect("Request header is not read yet")
    }

    /// Get the header value for the given header name
    /// If there are multiple headers under the same name, the first one will be returned
    /// Use `self.req_header().header.get_all(name)` to get all the headers under the same name
    pub fn get_header(&self, name: impl AsHeaderName) -> Option<&HeaderValue> {
        self.request_header
            .as_ref()
            .and_then(|h| h.headers.get(name))
    }

    /// Return the method of this request. None if the request is not read yet.
    pub(crate) fn get_method(&self) -> Option<&http::Method> {
        self.request_header.as_ref().map(|r| &r.method)
    }

    /// Return the path of the request (i.e., the `/hello?1` of `GET /hello?1 HTTP1.1`)
    /// An empty slice will be used if there is no path or the request is not read yet
    pub(crate) fn get_path(&self) -> &[u8] {
        self.request_header.as_ref().map_or(b"", |r| r.raw_path())
    }

    /// Return the host header of the request. An empty slice will be used if there is no host header
    pub(crate) fn get_host(&self) -> &[u8] {
        self.request_header
            .as_ref()
            .and_then(|h| h.headers.get(header::HOST))
            .map_or(b"", |h| h.as_bytes())
    }

    /// Return a string `$METHOD $PATH, Host: $HOST`. Mostly for logging and debug purpose
    pub fn request_summary(&self) -> String {
        format!(
            "{} {}, Host: {}",
            self.get_method().map_or("-", |r| r.as_str()),
            String::from_utf8_lossy(self.get_path()),
            String::from_utf8_lossy(self.get_host())
        )
    }

    /// Is the request a upgrade request
    pub fn is_upgrade_req(&self) -> bool {
        match self.request_header.as_deref() {
            Some(req) => is_upgrade_req(req),
            None => false,
        }
    }

    /// Get the request header as raw bytes, `b""` when the header doesn't exist
    pub fn get_header_bytes(&self, name: impl AsHeaderName) -> &[u8] {
        self.get_header(name).map_or(b"", |v| v.as_bytes())
    }

    /// Read the request body. `Ok(None)` when there is no (more) body to read.
    pub async fn read_body_bytes(&mut self) -> Result<Option<Bytes>> {
        let read = self.read_body().await?;
        Ok(read.map(|b| {
            let bytes = Bytes::copy_from_slice(self.get_body(&b));
            self.body_bytes_read += bytes.len();
            if let Some(buffer) = self.retry_buffer.as_mut() {
                buffer.write_to_buffer(&bytes);
            }
            bytes
        }))
    }

    async fn do_read_body(&mut self) -> Result<Option<BufRef>> {
        self.init_body_reader();
        self.body_reader
            .read_body(&mut self.underlying_stream)
            .await
    }

    /// Read the body into the internal buffer
    async fn read_body(&mut self) -> Result<Option<BufRef>> {
        match self.read_timeout {
            Some(t) => match timeout(t, self.do_read_body()).await {
                Ok(res) => res,
                Err(_) => Error::e_explain(ReadTimedout, format!("reading body, timeout: {t:?}")),
            },
            None => self.do_read_body().await,
        }
    }

    async fn do_drain_request_body(&mut self) -> Result<()> {
        loop {
            match self.read_body_bytes().await {
                Ok(Some(_)) => { /* continue to drain */ }
                Ok(None) => return Ok(()), // done
                Err(e) => return Err(e),
            }
        }
    }

    /// Drain the request body. `Ok(())` when there is no (more) body to read.
    pub async fn drain_request_body(&mut self) -> Result<()> {
        if self.is_body_done() {
            return Ok(());
        }
        match self.total_drain_timeout {
            Some(t) => match timeout(t, self.do_drain_request_body()).await {
                Ok(res) => res,
                Err(_) => Error::e_explain(ReadTimedout, format!("draining body, timeout: {t:?}")),
            },
            None => self.do_drain_request_body().await,
        }
    }

    /// Whether there is no (more) body to be read.
    pub fn is_body_done(&mut self) -> bool {
        self.init_body_reader();
        self.body_reader.body_done()
    }

    /// Whether the request has an empty body
    /// Because HTTP 1.1 clients have to send either `Content-Length` or `Transfer-Encoding` in order
    /// to signal the server that it will send the body, this function returns accurate results even
    /// only when the request header is just read.
    pub fn is_body_empty(&mut self) -> bool {
        self.init_body_reader();
        self.body_reader.body_empty()
    }

    /// Write the response header to the client.
    /// This function can be called more than once to send 1xx informational headers excluding 101.
    pub async fn write_response_header(&mut self, mut header: Box<ResponseHeader>) -> Result<()> {
        // Prepare header (handle upgrades, set headers, initialize body writer, serialize to bytes)
        let Some((write_buf, flush)) = self.prepare_response_header(&mut header)? else {
            // Header already sent or should be ignored
            return Ok(());
        };

        match self.underlying_stream.write_all(&write_buf).await {
            Ok(()) => {
                // flush the stream if 1xx header or there is no response body
                if flush || self.body_writer.finished() {
                    self.underlying_stream
                        .flush()
                        .await
                        .or_err(WriteError, "flushing response header")?;
                }
                self.response_written = Some(header);
                Ok(())
            }
            Err(e) => Error::e_because(WriteError, "writing response header", e),
        }
    }

    /// Return the response header if it is already sent.
    pub fn response_written(&self) -> Option<&ResponseHeader> {
        self.response_written.as_deref()
    }

    /// `Some(true)` if the this is a successful upgrade
    /// `Some(false)` if the request is an upgrade but the response refuses it
    /// `None` if the request is not an upgrade.
    pub fn is_upgrade(&self, header: &ResponseHeader) -> Option<bool> {
        if self.is_upgrade_req() {
            Some(is_upgrade_resp(header))
        } else {
            None
        }
    }

    /// Was this request successfully turned into an upgraded connection?
    ///
    /// Both the request had to have been an `Upgrade` request
    /// and the response had to have been a `101 Switching Protocols`.
    pub fn was_upgraded(&self) -> bool {
        self.upgraded
    }

    fn set_keepalive(&mut self, seconds: Option<u64>) {
        match seconds {
            Some(sec) => {
                if sec > 0 {
                    self.keepalive_timeout = KeepaliveStatus::Timeout(Duration::from_secs(sec));
                } else {
                    self.keepalive_timeout = KeepaliveStatus::Infinite;
                }
            }
            None => {
                self.keepalive_timeout = KeepaliveStatus::Off;
            }
        }
    }

    pub fn get_keepalive_timeout(&self) -> Option<u64> {
        match self.keepalive_timeout {
            KeepaliveStatus::Timeout(d) => Some(d.as_secs()),
            KeepaliveStatus::Infinite => Some(0),
            KeepaliveStatus::Off => None,
        }
    }

    pub fn set_keepalive_reuses_remaining(&mut self, remaining: Option<u32>) {
        self.keepalive_reuses_remaining = remaining;
    }

    pub fn get_keepalive_reuses_remaining(&self) -> Option<u32> {
        self.keepalive_reuses_remaining
    }

    /// Set user-defined context to carry across requests on the same keepalive connection.
    ///
    /// This is typically called by
    /// [`HttpPersistentSettings::apply_to_session`](crate::apps::HttpPersistentSettings::apply_to_session)
    /// during the keepalive reuse loop. The proxy layer consumes it via
    /// [`take_connection_user_context`](Self::take_connection_user_context).
    pub fn set_connection_user_context(&mut self, ctx: Option<Box<dyn Any + Send + Sync>>) {
        self.connection_user_context = ctx;
    }

    /// Take the user-defined context from the previous request on this keepalive connection.
    ///
    /// Returns `None` if this is the first request on the connection or if no context was
    /// persisted by the previous request.
    pub fn take_connection_user_context(&mut self) -> Option<Box<dyn Any + Send + Sync>> {
        self.connection_user_context.take()
    }

    /// Return whether the session will be keepalived for connection reuse.
    pub fn will_keepalive(&self) -> bool {
        !matches!(
            (&self.keepalive_timeout, self.keepalive_reuses_remaining),
            (KeepaliveStatus::Off, _) | (_, Some(0))
        )
    }

    // `Keep-Alive: timeout=5, max=1000` => 5, 1000
    fn get_keepalive_values(&self) -> (Option<u64>, Option<usize>) {
        // TODO: implement this parsing
        (None, None)
    }

    fn ignore_info_resp(&self, status: u16) -> bool {
        // ignore informational response if ignore flag is set and it's not an Upgrade and Expect: 100-continue isn't set
        self.ignore_info_resp && status != 101 && !(status == 100 && self.is_expect_continue_req())
    }

    fn is_expect_continue_req(&self) -> bool {
        match self.request_header.as_deref() {
            Some(req) => is_expect_continue_req(req),
            None => false,
        }
    }

    fn is_connection_keepalive(&self) -> Option<bool> {
        is_buf_keepalive(self.get_header(header::CONNECTION))
    }

    // calculate write timeout from min_send_rate if set, otherwise return write_timeout
    fn write_timeout(&self, buf_len: usize) -> Option<Duration> {
        let Some(min_send_rate) = self.min_send_rate.filter(|r| *r > 0) else {
            return self.write_timeout;
        };

        // min timeout is 1s
        let ms = (buf_len.max(min_send_rate) as f64 / min_send_rate as f64) * 1000.0;
        // truncates unrealistically large values (we'll be out of memory before this happens)
        Some(Duration::from_millis(ms as u64))
    }

    /// Apply keepalive settings according to the client
    /// For HTTP 1.1, assume keepalive as long as there is no `Connection: Close` request header.
    /// For HTTP 1.0, only keepalive if there is an explicit header `Connection: keep-alive`.
    pub fn respect_keepalive(&mut self) {
        if let Some(keepalive) = self.is_connection_keepalive() {
            if keepalive {
                let (timeout, _max_use) = self.get_keepalive_values();
                // TODO: respect max_use
                match timeout {
                    Some(d) => self.set_keepalive(Some(d)),
                    None => self.set_keepalive(Some(0)), // infinite
                }
            } else {
                self.set_keepalive(None);
            }
        } else if self.req_header().version == Version::HTTP_11 {
            self.set_keepalive(Some(0)); // on by default for http 1.1
        } else {
            self.set_keepalive(None); // off by default for http 1.0
        }
    }

    /// Prepare response header for writing: handle upgrades, set headers, initialize body writer.
    /// This contains all the synchronous logic that should happen before writing the header.
    /// Returns Ok(Some((bytes, should_flush))) if the header should be written, Ok(None) if should skip.
    fn prepare_response_header(
        &mut self,
        header: &mut ResponseHeader,
    ) -> Result<Option<(Bytes, bool)>> {
        // Check if we should ignore informational responses
        if header.status.is_informational() && self.ignore_info_resp(header.status.into()) {
            debug!("ignoring informational headers");
            return Ok(None);
        }

        // Check if we already sent a response header
        if let Some(ref resp) = self.response_written {
            if !resp.status.is_informational() || self.upgraded {
                warn!("Respond header is already sent, cannot send again");
                return Ok(None);
            }
        }

        // if body unfinished, or request header was not finished reading
        if self.close_on_response_before_downstream_finish
            && (self.request_header.is_none() || !self.is_body_done())
        {
            debug!("set connection close before downstream finish");
            self.set_keepalive(None);
        }

        // no need to add these headers to 1xx responses
        if !header.status.is_informational() && self.update_resp_headers {
            /* update headers */
            header.insert_header(header::DATE, date::get_cached_date())?;

            // TODO: make these lazy static
            let connection_value = if self.will_keepalive() {
                "keep-alive"
            } else {
                "close"
            };
            header.insert_header(header::CONNECTION, connection_value)?;
        }

        if header.status == 101 {
            // make sure the connection is closed at the end when 101/upgrade is used
            self.set_keepalive(None);
        }

        // Allow informational header (excluding 101) to pass through without affecting the state
        // of the request
        if header.status == 101 || !header.status.is_informational() {
            // reset request body to done for incomplete upgrade handshakes
            if let Some(upgrade_ok) = self.is_upgrade(header) {
                if upgrade_ok {
                    debug!("ok upgrade handshake");
                    // For ws we use HTTP1_0 do_read_body_until_closed
                    //
                    // On ws close the initiator sends a close frame and
                    // then waits for a response from the peer, once it receives
                    // a response it closes the conn. After receiving a
                    // control frame indicating the connection should be closed,
                    // a peer discards any further data received.
                    // https://www.rfc-editor.org/rfc/rfc6455#section-1.4
                    self.upgraded = true;
                    // Now that the upgrade was successful, we need to change
                    // how we interpret the rest of the body as pass-through.
                    if self.body_reader.need_init() {
                        self.init_body_reader();
                    } else {
                        // already initialized
                        // immediately start reading the rest of the body as upgraded
                        // (in practice most upgraded requests shouldn't have any body)
                        //
                        // TODO: https://datatracker.ietf.org/doc/html/rfc9110#name-upgrade
                        // the most spec-compliant behavior is to switch interpretation
                        // after sending the former body,
                        // we immediately switch interpretation to match nginx
                        self.body_reader.convert_to_close_delimited();
                    }
                } else {
                    // this was a request that requested Upgrade,
                    // but upstream did not comply
                    debug!("bad upgrade handshake!");
                    // continue to read body as-is, this is now just a regular request
                }
            }
            self.init_body_writer(header);
        }

        // Defense-in-depth: if response body is close-delimited, mark session
        // as un-reusable
        if self.body_writer.is_close_delimited() {
            self.set_keepalive(None);
        }

        // Serialize header to bytes
        let mut write_buf = BytesMut::with_capacity(INIT_HEADER_BUF_SIZE);
        http_resp_header_to_buf(header, &mut write_buf)
            .map_err(|_| Error::explain(WriteError, "serializing response header"))?;

        // Determine if we should flush
        // Don't have to flush response with content length because it is less
        // likely to be real time communication. So do flush when
        // 1. 1xx response: client needs to see it before the rest of response
        // 2. No content length: the response could be generated in real time
        let should_flush = header.status.is_informational()
            || header.headers.get(header::CONTENT_LENGTH).is_none();

        Ok(Some((write_buf.freeze(), should_flush)))
    }

    fn init_body_writer(&mut self, header: &ResponseHeader) {
        use http::StatusCode;
        /* the following responses don't have body 204, 304, and HEAD */
        if matches!(
            header.status,
            StatusCode::NO_CONTENT | StatusCode::NOT_MODIFIED
        ) || self.get_method() == Some(&Method::HEAD)
        {
            self.body_writer.init_content_length(0);
            return;
        }

        if header.status.is_informational() && header.status != StatusCode::SWITCHING_PROTOCOLS {
            // 1xx response, not enough to init body
            return;
        }

        if self.is_upgrade(header) == Some(true) {
            self.body_writer.init_close_delimited();
        } else {
            init_body_writer_comm(&mut self.body_writer, &header.headers);
        }
    }

    /// Same as [`Self::write_response_header()`] but takes a reference.
    pub async fn write_response_header_ref(&mut self, resp: &ResponseHeader) -> Result<()> {
        self.write_response_header(Box::new(resp.clone())).await
    }

    async fn do_write_body(&mut self, buf: &[u8]) -> Result<Option<usize>> {
        let written = self
            .body_writer
            .write_body(&mut self.underlying_stream, buf)
            .await;

        if let Ok(Some(num_bytes)) = written {
            self.body_bytes_sent += num_bytes;
        }

        written
    }

    /// Write response body to the client. Return `Ok(None)` when there shouldn't be more body
    /// to be written, e.g., writing more bytes than what the `Content-Length` header suggests
    pub async fn write_body(&mut self, buf: &[u8]) -> Result<Option<usize>> {
        // TODO: check if the response header is written
        match self.write_timeout(buf.len()) {
            Some(t) => match timeout(t, self.do_write_body(buf)).await {
                Ok(res) => res,
                Err(_) => Error::e_explain(WriteTimedout, format!("writing body, timeout: {t:?}")),
            },
            None => self.do_write_body(buf).await,
        }
    }

    /// Whether the cancel-safe proxy task API is enabled for this session.
    pub fn proxy_tasks_enabled(&self) -> bool {
        self.proxy_tasks_enabled
    }

    /// Enable or disable the cancel-safe proxy task API for this session.
    pub fn set_proxy_tasks_enabled(&mut self, enabled: bool) {
        self.proxy_tasks_enabled = enabled;
    }

    /// Whether HTTP/1.1 request pipelining is enabled for this session.
    pub fn pipelining_enabled(&self) -> bool {
        self.pipelining_enabled
    }

    /// Enable or disable HTTP/1.1 request pipelining on this session.
    ///
    /// When enabled, if the client pipelines requests on a single keep-alive
    /// connection (sends request N+1 before reading response N), the proxy will
    /// serve each request sequentially with responses in request order as
    /// required by RFC 9112 §9.3.2. Each pipelined request still goes through
    /// independent upstream selection; only the downstream connection is reused.
    ///
    /// When disabled (default), pipelined bytes received alongside request N
    /// cause the session to be marked un-reusable: response N is still
    /// delivered, the connection closes, and request N+1 is dropped. Clients
    /// are expected to detect the close and retry on a fresh connection per
    /// RFC 9112 §9.3.2.
    ///
    /// Sequential dispatch only: response N must be fully written before
    /// request N+1 begins processing. No parallel pipelining.
    pub fn set_pipelining_enabled(&mut self, enabled: bool) {
        self.pipelining_enabled = enabled;
    }

    /// Set pipelined bytes to be parsed as the start of this session's request.
    ///
    /// Called by the proxy layer when continuing a keep-alive connection whose
    /// previous session yielded overread bytes. The prefix is consumed on the
    /// first [`Self::read_request`] call; the parser treats the prefix + any
    /// further stream reads as the next request's header + body bytes.
    pub fn set_pipelined_prefix(&mut self, prefix: BytesMut) {
        debug_assert!(
            self.pipelined_prefix.is_none(),
            "pipelined prefix already set"
        );
        self.pipelined_prefix = Some(prefix);
    }

    /// Take ownership of bytes read past the end of this session's request
    /// body. When non-empty, those bytes are the start of a pipelined
    /// follow-up request on the same keep-alive connection and should be
    /// fed to the next session via [`Self::set_pipelined_prefix`].
    ///
    /// Returns `None` when no overread is present. After this call, the
    /// session's body-reader no longer holds the bytes.
    pub(crate) fn take_body_overread(&mut self) -> Option<BytesMut> {
        self.body_reader.take_body_overread()
    }

    async fn do_write_body_buf(&mut self) -> Result<Option<usize>> {
        // Don't flush empty chunks, they are considered end of body for chunks
        if self.body_write_buf.is_empty() {
            return Ok(None);
        }

        let written = self
            .body_writer
            .write_body(&mut self.underlying_stream, &self.body_write_buf)
            .await;

        if let Ok(Some(num_bytes)) = written {
            self.body_bytes_sent += num_bytes;
        }

        // make sure this buf is safe to reuse
        self.body_write_buf.clear();

        written
    }

    async fn write_body_buf(&mut self) -> Result<Option<usize>> {
        match self.write_timeout(self.body_write_buf.len()) {
            Some(t) => match timeout(t, self.do_write_body_buf()).await {
                Ok(res) => res,
                Err(_) => Error::e_explain(WriteTimedout, format!("writing body, timeout: {t:?}")),
            },
            None => self.do_write_body_buf().await,
        }
    }

    fn maybe_force_close_body_reader(&mut self) {
        if self.upgraded && !self.body_reader.body_done() {
            // response is done, reset the request body to close
            self.body_reader.init_content_length(0, b"");
        }
    }

    /// Signal that there is no more body to write.
    /// This call will try to flush the buffer if there is any un-flushed data.
    /// For chunked encoding response, this call will also send the last chunk.
    /// For upgraded sessions, this call will also close the reading of the client body.
    pub async fn finish_body(&mut self) -> Result<Option<usize>> {
        let res = self.body_writer.finish(&mut self.underlying_stream).await?;
        self.underlying_stream
            .flush()
            .await
            .or_err(WriteError, "flushing body")?;

        trace!(
            "finish body (response body writer), upgraded: {}",
            self.upgraded
        );
        self.maybe_force_close_body_reader();
        Ok(res)
    }

    /// Return how many response body bytes (application, not wire) already sent downstream
    pub fn body_bytes_sent(&self) -> usize {
        self.body_bytes_sent
    }

    /// Return how many request body bytes (application, not wire) already read from downstream
    pub fn body_bytes_read(&self) -> usize {
        self.body_bytes_read
    }

    fn is_chunked_encoding(&self) -> bool {
        is_chunked_encoding_from_headers(&self.req_header().headers)
    }

    fn get_content_length(&self) -> Result<Option<usize>> {
        content_length_for_framing(&self.req_header().headers)
    }

    fn init_body_reader(&mut self) {
        if self.body_reader.need_init() {
            // reset retry buffer
            if let Some(buffer) = self.retry_buffer.as_mut() {
                buffer.clear();
            }

            // follow https://datatracker.ietf.org/doc/html/rfc9112#section-6.3
            let preread_body = self.preread_body.take().unwrap_or_default();

            if self.was_upgraded() {
                // if upgraded _post_ 101 (and body was not init yet)
                // treat as upgraded body (pass through until closed)
                self.body_reader.init_close_delimited_owned(preread_body);
            } else if self.is_chunked_encoding() {
                // if chunked encoding, content-length should be ignored
                self.body_reader.init_chunked_owned(preread_body);
            } else {
                // At this point, validate_request() should have already been called,
                // so get_content_length() should not return an error for invalid values
                let cl = self.get_content_length().unwrap_or(None);
                match cl {
                    Some(i) => {
                        self.body_reader.init_content_length_owned(i, preread_body);
                    }
                    None => {
                        // https://datatracker.ietf.org/doc/html/rfc9112#section-6.3
                        // "Request messages are never close-delimited because they are
                        // always explicitly framed by length or transfer coding, with the absence of
                        // both implying the request ends immediately after the header section."
                        self.body_reader.init_content_length_owned(0, preread_body);
                    }
                }
            }
        }
    }

    pub fn retry_buffer_truncated(&self) -> bool {
        self.retry_buffer
            .as_ref()
            .map_or_else(|| false, |r| r.is_truncated())
    }

    pub fn enable_retry_buffering(&mut self) {
        if self.retry_buffer.is_none() {
            self.retry_buffer = Some(FixedBuffer::new(BODY_BUF_LIMIT))
        }
    }

    pub fn get_retry_buffer(&self) -> Option<Bytes> {
        self.retry_buffer.as_ref().and_then(|b| {
            if b.is_truncated() {
                None
            } else {
                b.get_buffer()
            }
        })
    }

    fn get_body(&self, buf_ref: &BufRef) -> &[u8] {
        // TODO: these get_*() could panic. handle them better
        self.body_reader.get_body(buf_ref)
    }

    /// This function will (async) block forever until the client closes the connection.
    pub async fn idle(&mut self) -> Result<usize> {
        // OpenSSL read requires a non-empty buffer. Keep this probe at one byte
        // so idle-style reads consume at most one byte before returning control.
        self.read_idle_probe("during HTTP idle state")
            .await
            .map(|(_, read)| read)
    }

    async fn read_idle_probe(&mut self, context: &'static str) -> Result<([u8; 1], usize)> {
        let mut probe = [0; 1];
        let read = self
            .underlying_stream
            .read(&mut probe)
            .await
            .or_err(ReadError, context)?;
        Ok((probe, read))
    }

    /// This function will return body bytes (same as [`Self::read_body_bytes()`]), but after
    /// the client body finishes (`Ok(None)` is returned), calling this function again will block
    /// forever, same as [`Self::idle()`].
    ///
    /// By default (`abort_on_close = true`), if the client closes the connection
    /// (sends TCP FIN, i.e. `read == 0`) after the request body is complete, a
    /// `ConnectionClosed` error is returned.
    ///
    /// When `abort_on_close` is **disabled**, the close is tolerated: the future stays
    /// pending so the proxy can finish delivering the upstream response via the write
    /// path (per RFC 9112 Section 9.6). A true disconnect (RST) will be caught later
    /// when the response write fails.
    ///
    /// Note that this marks the connection as half-closed if FIN is detected. If this function
    /// is called after the connection is already marked half-closed and `abort_on_close` is
    /// **disabled**, then it will pend forever.
    pub async fn read_body_or_idle(&mut self, no_body_expected: bool) -> Result<Option<Bytes>> {
        if no_body_expected || self.is_body_done() {
            if self.half_closed {
                if self.abort_on_close {
                    return Error::e_explain(
                        ConnectionClosed,
                        if self.response_written.is_none() {
                            "Prematurely before response header is sent"
                        } else {
                            "Prematurely before response body is complete"
                        },
                    );
                }
                return std::future::pending().await;
            }
            // When pipelining is enabled and an earlier idle read already
            // stashed the next request's bytes as overread, any further
            // poll of this function on the same request must not read
            // the stream again (the proxy's body-pump `select!` loop
            // will call back into here repeatedly until its other
            // branches resolve the request). Go straight to pending.
            // `abort_on_close` and the FIN handling above stay untouched
            // — this branch is exclusive to the pipelining case where
            // bytes (not FIN) arrived on the idle poll.
            if self.pipelining_enabled && self.pipelined_idle_bytes_stashed {
                return std::future::pending().await;
            }
            // XXX: account for upgraded body reader change, if the read half split from the write half
            let (probe, read) = self
                .read_idle_probe("during HTTP body-or-idle state")
                .await?;
            if read == 0 {
                self.half_closed = true;
                self.set_keepalive(None);
                if self.abort_on_close {
                    Error::e_explain(
                        ConnectionClosed,
                        if self.response_written.is_none() {
                            "Prematurely before response header is sent"
                        } else {
                            "Prematurely before response body is complete"
                        },
                    )
                } else {
                    debug!("downstream closed (FIN), keeping write side open");
                    // If the connection is fully closed, writing the response side
                    // will fail.
                    std::future::pending().await
                }
            } else if self.pipelining_enabled {
                // The read bytes are the start of a pipelined next
                // request on this keep-alive connection (RFC 9112
                // §9.3.2). Stash them on the body reader's overread
                // surface so the existing `take_body_overread` +
                // `HttpPersistentSettings` extraction path picks them
                // up at `reuse()` time and feeds them to the next
                // session via `set_pipelined_prefix`.
                //
                // Returning pending (rather than `Ok(None)` or an
                // error) signals the body-pump `tokio::select!` loop
                // that the downstream has no more body work to do on
                // this request — the loop exits naturally via the
                // upstream-response-done / response-write-done
                // branches, and `finish()` runs its standard pipelining
                // extraction. The read == 0 FIN path above is unchanged; this
                // branch only handles a non-zero idle read that belongs to the
                // next pipelined request, so it leaves `half_closed` and
                // `abort_on_close` untouched.
                // Keep the stash and flag update adjacent and synchronous.
                // Once the prefix byte is handed to the overread path, the
                // flag prevents later idle polls for this request from
                // reading the stream again.
                self.body_reader.push_body_overread(&probe[..read]);
                self.pipelined_idle_bytes_stashed = true;
                debug!("pipelined request bytes stashed as overread ({read} bytes)");
                std::future::pending().await
            } else {
                Error::e_explain(ConnectError, "Sent data after end of body")
            }
        } else {
            self.read_body_bytes().await
        }
    }

    /// Whether the client has half-closed the TCP connection.
    pub fn is_half_closed(&self) -> bool {
        self.half_closed
    }

    /// Return the raw bytes of the request header.
    pub fn get_headers_raw_bytes(&self) -> Bytes {
        self.raw_header.as_ref().unwrap().get_bytes(&self.buf)
    }

    /// Close the connection abruptly. This allows to signal the client that the connection is closed
    /// before dropping [`HttpSession`]
    pub async fn shutdown(&mut self) {
        let _ = self.underlying_stream.shutdown().await;
    }

    /// Set the server keepalive timeout.
    /// `None`: disable keepalive, this session cannot be reused.
    /// `Some(0)`: reusing this session is allowed and there is no timeout.
    /// `Some(>0)`: reusing this session is allowed within the given timeout in seconds.
    /// If the client disallows connection reuse, then `keepalive` will be ignored.
    pub fn set_server_keepalive(&mut self, keepalive: Option<u64>) {
        if let Some(false) = self.is_connection_keepalive() {
            // connection: close is set
            self.set_keepalive(None);
        } else {
            self.set_keepalive(keepalive);
        }
    }

    /// Sets the downstream read timeout. This will trigger if we're unable
    /// to read from the stream after `timeout`.
    pub fn set_read_timeout(&mut self, timeout: Option<Duration>) {
        self.read_timeout = timeout;
    }

    /// Gets the downstream read timeout.
    pub fn get_read_timeout(&self) -> Option<Duration> {
        self.read_timeout
    }

    /// Sets the downstream write timeout. This will trigger if we're unable
    /// to write to the stream after `timeout`. If a `min_send_rate` is
    /// configured then the `min_send_rate` calculated timeout has higher priority.
    pub fn set_write_timeout(&mut self, timeout: Option<Duration>) {
        self.write_timeout = timeout;
    }

    /// Gets the downstream write timeout.
    pub fn get_write_timeout(&self) -> Option<Duration> {
        self.write_timeout
    }

    /// Sets the total drain timeout. For HTTP/1.1, reusing a session requires
    /// ensuring that the request body is consumed. This `timeout` will be used
    /// to determine how long to wait for the entirety of the downstream request
    /// body to finish after the upstream response is completed to return the
    /// session to the reuse pool. If the timeout is exceeded, we will give up
    /// on trying to reuse the session.
    ///
    /// Note that the downstream read timeout still applies between body byte reads.
    pub fn set_total_drain_timeout(&mut self, timeout: Option<Duration>) {
        self.total_drain_timeout = timeout;
    }

    /// Get the total drain timeout.
    pub fn get_total_drain_timeout(&self) -> Option<Duration> {
        self.total_drain_timeout
    }

    /// Sets the minimum downstream send rate in bytes per second. This
    /// is used to calculate a write timeout in seconds based on the size
    /// of the buffer being written. If a `min_send_rate` is configured it
    /// has higher priority over a set `write_timeout`. The minimum send
    /// rate must be greater than zero.
    ///
    /// Calculated write timeout is guaranteed to be at least 1s if `min_send_rate`
    /// is greater than zero, a send rate of zero is equivalent to disabling.
    pub fn set_min_send_rate(&mut self, min_send_rate: Option<usize>) {
        if let Some(rate) = min_send_rate.filter(|r| *r > 0) {
            self.min_send_rate = Some(rate);
        } else {
            self.min_send_rate = None;
        }
    }

    /// Sets whether we ignore writing informational responses downstream.
    ///
    /// This is a noop if the response is Upgrade or Continue and
    /// Expect: 100-continue was set on the request.
    pub fn set_ignore_info_resp(&mut self, ignore: bool) {
        self.ignore_info_resp = ignore;
    }

    /// Sets whether keepalive should be disabled if response is written prior to
    /// downstream body finishing.
    ///
    /// This may be set to avoid draining downstream if the body is no longer necessary.
    pub fn set_close_on_response_before_downstream_finish(&mut self, close: bool) {
        self.close_on_response_before_downstream_finish = close;
    }

    /// Controls behaviour when the client closes the connection after the request body.
    ///
    /// When **enabled** (default), a client close is returned as a `ConnectionClosed`
    /// error so the proxy aborts immediately.
    ///
    /// When **disabled**, `read_body_or_idle` stays pending on a client close so the
    /// proxy can finish delivering the upstream response (RFC 9112 Section 9.6). A true
    /// disconnect (RST) will surface later when the response write fails.
    pub fn set_abort_on_close(&mut self, abort: bool) {
        self.abort_on_close = abort;
    }

    /// Return the [Digest] of the connection.
    pub fn digest(&self) -> &Digest {
        &self.digest
    }

    /// Return a mutable [Digest] reference for the connection.
    pub fn digest_mut(&mut self) -> &mut Digest {
        &mut self.digest
    }

    /// Return the client (peer) address of the underlying connection.
    pub fn client_addr(&self) -> Option<&SocketAddr> {
        self.digest()
            .socket_digest
            .as_ref()
            .map(|d| d.peer_addr())?
    }

    /// Return the server (local) address of the underlying connection.
    pub fn server_addr(&self) -> Option<&SocketAddr> {
        self.digest()
            .socket_digest
            .as_ref()
            .map(|d| d.local_addr())?
    }

    /// Consume `self`, if the connection can be reused, the underlying stream and any pipelined
    /// prefix bytes will be returned to be fed to the next [`Self::new()`]. This drains any
    /// remaining request body if it hasn't yet been read and the stream is reusable.
    ///
    /// The next session can just call [`Self::read_request()`].
    ///
    /// If the connection cannot be reused, the underlying stream will be closed and `None` will be
    /// returned. If there was an error while draining any remaining request body that error will
    /// be returned.
    pub async fn reuse(mut self) -> Result<Option<ReusableHttpStream>> {
        if !self.will_keepalive() {
            debug!("HTTP shutdown connection");
            self.shutdown().await;
            Ok(None)
        } else {
            self.drain_request_body().await?;
            if self.body_reader.has_bytes_overread() && !self.pipelining_enabled {
                debug!("bytes overread on request, disallowing reuse");
                Ok(None)
            } else {
                let pipelined_prefix = self
                    .pipelining_enabled
                    .then(|| self.take_body_overread())
                    .flatten()
                    .filter(|prefix| !prefix.is_empty());
                Ok(Some(ReusableHttpStream::new(
                    self.underlying_stream,
                    pipelined_prefix,
                )))
            }
        }
    }

    /// Write a `100 Continue` response to the client.
    pub async fn write_continue_response(&mut self) -> Result<()> {
        // only send if we haven't already
        if self.response_written.is_none() {
            // size hint Some(0) because default is 8
            return self
                .write_response_header(Box::new(ResponseHeader::build(100, Some(0)).unwrap()))
                .await;
        }
        Ok(())
    }

    async fn write_non_empty_body(&mut self, data: Option<Bytes>, upgraded: bool) -> Result<()> {
        // Both upstream and downstream should agree on upgrade status.
        // Upgrade can only occur if both downstream and upstream sessions are H1.1
        // and see a 101 response, which logically MUST have been received
        // prior to this task.
        if upgraded != self.upgraded {
            if upgraded {
                panic!("Unexpected UpgradedBody task received on un-upgraded downstream session");
            } else {
                panic!("Unexpected Body task received on upgraded downstream session");
            }
        }
        let Some(d) = data else {
            return Ok(());
        };
        if d.is_empty() {
            return Ok(());
        }
        self.write_body(&d).await.map_err(|e| e.into_down())?;
        Ok(())
    }

    async fn response_duplex(&mut self, task: HttpTask) -> Result<bool> {
        let end_stream = match task {
            HttpTask::Header(header, end_stream) => {
                self.write_response_header(header)
                    .await
                    .map_err(|e| e.into_down())?;
                end_stream
            }
            HttpTask::Body(data, end_stream) => {
                self.write_non_empty_body(data, false).await?;
                end_stream
            }
            HttpTask::UpgradedBody(data, end_stream) => {
                self.write_non_empty_body(data, true).await?;
                end_stream
            }
            HttpTask::Trailer(_) => true, // h1 trailer is not supported yet
            HttpTask::Done => true,
            HttpTask::Failed(e) => return Err(e),
        };
        if end_stream {
            // no-op if body wasn't initialized or is finished already
            self.finish_body().await.map_err(|e| e.into_down())?;
        }
        Ok(end_stream || self.body_writer.finished())
    }

    fn buffer_body_data(&mut self, data: Option<Bytes>, upgraded: bool) {
        if upgraded != self.upgraded {
            if upgraded {
                panic!("Unexpected Body task received on upgraded downstream session");
            } else {
                panic!("Unexpected UpgradedBody task received on un-upgraded downstream session");
            }
        }

        let Some(d) = data else {
            return;
        };
        if !d.is_empty() && !self.body_writer.finished() {
            self.body_write_buf.put_slice(&d);
        }
    }

    // TODO: use vectored write to avoid copying
    pub async fn response_duplex_vec(&mut self, mut tasks: Vec<HttpTask>) -> Result<bool> {
        let n_tasks = tasks.len();
        if n_tasks == 1 {
            // fallback to single operation to avoid copy
            return self.response_duplex(tasks.pop().unwrap()).await;
        }

        let mut end_stream = false;
        for task in tasks.into_iter() {
            end_stream = match task {
                HttpTask::Header(header, end_stream) => {
                    self.write_response_header(header)
                        .await
                        .map_err(|e| e.into_down())?;
                    end_stream
                }
                HttpTask::Body(data, end_stream) => {
                    self.buffer_body_data(data, false);
                    end_stream
                }
                HttpTask::UpgradedBody(data, end_stream) => {
                    self.buffer_body_data(data, true);
                    end_stream
                }
                HttpTask::Trailer(_) => true, // h1 trailer is not supported yet
                HttpTask::Done => true,
                HttpTask::Failed(e) => {
                    // flush the data we have and quit
                    self.write_body_buf().await.map_err(|e| e.into_down())?;
                    self.underlying_stream
                        .flush()
                        .await
                        .or_err(WriteError, "flushing response")?;
                    return Err(e);
                }
            }
        }
        self.write_body_buf().await.map_err(|e| e.into_down())?;
        if end_stream {
            // no-op if body wasn't initialized or is finished already
            self.finish_body().await.map_err(|e| e.into_down())?;
        }
        Ok(end_stream || self.body_writer.finished())
    }

    /// Queue a proxy task for cancel-safe writing with the current write_timeout.
    /// The task will be written when `write_proxy_tasks()` is called.
    ///
    /// A write canceled mid-operation can be resumed via `write_proxy_tasks()`.
    pub fn send_proxy_task(&mut self, task: HttpTask) {
        self.proxy_task_state.tasks.push_back(task);
    }

    /// Check if there are pending proxy tasks queued for writing.
    pub fn has_pending_proxy_tasks(&self) -> bool {
        self.proxy_task_state.current_writer.is_some() || !self.proxy_task_state.tasks.is_empty()
    }

    /// Write all queued proxy tasks (response `HttpTask`s from `send_proxy_task`)
    /// in a cancel-safe manner.
    ///
    /// If cancelled mid-write, the next call will resume the in-progress write.
    ///
    /// Returns `Ok(true)` if this was the end of the response stream.
    // Leverages the cancel-safe `HeaderWriter` and `BodyWriter` primitives.
    // TODO: we can do the same for the non-cancel-safe APIs.
    pub async fn write_proxy_tasks(&mut self) -> Result<bool> {
        let mut end_stream = false;

        // TODO: buffer body data like response_duplex_vec
        loop {
            // - Resume any in-progress write
            if let Some(ref writer_state) = self.proxy_task_state.current_writer {
                match writer_state {
                    ProxyTaskWriter::WritingHeader(_, _) => {
                        let _bytes_written = self
                            .proxy_task_state
                            .header_writer()
                            .write_current_header_task(&mut self.underlying_stream)
                            .await
                            .map_err(|e| e.into_down())?;
                    }
                    ProxyTaskWriter::WritingBody(_) => {
                        let written = self
                            .body_writer
                            .write_current_body_task(&mut self.underlying_stream)
                            .await
                            .map_err(|e| e.into_down())?;
                        if let Some(n) = written {
                            self.body_bytes_sent += n;
                        }
                    }
                    ProxyTaskWriter::FinishingBody => {
                        self.body_writer
                            .write_current_finish_task(&mut self.underlying_stream)
                            .await
                            .map_err(|e| e.into_down())?;
                    }
                }

                match self
                    .proxy_task_state
                    .current_writer
                    .take()
                    .expect("writer state present")
                {
                    ProxyTaskWriter::WritingHeader(header, end) => {
                        self.response_written = Some(header);
                        end_stream = end;
                    }
                    ProxyTaskWriter::WritingBody(end) => {
                        end_stream = end;
                    }
                    ProxyTaskWriter::FinishingBody => {
                        end_stream = true;
                        self.maybe_force_close_body_reader();
                        break; // fine to break after finish, no tasks should be queued after
                    }
                }
                continue;
            }

            // - Send tasks, set state.
            // Pop next task
            let Some(task) = self.proxy_task_state.tasks.pop_front() else {
                if end_stream {
                    self.body_writer.send_finish_task();
                    self.proxy_task_state.current_writer = Some(ProxyTaskWriter::FinishingBody);
                    continue;
                }
                break;
            };

            match task {
                HttpTask::Header(mut header, end) => {
                    let Some((write_buf, should_flush)) =
                        self.prepare_response_header(&mut header)?
                    else {
                        end_stream = end;
                        continue;
                    };
                    // header only responses will want to flush
                    let flush = should_flush || self.body_writer.finished();
                    self.proxy_task_state
                        .header_writer()
                        .send_header_task(write_buf, flush, None);
                    self.proxy_task_state.current_writer =
                        Some(ProxyTaskWriter::WritingHeader(header, end));
                }
                HttpTask::Body(ref data, end) => {
                    if self.upgraded {
                        panic!("Unexpected Body task received on upgraded downstream session");
                    }
                    if let Some(d) = data.as_ref() {
                        if !d.is_empty() {
                            let body_timeout = self.write_timeout(d.len());
                            self.body_writer.send_body_task(d.clone(), body_timeout);
                            self.proxy_task_state.current_writer =
                                Some(ProxyTaskWriter::WritingBody(end));
                            continue;
                        }
                    }
                    end_stream = end;
                }
                HttpTask::UpgradedBody(ref data, end) => {
                    if !self.upgraded {
                        panic!("Unexpected UpgradedBody task received on un-upgraded downstream session");
                    }
                    if let Some(d) = data.as_ref() {
                        if !d.is_empty() {
                            let body_timeout = self.write_timeout(d.len());
                            self.body_writer.send_body_task(d.clone(), body_timeout);
                            self.proxy_task_state.current_writer =
                                Some(ProxyTaskWriter::WritingBody(end));
                            continue;
                        }
                    }
                    end_stream = end;
                }
                HttpTask::Trailer(_) | HttpTask::Done => {
                    end_stream = true;
                }
                HttpTask::Failed(e) => {
                    return Err(e);
                }
            }
        }

        Ok(end_stream || self.body_writer.finished())
    }

    /// Get the reference of the [Stream] that this HTTP session is operating upon.
    pub fn stream(&self) -> &Stream {
        &self.underlying_stream
    }

    /// Consume `self`, the underlying stream will be returned and can be used
    /// directly, for example, in the case of HTTP upgrade. The stream is not
    /// flushed prior to being returned.
    pub fn into_inner(self) -> Stream {
        self.underlying_stream
    }
}

// Regex to parse request line that has illegal chars in it
static REQUEST_LINE_REGEX: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^\w+ (?P<uri>.+) HTTP/\d(?:\.\d)?").unwrap());

// the chars httparse considers illegal in URL
// Almost https://url.spec.whatwg.org/#query-percent-encode-set + {}
const URI_ESC_CHARSET: &AsciiSet = &CONTROLS.add(b' ').add(b'<').add(b'>').add(b'"');

fn escape_illegal_request_line(buf: &BytesMut) -> Option<BytesMut> {
    if let Some(captures) = REQUEST_LINE_REGEX.captures(buf) {
        // return if nothing matches: not a request line at all
        let uri = captures.name("uri")?;

        let escaped_uri = percent_encode(uri.as_bytes(), URI_ESC_CHARSET);

        // rebuild the entire request buf in a new buffer
        // TODO: this might be able to be done in place

        // need to be slightly bigger than the current buf;
        let mut new_buf = BytesMut::with_capacity(buf.len() + 32);
        new_buf.extend_from_slice(&buf[..uri.start()]);

        for s in escaped_uri {
            new_buf.extend_from_slice(s.as_bytes());
        }

        if new_buf.len() == uri.end() {
            // buf unchanged, nothing is escaped, return None to avoid loop
            return None;
        }

        new_buf.extend_from_slice(&buf[uri.end()..]);

        Some(new_buf)
    } else {
        None
    }
}

#[inline]
fn parse_req_buffer<'buf>(
    req: &mut httparse::Request<'_, 'buf>,
    buf: &'buf [u8],
) -> HeaderParseState {
    use httparse::Result;

    #[cfg(feature = "patched_http1")]
    fn parse<'buf>(req: &mut httparse::Request<'_, 'buf>, buf: &'buf [u8]) -> Result<usize> {
        req.parse_unchecked(buf)
    }

    #[cfg(not(feature = "patched_http1"))]
    fn parse<'buf>(req: &mut httparse::Request<'_, 'buf>, buf: &'buf [u8]) -> Result<usize> {
        req.parse(buf)
    }

    let res = match parse(req, buf) {
        Ok(s) => s,
        Err(e) => {
            return HeaderParseState::Invalid(e);
        }
    };
    match res {
        httparse::Status::Complete(s) => HeaderParseState::Complete(s),
        _ => HeaderParseState::Partial,
    }
}

#[inline]
fn http_resp_header_to_buf(
    resp: &ResponseHeader,
    buf: &mut BytesMut,
) -> std::result::Result<(), ()> {
    // Status-Line
    let version = match resp.version {
        Version::HTTP_09 => "HTTP/0.9 ",
        Version::HTTP_10 => "HTTP/1.0 ",
        Version::HTTP_11 => "HTTP/1.1 ",
        _ => {
            return Err(()); /*TODO: unsupported version */
        }
    };
    buf.put_slice(version.as_bytes());
    let status = resp.status;
    buf.put_slice(status.as_str().as_bytes());
    buf.put_u8(b' ');
    let reason = resp.get_reason_phrase();
    if let Some(reason_buf) = reason {
        buf.put_slice(reason_buf.as_bytes());
    }
    buf.put_slice(CRLF);

    // headers
    // TODO: style: make sure Server and Date headers are the first two
    resp.header_to_h1_wire(buf);

    buf.put_slice(CRLF);
    Ok(())
}

#[cfg(test)]
mod tests_stream {
    use super::*;
    use crate::protocols::http::v1::body::{BodyMode, ParseState};
    use http::StatusCode;
    use pingora_error::ErrorType;
    use rstest::rstest;
    use std::str;
    use tokio_test::io::Builder;

    fn init_log() {
        let _ = env_logger::builder().is_test(true).try_init();
    }

    #[tokio::test]
    async fn read_basic() {
        init_log();
        let input = b"GET / HTTP/1.1\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert_eq!(input.len(), res.unwrap().unwrap());
        assert_eq!(0, http_stream.req_header().headers.len());
    }

    #[cfg(feature = "patched_http1")]
    #[tokio::test]
    async fn read_invalid_path() {
        init_log();
        let input = b"GET /\x01\xF0\x90\x80 HTTP/1.1\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert_eq!(input.len(), res.unwrap().unwrap());
        assert_eq!(0, http_stream.req_header().headers.len());
        assert_eq!(b"/\x01\xF0\x90\x80", http_stream.get_path());
    }

    #[tokio::test]
    async fn read_2_buf() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\n\r\n";
        let mock_io = Builder::new().read(&input1[..]).read(&input2[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert_eq!(input1.len() + input2.len(), res.unwrap().unwrap());
        assert_eq!(
            input1.len() + input2.len(),
            http_stream.raw_header.as_ref().unwrap().len()
        );
        assert_eq!(1, http_stream.req_header().headers.len());
        assert_eq!(Some(&Method::GET), http_stream.get_method());
        assert_eq!(b"/", http_stream.get_path());
        assert_eq!(Version::HTTP_11, http_stream.req_header().version);

        assert_eq!(b"pingora.org", http_stream.get_header_bytes("Host"));
    }

    #[tokio::test]
    async fn read_with_body_content_length() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nContent-Length: 3\r\n\r\n";
        let input3 = b"abc";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, input3.as_slice());
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(3));
        assert_eq!(http_stream.body_bytes_read(), 3);
    }

    #[tokio::test]
    #[should_panic(expected = "There is still data left to read.")]
    async fn read_with_body_timeout() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nContent-Length: 3\r\n\r\n";
        let input3 = b"abc";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .wait(Duration::from_secs(2))
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_timeout = Some(Duration::from_secs(1));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await;
        assert_eq!(http_stream.body_bytes_read(), 0);
        assert_eq!(res.unwrap_err().etype(), &ReadTimedout);
    }

    #[tokio::test]
    async fn read_with_body_content_length_single_read() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nContent-Length: 3\r\n\r\nabc";
        let mock_io = Builder::new().read(&input1[..]).read(&input2[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, b"abc".as_slice());
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(3));
        assert_eq!(http_stream.body_bytes_read(), 3);
    }

    #[tokio::test]
    #[should_panic(expected = "There is still data left to read.")]
    async fn read_with_body_http10() {
        init_log();
        let input1 = b"GET / HTTP/1.0\r\n";
        let input2 = b"Host: pingora.org\r\n\r\n";
        let input3 = b"a"; // This should NOT be read as body
        let input4 = b""; // simulating close - should also NOT be reached
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .read(&input4[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await.unwrap();
        assert!(res.is_none());
        assert_eq!(http_stream.body_bytes_read(), 0);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(0));
    }

    #[tokio::test]
    async fn read_with_body_http10_single_read() {
        init_log();
        // should have 0 body, even when data follows the headers
        let input1 = b"GET / HTTP/1.0\r\n";
        let input2 = b"Host: pingora.org\r\n\r\na";
        let mock_io = Builder::new().read(&input1[..]).read(&input2[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await.unwrap();
        assert!(res.is_none());
        assert_eq!(http_stream.body_bytes_read(), 0);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(0));
        assert_eq!(http_stream.body_reader.get_body_overread().unwrap(), b"a");
    }

    #[tokio::test]
    async fn read_http11_default_no_body() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\n\r\n";
        let mock_io = Builder::new().read(&input1[..]).read(&input2[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await.unwrap();
        assert!(res.is_none());
        assert_eq!(http_stream.body_bytes_read(), 0);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(0));
    }

    #[tokio::test]
    async fn read_http10_with_content_length() {
        init_log();
        let input1 = b"POST / HTTP/1.0\r\n";
        let input2 = b"Host: pingora.org\r\nContent-Length: 3\r\n\r\n";
        let input3 = b"abc";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, input3.as_slice());
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(3));
        assert_eq!(http_stream.body_bytes_read(), 3);
    }

    #[tokio::test]
    async fn read_with_body_chunked_0_incomplete() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n";
        let input3 = b"0\r\n";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_chunked_encoding());
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, b"".as_slice());
        let e = http_stream.read_body_bytes().await.unwrap_err();
        assert_eq!(*e.etype(), ErrorType::ConnectionClosed);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Done(0));
    }

    #[tokio::test]
    async fn read_with_body_chunked_0_extra() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n";
        let input3 = b"0\r\n";
        let input4 = b"abc";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .read(&input4[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_chunked_encoding());
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, b"".as_slice());
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, b"".as_slice());
        let e = http_stream.read_body_bytes().await.unwrap_err();
        assert_eq!(*e.etype(), ErrorType::ConnectionClosed);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Done(0));
    }

    #[tokio::test]
    async fn read_with_body_chunked_single_read() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n1\r\na\r\n";
        let input3 = b"0\r\n\r\n";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_chunked_encoding());
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, b"a".as_slice());
        assert_eq!(
            http_stream.body_reader.body_state,
            ParseState::Chunked(1, 0, 0, 0)
        );
        let res = http_stream.read_body_bytes().await.unwrap();
        assert!(res.is_none());
        assert_eq!(http_stream.body_bytes_read(), 1);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(1));
    }

    #[tokio::test]
    async fn read_with_body_chunked_single_read_extra() {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n1\r\na\r\n";
        let input3 = b"0\r\n\r\nabc";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_chunked_encoding());
        let res = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(res, b"a".as_slice());
        assert_eq!(
            http_stream.body_reader.body_state,
            ParseState::Chunked(1, 0, 0, 0)
        );
        let res = http_stream.read_body_bytes().await.unwrap();
        assert!(res.is_none());
        assert_eq!(http_stream.body_bytes_read(), 1);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(1));
        assert_eq!(http_stream.body_reader.get_body_overread().unwrap(), b"abc");
    }

    #[rstest]
    #[case(None, None)]
    #[case(Some("transfer-encoding"), None)]
    #[case(Some("transfer-encoding"), Some("CONTENT-LENGTH"))]
    #[case(Some("TRANSFER-ENCODING"), Some("CONTENT-LENGTH"))]
    #[case(Some("TRANSFER-ENCODING"), None)]
    #[case(None, Some("CONTENT-LENGTH"))]
    #[case(Some("TRANSFER-ENCODING"), Some("content-length"))]
    #[case(None, Some("content-length"))]
    #[tokio::test]
    async fn transfer_encoding_and_content_length_disallowed(
        #[case] transfer_encoding_header: Option<&str>,
        #[case] content_length_header: Option<&str>,
    ) {
        init_log();
        let input1 = b"GET / HTTP/1.1\r\n";
        let mut input2 = "Host: pingora.org\r\n".to_owned();

        if let Some(transfer_encoding) = transfer_encoding_header {
            input2 += &format!("{transfer_encoding}: chunked\r\n");
        }
        if let Some(content_length) = content_length_header {
            input2 += &format!("{content_length}: 4\r\n")
        }

        input2 += "\r\n3e\r\na\r\n";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(input2.as_bytes())
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let _ = http_stream.read_request().await.unwrap();

        match (content_length_header, transfer_encoding_header) {
            (Some(_) | None, Some(_)) => {
                assert!(http_stream.get_header(TRANSFER_ENCODING).is_some());
                assert!(http_stream.get_header(CONTENT_LENGTH).is_none());
            }
            (Some(_), None) => {
                assert!(http_stream.get_header(TRANSFER_ENCODING).is_none());
                assert!(http_stream.get_header(CONTENT_LENGTH).is_some());
            }
            _ => {
                assert!(http_stream.get_header(CONTENT_LENGTH).is_none());
                assert!(http_stream.get_header(TRANSFER_ENCODING).is_none());
            }
        }
    }

    #[rstest]
    #[case::negative("-1")]
    #[case::not_a_number("abc")]
    #[case::float("1.5")]
    #[case::empty("")]
    #[case::spaces("  ")]
    #[case::mixed("123abc")]
    #[tokio::test]
    async fn validate_request_rejects_invalid_content_length(#[case] invalid_value: &str) {
        init_log();
        let input = format!(
            "POST / HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: {}\r\n\r\n",
            invalid_value
        );
        let mock_io = Builder::new().read(input.as_bytes()).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        // read_request calls validate_request internally, so it should fail here
        let res = http_stream.read_request().await;
        assert!(res.is_err());
        assert_eq!(res.unwrap_err().etype(), &InvalidHTTPHeader);
    }

    #[rstest]
    #[case::valid_zero("0")]
    #[case::valid_small("123")]
    #[case::valid_large("999999")]
    #[tokio::test]
    async fn validate_request_accepts_valid_content_length(#[case] valid_value: &str) {
        init_log();
        let input = format!(
            "POST / HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: {}\r\n\r\n",
            valid_value
        );
        let mock_io = Builder::new().read(input.as_bytes()).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert!(res.is_ok());
    }

    #[tokio::test]
    async fn validate_request_accepts_no_content_length() {
        init_log();
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert!(res.is_ok());
    }

    #[tokio::test]
    #[should_panic(expected = "There is still data left to read.")]
    async fn read_invalid() {
        let input1 = b"GET / HTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\n\r\n";
        let mock_io = Builder::new().read(&input1[..]).read(&input2[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert_eq!(&InvalidHTTPHeader, res.unwrap_err().etype());
    }

    #[tokio::test]
    async fn read_invalid_header_end() {
        let input = b"POST / HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 3\r\r\nConnection: keep-alive\r\n\r\nabc";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let res = http_stream.read_request().await;
        assert_eq!(&InvalidHTTPHeader, res.unwrap_err().etype());
    }

    async fn build_upgrade_req(upgrade: &str, conn: &str) -> HttpSession {
        let input = format!("GET / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: {upgrade}\r\nConnection: {conn}\r\n\r\n");
        let mock_io = Builder::new().read(input.as_bytes()).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        http_stream
    }

    #[tokio::test]
    async fn read_upgrade_req() {
        // http 1.0
        let input = b"GET / HTTP/1.0\r\nHost: pingora.org\r\nUpgrade: websocket\r\nConnection: upgrade\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(!http_stream.is_upgrade_req());

        // different method
        let input = b"POST / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: websocket\r\nConnection: upgrade\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());

        // missing upgrade header
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nConnection: upgrade\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(!http_stream.is_upgrade_req());

        // no connection header
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: WebSocket\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());

        assert!(build_upgrade_req("websocket", "Upgrade")
            .await
            .is_upgrade_req());

        // mixed case
        assert!(build_upgrade_req("WebSocket", "Upgrade")
            .await
            .is_upgrade_req());
    }

    const POST_CL_UPGRADE_REQ: &[u8] = b"POST / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: websocket\r\nConnection: upgrade\r\nContent-Length: 10\r\n\r\n";
    const POST_BODY_DATA: &[u8] = b"abcdefghij";
    const POST_CHUNKED_UPGRADE_REQ: &[u8] = b"POST / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: websocket\r\nConnection: upgrade\r\nTransfer-Encoding: chunked\r\n\r\n";
    const POST_BODY_DATA_CHUNKED: &[u8] = b"3\r\nabc\r\n7\r\ndefghij\r\n0\r\n\r\n";

    #[rstest]
    #[case::content_length(POST_CL_UPGRADE_REQ, POST_BODY_DATA, POST_BODY_DATA)]
    #[case::chunked(POST_CHUNKED_UPGRADE_REQ, POST_BODY_DATA, POST_BODY_DATA_CHUNKED)]
    #[tokio::test]
    async fn read_upgrade_req_with_body(
        #[case] header: &[u8],
        #[case] body: &[u8],
        #[case] body_wire: &[u8],
    ) {
        let ws_data = b"data";
        let mock_io = Builder::new()
            .read(header)
            .read(body_wire)
            .write(b"HTTP/1.1 101 Switching Protocols\r\n\r\n")
            .read(&ws_data[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());
        // request has body
        assert!(!http_stream.is_body_done());

        let mut buf = vec![];
        while let Some(b) = http_stream.read_body_bytes().await.unwrap() {
            buf.put_slice(&b);
        }
        assert_eq!(buf, body);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(10));
        assert_eq!(http_stream.body_bytes_read(), 10);

        assert!(http_stream.is_body_done());

        let mut response = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();
        // body reader type switches
        assert!(!http_stream.is_body_done());

        // now the ws data
        let buf = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(buf, ws_data.as_slice());
        assert!(!http_stream.is_body_done());

        // EOF ends body
        assert!(http_stream.read_body_bytes().await.unwrap().is_none());
        assert!(http_stream.is_body_done());
    }

    #[rstest]
    #[case::content_length(POST_CL_UPGRADE_REQ, POST_BODY_DATA, POST_BODY_DATA)]
    #[case::chunked(POST_CHUNKED_UPGRADE_REQ, POST_BODY_DATA, POST_BODY_DATA_CHUNKED)]
    #[tokio::test]
    async fn read_upgrade_req_with_body_extra(
        #[case] header: &[u8],
        #[case] body: &[u8],
        #[case] body_wire: &[u8],
    ) {
        let ws_data = b"data";
        let data_wire = [body_wire, ws_data.as_slice()].concat();
        let mock_io = Builder::new()
            .read(header)
            .read(&data_wire[..])
            .write(b"HTTP/1.1 101 Switching Protocols\r\n\r\n")
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());
        // request has body
        assert!(!http_stream.is_body_done());

        let mut buf = vec![];
        while let Some(b) = http_stream.read_body_bytes().await.unwrap() {
            buf.put_slice(&b);
        }
        assert_eq!(buf, body);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(10));
        assert_eq!(http_stream.body_bytes_read(), 10);

        assert!(http_stream.is_body_done());

        let mut response = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();
        // body reader type switches
        assert!(!http_stream.is_body_done());

        // now the ws data
        let buf = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(buf, ws_data.as_slice());
        assert!(!http_stream.is_body_done());

        // EOF ends body
        assert!(http_stream.read_body_bytes().await.unwrap().is_none());
        assert!(http_stream.is_body_done());
    }

    #[rstest]
    #[case::content_length(POST_CL_UPGRADE_REQ, POST_BODY_DATA, POST_BODY_DATA)]
    #[case::chunked(POST_CHUNKED_UPGRADE_REQ, POST_BODY_DATA, POST_BODY_DATA_CHUNKED)]
    #[tokio::test]
    async fn read_upgrade_req_with_preread_body(
        #[case] header: &[u8],
        #[case] body: &[u8],
        #[case] body_wire: &[u8],
    ) {
        let ws_data = b"data";
        let data_wire = [header, body_wire, ws_data.as_slice()].concat();
        let mock_io = Builder::new()
            .read(&data_wire[..])
            .write(b"HTTP/1.1 101 Switching Protocols\r\n\r\n")
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());
        // request has body
        assert!(!http_stream.is_body_done());

        let mut buf = vec![];
        while let Some(b) = http_stream.read_body_bytes().await.unwrap() {
            buf.put_slice(&b);
        }
        assert_eq!(buf, body);
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(10));
        assert_eq!(http_stream.body_bytes_read(), 10);

        assert!(http_stream.is_body_done());

        let mut response = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();
        // body reader type switches
        assert!(!http_stream.is_body_done());

        // now the ws data
        let buf = http_stream.read_body_bytes().await.unwrap().unwrap();
        assert_eq!(buf, ws_data.as_slice());
        assert!(!http_stream.is_body_done());

        // EOF ends body
        assert!(http_stream.read_body_bytes().await.unwrap().is_none());
        assert!(http_stream.is_body_done());
    }

    #[rstest]
    #[case::content_length(POST_CL_UPGRADE_REQ, POST_BODY_DATA)]
    #[case::chunked(POST_CHUNKED_UPGRADE_REQ, POST_BODY_DATA_CHUNKED)]
    #[tokio::test]
    async fn read_upgrade_req_with_preread_body_after_101(
        #[case] header: &[u8],
        #[case] body_wire: &[u8],
    ) {
        let ws_data = b"data";
        let data_wire = [header, body_wire, ws_data.as_slice()].concat();
        let mock_io = Builder::new()
            .read(&data_wire[..])
            .write(b"HTTP/1.1 101 Switching Protocols\r\n\r\n")
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());
        // request has body
        assert!(!http_stream.is_body_done());

        let mut response = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();
        // body reader type switches to http10
        assert!(!http_stream.is_body_done());

        let mut buf = vec![];
        while let Some(b) = http_stream.read_body_bytes().await.unwrap() {
            buf.put_slice(&b);
        }
        let expected_body = [body_wire, ws_data.as_slice()].concat();
        assert_eq!(buf, expected_body.as_bytes());
        assert_eq!(http_stream.body_bytes_read(), expected_body.len());
        assert!(http_stream.is_body_done());
    }

    #[tokio::test]
    async fn read_upgrade_req_with_1xx_response() {
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: websocket\r\nConnection: upgrade\r\n\r\n";
        let mock_io = Builder::new()
            .read(&input[..])
            .write(b"HTTP/1.1 100 Continue\r\n\r\n")
            .write(b"HTTP/1.1 101 Switching Protocols\r\n\r\n")
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());
        let mut response = ResponseHeader::build(StatusCode::CONTINUE, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();
        // 100 won't affect body state
        // current GET request is done
        assert!(http_stream.is_body_done());

        let mut response = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();
        // body reader type switches
        assert!(!http_stream.is_body_done());
        // EOF ends body
        assert!(http_stream.read_body_bytes().await.unwrap().is_none());
        assert!(http_stream.is_body_done());
    }

    #[tokio::test]
    async fn test_upgrade_without_content_length_with_ws_data() {
        let request = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nUpgrade: websocket\r\nConnection: upgrade\r\n\r\n";
        let ws_data = b"websocket data";

        let mock_io = Builder::new()
            .read(request)
            .write(b"HTTP/1.1 101 Switching Protocols\r\n\r\n")
            .read(ws_data) // websocket data sent after 101
            .build();

        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_upgrade_req());

        // When enabled (default), is_body_done() is called before the upgrade
        http_stream.set_close_on_response_before_downstream_finish(false);

        // Send 101 response - this is where the bug occurs
        let mut response = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response.set_version(http::Version::HTTP_11);
        http_stream
            .write_response_header(Box::new(response))
            .await
            .unwrap();

        assert_eq!(
            http_stream.body_reader.body_state,
            ParseState::UntilClose(0),
            "Body reader should be in UntilClose mode after 101 for upgraded connections"
        );

        // Try to read websocket data
        let mut buf = vec![];
        while let Some(b) = http_stream.read_body_bytes().await.unwrap() {
            buf.put_slice(&b);
        }
        assert_eq!(buf, ws_data, "Expected to read websocket data after 101");
    }

    #[tokio::test]
    async fn set_server_keepalive() {
        // close
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nConnection: close\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        // verify close
        assert_eq!(http_stream.keepalive_timeout, KeepaliveStatus::Off);
        http_stream.set_server_keepalive(Some(60));
        // verify no change on override
        assert_eq!(http_stream.keepalive_timeout, KeepaliveStatus::Off);

        // explicit keep-alive
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nConnection: keep-alive\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        // default is infinite for 1.1
        http_stream.read_request().await.unwrap();
        assert_eq!(http_stream.keepalive_timeout, KeepaliveStatus::Infinite);
        http_stream.set_server_keepalive(Some(60));
        // override respected
        assert_eq!(
            http_stream.keepalive_timeout,
            KeepaliveStatus::Timeout(Duration::from_secs(60))
        );

        // not specified
        let input = b"GET / HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        // default is infinite for 1.1
        assert_eq!(http_stream.keepalive_timeout, KeepaliveStatus::Infinite);
        http_stream.set_server_keepalive(Some(60));
        // override respected
        assert_eq!(
            http_stream.keepalive_timeout,
            KeepaliveStatus::Timeout(Duration::from_secs(60))
        );
    }

    #[tokio::test]
    async fn write() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let write_expected = b"HTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n";
        let mock_io = Builder::new().read(read_wire).write(write_expected).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_custom_reason() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let write_expected = b"HTTP/1.1 200 Just Fine\r\nFoo: Bar\r\n\r\n";
        let mock_io = Builder::new().read(read_wire).write(write_expected).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.set_reason_phrase(Some("Just Fine")).unwrap();
        new_response.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_informational() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let write_expected = b"HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n";
        let mock_io = Builder::new().read(read_wire).write(write_expected).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let response_100 = ResponseHeader::build(StatusCode::CONTINUE, None).unwrap();
        http_stream
            .write_response_header_ref(&response_100)
            .await
            .unwrap();
        let mut response_200 = ResponseHeader::build(StatusCode::OK, None).unwrap();
        response_200.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&response_200)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_informational_ignored() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let write_expected = b"HTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n";
        let mock_io = Builder::new().read(read_wire).write(write_expected).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        // ignore the 100 Continue
        http_stream.ignore_info_resp = true;
        http_stream.read_request().await.unwrap();
        let response_100 = ResponseHeader::build(StatusCode::CONTINUE, None).unwrap();
        http_stream
            .write_response_header_ref(&response_100)
            .await
            .unwrap();
        let mut response_200 = ResponseHeader::build(StatusCode::OK, None).unwrap();
        response_200.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&response_200)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_informational_100_not_ignored_if_expect_continue() {
        let input = b"GET / HTTP/1.1\r\nExpect: 100-continue\r\n\r\n";
        let output = b"HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n";

        let mock_io = Builder::new().read(&input[..]).write(output).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        http_stream.ignore_info_resp = true;
        // 100 Continue is not ignored due to Expect: 100-continue on request
        let response_100 = ResponseHeader::build(StatusCode::CONTINUE, None).unwrap();
        http_stream
            .write_response_header_ref(&response_100)
            .await
            .unwrap();
        let mut response_200 = ResponseHeader::build(StatusCode::OK, None).unwrap();
        response_200.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&response_200)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_informational_1xx_ignored_if_expect_continue() {
        let input = b"GET / HTTP/1.1\r\nExpect: 100-continue\r\n\r\n";
        let output = b"HTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n";

        let mock_io = Builder::new().read(&input[..]).write(output).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        http_stream.ignore_info_resp = true;
        // 102 Processing is ignored
        let response_102 = ResponseHeader::build(StatusCode::PROCESSING, None).unwrap();
        http_stream
            .write_response_header_ref(&response_102)
            .await
            .unwrap();
        let mut response_200 = ResponseHeader::build(StatusCode::OK, None).unwrap();
        response_200.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&response_200)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_101_switching_protocol() {
        let read_wire = b"GET / HTTP/1.1\r\nUpgrade: websocket\r\n\r\n";
        let wire = b"HTTP/1.1 101 Switching Protocols\r\nFoo: Bar\r\n\r\n";
        let wire_body = b"nPAYLOAD";
        let mock_io = Builder::new()
            .read(read_wire)
            .write(wire)
            .write(wire_body)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut response_101 =
            ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, None).unwrap();
        response_101.append_header("Foo", "Bar").unwrap();
        http_stream
            .write_response_header_ref(&response_101)
            .await
            .unwrap();
        assert_eq!(http_stream.body_writer.body_mode, BodyMode::UntilClose(0));

        let n = http_stream.write_body(wire_body).await.unwrap().unwrap();
        assert_eq!(wire_body.len(), n);
        assert_eq!(http_stream.body_writer.body_mode, BodyMode::UntilClose(n));

        // this write should be ignored
        let response_502 = ResponseHeader::build(StatusCode::BAD_GATEWAY, None).unwrap();
        http_stream
            .write_response_header_ref(&response_502)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn write_body_cl() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let wire_header = b"HTTP/1.1 200 OK\r\nContent-Length: 1\r\n\r\n";
        let wire_body = b"a";
        let mock_io = Builder::new()
            .read(read_wire)
            .write(wire_header)
            .write(wire_body)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.append_header("Content-Length", "1").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
        assert_eq!(
            http_stream.body_writer.body_mode,
            BodyMode::ContentLength(1, 0)
        );
        let n = http_stream.write_body(wire_body).await.unwrap().unwrap();
        assert_eq!(wire_body.len(), n);
        let n = http_stream.finish_body().await.unwrap().unwrap();
        assert_eq!(wire_body.len(), n);
    }

    #[tokio::test]
    async fn body_bytes_sent_excludes_response_header() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let wire_header = b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n";
        let wire_body = b"hello";
        let mock_io = Builder::new()
            .read(read_wire)
            .write(wire_header)
            .write(wire_body)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.append_header("Content-Length", "5").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header(Box::new(new_response))
            .await
            .unwrap();
        assert_eq!(http_stream.body_bytes_sent(), 0);
        http_stream.write_body(wire_body).await.unwrap();
        assert_eq!(http_stream.body_bytes_sent(), wire_body.len());
    }

    #[tokio::test]
    async fn write_body_http10() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let wire_header = b"HTTP/1.1 200 OK\r\n\r\n";
        let wire_body = b"a";
        let mock_io = Builder::new()
            .read(read_wire)
            .write(wire_header)
            .write(wire_body)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
        assert_eq!(http_stream.body_writer.body_mode, BodyMode::UntilClose(0));
        let n = http_stream.write_body(wire_body).await.unwrap().unwrap();
        assert_eq!(wire_body.len(), n);
        let n = http_stream.finish_body().await.unwrap().unwrap();
        assert_eq!(wire_body.len(), n);
    }

    #[tokio::test]
    async fn write_body_chunk() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let wire_header = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n";
        let wire_body = b"1\r\na\r\n";
        let wire_end = b"0\r\n\r\n";
        let mock_io = Builder::new()
            .read(read_wire)
            .write(wire_header)
            .write(wire_body)
            .write(wire_end)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response
            .append_header("Transfer-Encoding", "chunked")
            .unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
        assert_eq!(
            http_stream.body_writer.body_mode,
            BodyMode::ChunkedEncoding(0)
        );
        let n = http_stream.write_body(b"a").await.unwrap().unwrap();
        assert_eq!(b"a".len(), n);
        let n = http_stream.finish_body().await.unwrap().unwrap();
        assert_eq!(b"a".len(), n);
    }

    #[tokio::test]
    async fn read_with_illegal() {
        init_log();
        let input1 = b"GET /a?q=b c HTTP/1.1\r\n";
        let input2 = b"Host: pingora.org\r\nContent-Length: 3\r\n\r\n";
        let input3 = b"abc";
        let mock_io = Builder::new()
            .read(&input1[..])
            .read(&input2[..])
            .read(&input3[..])
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert_eq!(http_stream.get_path(), &b"/a?q=b%20c"[..]);
        let res = http_stream.read_body().await.unwrap().unwrap();
        assert_eq!(res, BufRef::new(0, 3));
        assert_eq!(http_stream.body_reader.body_state, ParseState::Complete(3));
        assert_eq!(input3, http_stream.get_body(&res));
    }

    #[tokio::test]
    async fn read_absolute_form_request_target() {
        init_log();
        // RFC 9112 §3.2.2: a server MUST accept absolute-form. The target is kept
        // verbatim, while the Uri exposes only the path component.
        // §3.2.2 requires Host to match the request-target authority; a mismatch is
        // rejected by the ingress authority validation, which this fixture is not
        // exercising.
        let input = b"GET http://pingora.org:8080/a?q=b HTTP/1.1\r\nHost: pingora.org:8080\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert_eq!(
            &b"http://pingora.org:8080/a?q=b"[..],
            http_stream.get_path()
        );
        let uri = &http_stream.req_header().uri;
        assert_eq!("/a", uri.path());
        assert_eq!(Some("q=b"), uri.query());
        // Scheme and authority stay off the Uri so the proxy layer reconciles the
        // target authority against `Host` from the raw bytes.
        assert_eq!(None, uri.authority());
        assert_eq!(None, uri.scheme_str());
    }

    #[tokio::test]
    async fn read_absolute_form_request_target_rejects_host_mismatch() {
        init_log();
        // The fixture above has to keep `Host` and the request-target authority
        // consistent to get past ingress validation. Pin the rejection it relies on, so
        // that agreement stays a deliberate property of the fixture rather than an
        // assumption that could silently stop holding.
        let input = b"GET http://pingora.org:8080/a?q=b HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let err = http_stream.read_request().await.unwrap_err();
        assert_eq!(&InvalidHTTPHeader, err.etype());
        // InvalidHTTPHeader covers every authority rejection, so pin the reason as well.
        assert!(
            format!("{err}").contains("Host header differs from request-target authority"),
            "rejected for the wrong reason: {err}"
        );
    }

    #[tokio::test]
    async fn read_authority_form_request_target() {
        init_log();
        // RFC 9112 §3.2.3: authority-form reaches the tunnel destination verbatim.
        let input = b"CONNECT pingora.org:443 HTTP/1.1\r\nHost: pingora.org:443\r\n\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert_eq!(&b"pingora.org:443"[..], http_stream.get_path());
        assert_eq!(Some(&Method::CONNECT), http_stream.get_method());
    }

    #[test]
    fn escape_illegal() {
        init_log();
        // in query string
        let input = BytesMut::from(
            &b"GET /a?q=<\"b c\"> HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 3\r\n\r\n"[..],
        );
        let output = escape_illegal_request_line(&input).unwrap();
        assert_eq!(
            &output,
            &b"GET /a?q=%3C%22b%20c%22%3E HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 3\r\n\r\n"[..]
        );

        // in path
        let input = BytesMut::from(
            &b"GET /a:\"bc\" HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 3\r\n\r\n"[..],
        );
        let output = escape_illegal_request_line(&input).unwrap();
        assert_eq!(
            &output,
            &b"GET /a:%22bc%22 HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 3\r\n\r\n"[..]
        );

        // empty uri, unable to parse
        let input =
            BytesMut::from(&b"GET  HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 3\r\n\r\n"[..]);
        assert!(escape_illegal_request_line(&input).is_none());
    }

    #[tokio::test]
    async fn test_write_body_buf() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let write_expected = b"HTTP/1.1 200 OK\r\nFoo: Bar\r\n\r\n";
        let mock_io = Builder::new().read(read_wire).write(write_expected).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.append_header("Foo", "Bar").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
        let written = http_stream.write_body_buf().await.unwrap();
        assert!(written.is_none());
    }

    #[tokio::test]
    #[should_panic(expected = "There is still data left to write.")]
    async fn test_write_body_buf_write_timeout() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let wire1 = b"HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\n";
        let wire2 = b"abc";
        let mock_io = Builder::new()
            .read(read_wire)
            .write(wire1)
            .wait(Duration::from_millis(500))
            .write(wire2)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        http_stream.write_timeout = Some(Duration::from_millis(100));
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.append_header("Content-Length", "3").unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header_ref(&new_response)
            .await
            .unwrap();
        http_stream.body_write_buf = BytesMut::from(&b"abc"[..]);
        let res = http_stream.write_body_buf().await;
        assert_eq!(res.unwrap_err().etype(), &WriteTimedout);
    }

    #[tokio::test]
    async fn test_write_continue_resp() {
        let read_wire = b"GET / HTTP/1.1\r\n\r\n";
        let write_expected = b"HTTP/1.1 100 Continue\r\n\r\n";
        let mock_io = Builder::new().read(read_wire).write(write_expected).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        http_stream.write_continue_response().await.unwrap();
    }

    #[test]
    fn test_get_write_timeout() {
        let mut http_stream = HttpSession::new(Box::new(Builder::new().build()));
        let expected = Duration::from_secs(5);

        http_stream.set_write_timeout(Some(expected));
        assert_eq!(Some(expected), http_stream.write_timeout(50));
    }

    #[test]
    fn test_get_write_timeout_none() {
        let http_stream = HttpSession::new(Box::new(Builder::new().build()));
        assert!(http_stream.write_timeout(50).is_none());
    }

    #[test]
    fn test_get_write_timeout_min_send_rate_zero() {
        let mut http_stream = HttpSession::new(Box::new(Builder::new().build()));
        http_stream.set_min_send_rate(Some(0));
        assert!(http_stream.write_timeout(50).is_none());

        let mut http_stream = HttpSession::new(Box::new(Builder::new().build()));
        http_stream.set_min_send_rate(None);
        assert!(http_stream.write_timeout(50).is_none());
    }

    #[test]
    fn test_get_write_timeout_min_send_rate_overrides_write_timeout() {
        let mut http_stream = HttpSession::new(Box::new(Builder::new().build()));
        let expected = Duration::from_millis(29800);

        http_stream.set_write_timeout(Some(Duration::from_secs(60)));
        http_stream.set_min_send_rate(Some(5000));

        assert_eq!(Some(expected), http_stream.write_timeout(149000));
    }

    #[test]
    fn test_get_write_timeout_min_send_rate_max_zero_buf() {
        let mut http_stream = HttpSession::new(Box::new(Builder::new().build()));
        let expected = Duration::from_secs(1);

        http_stream.set_min_send_rate(Some(1));
        assert_eq!(Some(expected), http_stream.write_timeout(0));
    }

    #[tokio::test]
    async fn test_te_and_cl_disables_keepalive() {
        // When both Transfer-Encoding and Content-Length are present,
        // we must disable keepalive per RFC 9112 Section 6.1
        // https://datatracker.ietf.org/doc/html/rfc9112#section-6.1-15
        let input = b"POST / HTTP/1.1\r\n\
Host: pingora.org\r\n\
Transfer-Encoding: chunked\r\n\
Content-Length: 10\r\n\
\r\n\
5\r\n\
hello\r\n\
0\r\n\
\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();

        // Keepalive should be disabled
        assert_eq!(http_stream.keepalive_timeout, KeepaliveStatus::Off);

        // Content-Length header should have been removed
        assert!(!http_stream
            .req_header()
            .headers
            .contains_key(CONTENT_LENGTH));

        // Transfer-Encoding should still be present
        assert!(http_stream
            .req_header()
            .headers
            .contains_key(TRANSFER_ENCODING));
    }

    #[tokio::test]
    async fn test_http10_request_with_transfer_encoding_rejected() {
        // HTTP/1.0 requests MUST NOT contain Transfer-Encoding
        let input = b"POST / HTTP/1.0\r\n\
Host: pingora.org\r\n\
Transfer-Encoding: chunked\r\n\
\r\n\
5\r\n\
hello\r\n\
0\r\n\
\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let result = http_stream.read_request().await;

        // Should be rejected with InvalidHTTPHeader error
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(err.etype(), &InvalidHTTPHeader);
        assert!(err.to_string().contains("Transfer-Encoding"));
    }

    #[tokio::test]
    async fn test_http10_request_without_transfer_encoding_accepted() {
        // HTTP/1.0 requests without Transfer-Encoding should be accepted
        let input = b"POST / HTTP/1.0\r\n\
Host: pingora.org\r\n\
Content-Length: 5\r\n\
\r\n\
hello";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let result = http_stream.read_request().await;

        // Should succeed
        assert!(result.is_ok());
        assert_eq!(http_stream.req_header().version, http::Version::HTTP_10);
    }

    #[tokio::test]
    async fn test_http11_request_with_transfer_encoding_accepted() {
        // HTTP/1.1 with Transfer-Encoding should be accepted (contrast with HTTP/1.0)
        let input = b"POST / HTTP/1.1\r\n\
Host: pingora.org\r\n\
Transfer-Encoding: chunked\r\n\
\r\n\
5\r\n\
hello\r\n\
0\r\n\
\r\n";
        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        let result = http_stream.read_request().await;

        // Should succeed
        assert!(result.is_ok());
        assert_eq!(http_stream.req_header().version, http::Version::HTTP_11);
    }

    #[tokio::test]
    async fn test_request_multiple_transfer_encoding_headers() {
        init_log();
        // Multiple TE headers should be treated as comma-separated
        let input = b"POST / HTTP/1.1\r\n\
Host: pingora.org\r\n\
Transfer-Encoding: gzip\r\n\
Transfer-Encoding: chunked\r\n\
\r\n\
5\r\n\
hello\r\n\
0\r\n\
\r\n";

        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();

        // Should correctly identify chunked encoding from last header
        assert!(http_stream.is_chunked_encoding());

        // Verify body can be read correctly
        let body = http_stream.read_body_bytes().await.unwrap();
        assert_eq!(body.unwrap().as_ref(), b"hello");
    }

    #[tokio::test]
    async fn test_request_multiple_te_headers_chunked_not_last() {
        init_log();
        // Chunked in first header but not last - should NOT be chunked
        // Only the final Transfer-Encoding determines if body is chunked
        let input = b"POST / HTTP/1.1\r\n\
Host: pingora.org\r\n\
Transfer-Encoding: chunked\r\n\
Transfer-Encoding: identity\r\n\
Content-Length: 5\r\n\
\r\n";

        let mock_io = Builder::new().read(&input[..]).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        // should fail validation
        http_stream.read_request().await.unwrap_err();
    }

    #[tokio::test]
    async fn test_no_more_reuses_explicitly_disables_reuse() {
        init_log();
        let wire_req = b"GET /test HTTP/1.1\r\n\r\n";
        let wire_header = b"HTTP/1.1 200 OK\r\n\r\n";
        let mock_io = Builder::new()
            .read(&wire_req[..])
            .write(wire_header)
            .build();
        let mut http_session = HttpSession::new(Box::new(mock_io));

        // Setting the number of keepalive reuses here overrides the keepalive
        // setting below
        http_session.set_keepalive_reuses_remaining(Some(0));

        http_session.read_request().await.unwrap();

        let new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        http_session.update_resp_headers = false;
        http_session
            .write_response_header(Box::new(new_response))
            .await
            .unwrap();

        assert_eq!(http_session.body_writer.body_mode, BodyMode::UntilClose(0));

        http_session.finish_body().await.unwrap().unwrap();

        http_session.set_keepalive(Some(100));
        let reused = http_session.reuse().await.unwrap();
        assert!(reused.is_none());
    }

    #[tokio::test]
    async fn test_close_delimited_response_explicitly_disables_reuse() {
        init_log();
        let wire_req = b"GET /test HTTP/1.1\r\n\r\n";
        let wire_header = b"HTTP/1.1 200 OK\r\n\r\n";
        let mock_io = Builder::new()
            .read(&wire_req[..])
            .write(wire_header)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();

        let new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        http_stream.update_resp_headers = false;
        http_stream
            .write_response_header(Box::new(new_response))
            .await
            .unwrap();

        assert_eq!(http_stream.body_writer.body_mode, BodyMode::UntilClose(0));

        http_stream.finish_body().await.unwrap().unwrap();

        let reused = http_stream.reuse().await.unwrap();
        assert!(reused.is_none());
    }

    #[test]
    fn test_connection_user_context_set_and_take() {
        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));

        // Initially no context
        assert!(session.take_connection_user_context().is_none());

        // Set a context
        session.set_connection_user_context(Some(Box::new(42u64)));

        // Take it back
        let ctx = session.take_connection_user_context();
        assert!(ctx.is_some());
        let val = ctx.unwrap().downcast::<u64>().unwrap();
        assert_eq!(*val, 42u64);

        // After take, it's gone
        assert!(session.take_connection_user_context().is_none());
    }

    #[test]
    fn test_connection_user_context_set_none_clears() {
        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));

        session.set_connection_user_context(Some(Box::new("hello".to_string())));
        session.set_connection_user_context(None);
        assert!(session.take_connection_user_context().is_none());
    }
}

#[cfg(test)]
mod test_sync {
    use super::*;
    use http::StatusCode;
    use log::{debug, error};
    use std::str;

    fn init_log() {
        let _ = env_logger::builder().is_test(true).try_init();
    }

    #[test]
    fn test_response_to_wire() {
        init_log();
        let mut new_response = ResponseHeader::build(StatusCode::OK, None).unwrap();
        new_response.append_header("Foo", "Bar").unwrap();
        let mut wire = BytesMut::with_capacity(INIT_HEADER_BUF_SIZE);
        http_resp_header_to_buf(&new_response, &mut wire).unwrap();
        debug!("{}", str::from_utf8(wire.as_ref()).unwrap());
        let mut headers = [httparse::EMPTY_HEADER; 128];
        let mut resp = httparse::Response::new(&mut headers);
        let result = resp.parse(wire.as_ref());
        match result {
            Ok(_) => {}
            Err(e) => error!("{:?}", e),
        }
        assert!(result.unwrap().is_complete());
        // FIXME: the order is not guaranteed
        assert_eq!(b"Foo", headers[0].name.as_bytes());
        assert_eq!(b"Bar", headers[0].value);
    }
}

#[cfg(test)]
mod test_proxy_tasks {
    use super::*;
    use http::StatusCode;
    use std::future::IntoFuture;
    use tokio_test::io::{Builder, Mock};

    fn init_log() {
        let _ = env_logger::builder().is_test(true).try_init();
    }

    // An upper limit for any read within any test to prevent tests from hanging forever if
    // an internal read call never returns, etc.
    const TEST_MAX_WAIT_FOR_READ: Duration = Duration::from_secs(3);

    // The duration of 600 seconds is chosen to be "effectively forever" for the purpose of testing
    const TEST_FOREVER_DURATION: Duration = Duration::from_secs(600);

    // The read_timeout to use, when we want to test that a read operation times out
    const TEST_READ_TIMEOUT: Duration = Duration::from_secs(1);

    #[derive(Debug)]
    struct ReadBlockedForeverError;

    // Returns a client stream that will "never" send any bytes / return from a read operation
    fn mocked_blocking_headers_forever_stream() -> Box<Mock> {
        Box::new(Builder::new().wait(TEST_FOREVER_DURATION).build())
    }

    fn mocked_blocking_body_forever_stream() -> Box<Mock> {
        let http1 = b"GET / HTTP/1.1\r\n";
        let http2 = b"Host: pingora.example\r\nContent-Length: 3\r\n\r\n";
        Box::new(
            Builder::new()
                .read(&http1[..])
                .read(&http2[..])
                .wait(TEST_FOREVER_DURATION)
                .build(),
        )
    }

    // Helper function to test a read operation with a tokio timeout
    // to prevent tests from hanging forever in case of a bug
    async fn test_read_with_tokio_timeout<F, T>(
        read_future: F,
    ) -> Result<Result<T, Box<Error>>, ReadBlockedForeverError>
    where
        F: IntoFuture<Output = Result<T, Box<Error>>>,
    {
        let read_result = tokio::time::timeout(TEST_MAX_WAIT_FOR_READ, read_future).await;
        read_result.map_err(|_| ReadBlockedForeverError)
    }

    #[tokio::test]
    async fn test_read_http_request_headers_timeout_for_read_request() {
        // confirm that a `read_timeout` of `None` would've waited "indefinitely"
        let mut http_stream = HttpSession::new(mocked_blocking_headers_forever_stream());
        http_stream.read_timeout = None;
        let res = test_read_with_tokio_timeout(http_stream.read_request()).await;
        assert!(res.is_err()); // test timeout occurred, and not any internal Pingora timeout

        // confirm that the `read_timeout` is respected
        let mut http_stream = HttpSession::new(mocked_blocking_headers_forever_stream());
        http_stream.read_timeout = Some(TEST_READ_TIMEOUT);
        let res = test_read_with_tokio_timeout(http_stream.read_request()).await;
        assert!(res.is_ok());
        assert_eq!(res.unwrap().unwrap_err().etype(), &ReadTimedout);
    }

    #[tokio::test]
    async fn test_read_http_body_timeout_for_read_body_bytes() {
        // confirm that a `read_timeout` of `None` would've waited "indefinitely"
        let mut http_stream = HttpSession::new(mocked_blocking_body_forever_stream());
        http_stream.read_timeout = None;
        http_stream.read_request().await.unwrap();
        let res = test_read_with_tokio_timeout(http_stream.read_body_bytes()).await;
        assert!(res.is_err()); // test timeout occurred, and not any internal Pingora timeout

        // confirm that the `read_timeout` is respected
        let mut http_stream = HttpSession::new(mocked_blocking_body_forever_stream());
        http_stream.read_timeout = Some(TEST_READ_TIMEOUT);
        http_stream.read_request().await.unwrap();
        let res = test_read_with_tokio_timeout(http_stream.read_body_bytes()).await;
        assert!(res.is_ok());
        assert_eq!(res.unwrap().unwrap_err().etype(), &ReadTimedout);
    }

    #[tokio::test]
    async fn test_send_proxy_task_and_write() {
        init_log();

        // We need to know exact bytes that will be written
        // "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello"
        let expected_header = b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n";
        let expected_body = b"hello";

        let mock_io = Builder::new()
            .write(expected_header)
            .write(expected_body)
            .build();

        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.update_resp_headers = false; // Disable automatic headers

        // Queue header task
        let mut header = ResponseHeader::build(StatusCode::OK, Some(5)).unwrap();
        header.insert_header("Content-Length", "5").unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), false));

        // Queue body task
        http_stream.send_proxy_task(HttpTask::Body(Some(Bytes::from("hello")), true));

        // Write all tasks
        let end_stream = http_stream.write_proxy_tasks().await.unwrap();
        assert!(end_stream);
    }

    #[tokio::test]
    async fn test_proxy_task_with_timeout() {
        init_log();

        let expected_header = b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n";
        let expected_body = b"hello";

        let mock_io = Builder::new()
            .write(expected_header)
            .write(expected_body)
            .build();

        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.update_resp_headers = false;
        http_stream.write_timeout = Some(Duration::from_secs(1)); // Set write timeout

        // Queue tasks
        let mut header = ResponseHeader::build(StatusCode::OK, Some(5)).unwrap();
        header.insert_header("Content-Length", "5").unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), false));
        http_stream.send_proxy_task(HttpTask::Body(Some(Bytes::from("hello")), true));

        // Verify initial state
        assert_eq!(
            http_stream.body_bytes_sent(),
            0,
            "Should start with 0 bytes sent"
        );

        // Write all tasks with timeout
        let end_stream = http_stream.write_proxy_tasks().await.unwrap();
        assert!(end_stream);

        // Verify body bytes were counted correctly (not double counted)
        assert_eq!(
            http_stream.body_bytes_sent(),
            5,
            "Should count exactly 5 bytes (application level), not double counted"
        );
    }

    // Test that write_proxy_tasks is cancel-safe: if the future is dropped mid-execution,
    // unwritten tasks should remain in the queue.
    #[tokio::test]
    async fn test_proxy_task_cancel_safety() {
        init_log();

        let expected_header = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n";
        // First chunk: "5\r\nhello\r\n"
        let expected_chunk1 = b"5\r\nhello\r\n";

        // Create a mock IO that will write the header and first chunk,
        // but will block indefinitely on the second chunk
        let mock_io = Builder::new()
            .write(expected_header)
            .write(expected_chunk1)
            .wait(Duration::from_secs(999)) // This will cause timeout
            .build();

        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.update_resp_headers = false;
        http_stream.write_timeout = Some(Duration::from_millis(100));

        // Queue 3 tasks: header + 2 body chunks
        let mut header = ResponseHeader::build(StatusCode::OK, None).unwrap();
        header
            .insert_header("Transfer-Encoding", "chunked")
            .unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), false));
        http_stream.send_proxy_task(HttpTask::Body(Some(Bytes::from("hello")), false));
        http_stream.send_proxy_task(HttpTask::Body(Some(Bytes::from("world")), true));

        // Verify we have 3 tasks queued
        assert_eq!(http_stream.proxy_task_state.tasks.len(), 3);

        // Try to write all tasks - this should timeout while writing the second body chunk
        let result = http_stream.write_proxy_tasks().await;
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().etype(), &WriteTimedout);

        // With the refactored cancel-safe design:
        // - First task (header) was written successfully and removed from queue
        // - Second task (first body "hello") was removed and sent to BodyWriter, write succeeded, state cleared
        // - Third task (second body "world") was removed and sent to BodyWriter, timed out mid-write
        // - The in-progress write state is tracked in current_writer, NOT in the queue
        assert_eq!(
            http_stream.proxy_task_state.tasks.len(),
            0,
            "Queue should be empty - tasks are owned by writers once sent"
        );

        // The task being written should be tracked in current_writer
        assert!(
            matches!(
                http_stream.proxy_task_state.current_writer,
                Some(ProxyTaskWriter::WritingBody(_))
            ),
            "Should be mid-write of body task - writer owns the 'world' task state"
        );

        // Verify body_bytes_sent only counts the successfully written "hello" (5 bytes)
        // not the timed-out "world"
        assert_eq!(
            http_stream.body_bytes_sent(),
            5,
            "Should only count the 5 bytes from 'hello', not the incomplete 'world' write"
        );

        // On next call to write_proxy_tasks(), Step 1 will resume the "world" write
    }

    use crate::protocols::http::v1::test_util::FlushTrackingMock;

    // Test that write_continue_response can be called before write_proxy_tasks
    // and both work correctly together.
    #[tokio::test]
    async fn test_continue_response_before_proxy_tasks() {
        init_log();

        // Expected bytes written:
        // 1. 100 Continue response
        // 2. 200 OK response header
        // 3. Body data
        let expected_continue = b"HTTP/1.1 100 Continue\r\n\r\n";
        let expected_header = b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n";
        let expected_body = b"hello";

        let mock_io = Builder::new()
            .write(expected_continue)
            .write(expected_header)
            .write(expected_body)
            .build();

        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.update_resp_headers = false; // Disable automatic headers

        // First, write the 100 Continue response
        http_stream.write_continue_response().await.unwrap();

        // Verify that 100 Continue was recorded
        assert!(
            http_stream.response_written().is_some(),
            "100 Continue should be recorded in response_written"
        );
        assert_eq!(
            http_stream.response_written().unwrap().status,
            StatusCode::CONTINUE,
            "Should have recorded 100 Continue"
        );

        // Now queue the actual response using proxy tasks
        let mut header = ResponseHeader::build(StatusCode::OK, Some(5)).unwrap();
        header.insert_header("Content-Length", "5").unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), false));
        http_stream.send_proxy_task(HttpTask::Body(Some(Bytes::from("hello")), true));

        // Write all proxy tasks
        let end_stream = http_stream.write_proxy_tasks().await.unwrap();
        assert!(end_stream, "Should indicate end of stream");

        // Verify final response is 200 OK, not 100 Continue
        assert_eq!(
            http_stream.response_written().unwrap().status,
            StatusCode::OK,
            "Final response should be 200 OK, overwriting 100 Continue"
        );
    }

    #[tokio::test]
    async fn test_head_response_with_content_length_flushes() {
        init_log();

        // HEAD request line + headers
        let request = b"HEAD / HTTP/1.1\r\nHost: example.com\r\n\r\n";
        let expected_header = b"HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\n";

        let mock_io = Builder::new().read(request).write(expected_header).build();
        let (flush_mock, flush_count) = FlushTrackingMock::new(mock_io);
        let mut http_stream = HttpSession::new(Box::new(flush_mock));
        http_stream.update_resp_headers = false;

        // Read the HEAD request
        http_stream.read_request().await.unwrap();
        assert_eq!(http_stream.get_method(), Some(&Method::HEAD));

        // Queue header with Content-Length (body will be empty for HEAD)
        let mut header = ResponseHeader::build(StatusCode::OK, Some(2)).unwrap();
        header.insert_header("Content-Length", "100").unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), true));

        let flush_before = FlushTrackingMock::flush_count(&flush_count);
        let end_stream = http_stream.write_proxy_tasks().await.unwrap();
        let flush_after = FlushTrackingMock::flush_count(&flush_count);

        assert!(end_stream, "HEAD response should be end of stream");
        assert!(
            flush_after > flush_before,
            "Should flush after writing HEAD response header with Content-Length \
             (body_writer.finished() is true). Got flush_before={flush_before}, \
             flush_after={flush_after}"
        );
    }

    #[tokio::test]
    async fn test_204_response_with_content_length_flushes() {
        init_log();

        let request = b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n";
        let expected_header = b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\n\r\n";

        let mock_io = Builder::new().read(request).write(expected_header).build();
        let (flush_mock, flush_count) = FlushTrackingMock::new(mock_io);
        let mut http_stream = HttpSession::new(Box::new(flush_mock));
        http_stream.update_resp_headers = false;

        http_stream.read_request().await.unwrap();

        let mut header = ResponseHeader::build(StatusCode::NO_CONTENT, Some(2)).unwrap();
        header.insert_header("Content-Length", "0").unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), true));

        let flush_before = FlushTrackingMock::flush_count(&flush_count);
        let end_stream = http_stream.write_proxy_tasks().await.unwrap();
        let flush_after = FlushTrackingMock::flush_count(&flush_count);

        assert!(end_stream, "204 response should be end of stream");
        assert!(
            flush_after > flush_before,
            "Should flush after writing 204 response header with Content-Length \
             (body_writer.finished() is true). Got flush_before={flush_before}, \
             flush_after={flush_after}"
        );
    }

    #[tokio::test]
    #[should_panic(
        expected = "Unexpected UpgradedBody task received on un-upgraded downstream session"
    )]
    async fn test_upgraded_body_on_non_upgraded_session_panics() {
        init_log();

        let request = b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n";
        let expected_header = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n";
        // UpgradedBody on a non-upgraded session should panic before writing,
        // but if the bug exists, BodyWriter would encode it as a chunk:
        let expected_chunk = b"5\r\nhello\r\n";
        let expected_finish = b"0\r\n\r\n";

        let mock_io = Builder::new()
            .read(request)
            .write(expected_header)
            // If the panic check is missing, the body gets written as a chunk
            .write(expected_chunk)
            .write(expected_finish)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.update_resp_headers = false;

        http_stream.read_request().await.unwrap();
        assert!(
            !http_stream.was_upgraded(),
            "Session should NOT be upgraded"
        );

        // Queue a normal header
        let mut header = ResponseHeader::build(StatusCode::OK, Some(2)).unwrap();
        header
            .insert_header("Transfer-Encoding", "chunked")
            .unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), false));

        // Queue an UpgradedBody task on a non-upgraded session — should panic
        http_stream.send_proxy_task(HttpTask::UpgradedBody(Some(Bytes::from("hello")), true));

        // This should panic before/during the body write
        let _ = http_stream.write_proxy_tasks().await;
    }

    #[tokio::test]
    #[should_panic(expected = "Unexpected Body task received on upgraded downstream session")]
    async fn test_body_on_upgraded_session_panics() {
        init_log();

        // Upgrade request
        let request =
            b"GET / HTTP/1.1\r\nHost: example.com\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n";
        // 101 Switching Protocols response
        let expected_header =
            b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n";
        // If the panic check is missing, Body data would be written raw (close-delimited)
        let expected_body = b"hello";

        let mock_io = Builder::new()
            .read(request)
            .write(expected_header)
            .write(expected_body)
            .build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.update_resp_headers = false;

        http_stream.read_request().await.unwrap();

        // Queue 101 header to complete the upgrade
        let mut header = ResponseHeader::build(StatusCode::SWITCHING_PROTOCOLS, Some(3)).unwrap();
        header.insert_header("Upgrade", "websocket").unwrap();
        header.insert_header("Connection", "Upgrade").unwrap();
        http_stream.send_proxy_task(HttpTask::Header(Box::new(header), false));

        // Queue a regular Body task on what will be an upgraded session — should panic
        http_stream.send_proxy_task(HttpTask::Body(Some(Bytes::from("hello")), true));

        // This should panic (after writing the header, session becomes upgraded,
        // then the Body task should be rejected)
        let _ = http_stream.write_proxy_tasks().await;
    }
}

#[cfg(test)]
mod test_overread {
    use super::*;
    use rstest::rstest;
    use tokio_test::io::Builder;

    fn init_log() {
        let _ = env_logger::builder().is_test(true).try_init();
    }

    /// Test session reuse with preread body (all data in single read).
    /// When extra bytes are read beyond the request body, the session should NOT be reused.
    /// Test matrix includes whether reading body bytes is polled.
    #[rstest]
    #[case(0, None, true, true)] // CL:0, no extra, read body -> should reuse
    #[case(0, None, false, true)] // CL:0, no extra, no read -> should reuse
    #[case(0, Some(&b"extra_data_here"[..]), true, false)] // CL:0, extra, read body -> should NOT reuse
    #[case(0, Some(&b"extra_data_here"[..]), false, false)] // CL:0, extra, no read -> should NOT reuse
    #[case(5, None, true, true)] // CL:5, no extra, read body -> should reuse
    #[case(5, None, false, true)] // CL:5, no extra, no read -> should reuse
    #[case(5, Some(&b"extra"[..]), true, false)] // CL:5, extra, read body -> should NOT reuse
    #[case(5, Some(&b"extra"[..]), false, false)] // CL:5, extra, no read -> should NOT reuse
    #[tokio::test]
    async fn test_reuse_with_preread_body_overread(
        #[case] content_length: usize,
        #[case] extra_bytes: Option<&[u8]>,
        #[case] read_body: bool,
        #[case] expect_reuse: bool,
    ) {
        init_log();

        let body = b"hello";

        // Build the complete HTTP request in a single buffer
        // (all body is preread with header)
        let mut request_data = Vec::new();
        request_data.extend_from_slice(b"GET / HTTP/1.1\r\n");
        request_data.extend_from_slice(
            format!("Host: pingora.org\r\nContent-Length: {content_length}\r\n\r\n",).as_bytes(),
        );

        if content_length > 0 {
            request_data.extend_from_slice(&body[..content_length]);
        }

        if let Some(extra) = extra_bytes {
            request_data.extend_from_slice(extra);
        }

        let mock_io = Builder::new().read(&request_data).build();
        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();

        // Conditionally read the body
        if read_body {
            let result = http_stream.read_body_bytes().await.unwrap();

            if content_length == 0 {
                assert!(
                    result.is_none(),
                    "Body should be empty for Content-Length: 0"
                );
            } else {
                let body_result = result.unwrap();
                assert_eq!(body_result.as_ref(), &body[..content_length]);
            }
            assert_eq!(http_stream.body_bytes_read(), content_length);
        }

        let reused = http_stream.reuse().await.unwrap();
        assert_eq!(reused.is_some(), expect_reuse);
    }

    /// Test session reuse with chunked encoding and separate reads.
    /// When extra bytes are read beyond the request body, the session should NOT be reused.
    /// Test matrix includes whether reading body bytes is polled.
    #[rstest]
    #[case(true)]
    #[case(false)]
    #[tokio::test]
    async fn test_reuse_with_chunked_body_overread(#[case] read_body: bool) {
        init_log();

        let headers = b"GET / HTTP/1.1\r\nHost: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n";
        let body_and_extra = b"5\r\nhello\r\n0\r\n\r\nextra";

        let mock_io = Builder::new().read(headers).read(body_and_extra).build();

        let mut http_stream = HttpSession::new(Box::new(mock_io));
        http_stream.read_request().await.unwrap();
        assert!(http_stream.is_chunked_encoding());

        if read_body {
            let result = http_stream.read_body_bytes().await.unwrap();
            assert_eq!(result.unwrap().as_ref(), b"hello");

            // Read terminating chunk (returns None)
            let result = http_stream.read_body_bytes().await.unwrap();
            assert!(result.is_none());

            assert_eq!(http_stream.body_bytes_read(), 5);
        }

        let reused = http_stream.reuse().await.unwrap();
        assert!(reused.is_none());
    }
}

#[cfg(test)]
mod test_abort_on_close {
    use super::*;
    use pingora_error::ErrorType;
    use tokio_test::io::Builder;

    fn init_log() {
        let _ = env_logger::builder().is_test(true).try_init();
    }

    /// Helper: create an HttpSession whose request has been read and body is done,
    /// with the mock stream returning EOF on the next read (simulating client FIN).
    async fn session_with_eof() -> HttpSession {
        let request = b"GET / HTTP/1.1\r\nHost: localhost\r\n\r\n";
        let mock_io = Builder::new().read(&request[..]).build();
        let mut s = HttpSession::new(Box::new(mock_io));
        s.read_request().await.unwrap();
        s
    }

    #[tokio::test]
    async fn default_abort_on_close_returns_error() {
        init_log();
        let mut s = session_with_eof().await;

        assert!(s.abort_on_close);
        let err = s.read_body_or_idle(true).await.unwrap_err();
        assert_eq!(*err.etype(), ErrorType::ConnectionClosed);
        assert!(s.is_half_closed());
    }

    #[tokio::test]
    async fn abort_on_close_false_stays_pending() {
        init_log();
        let mut s = session_with_eof().await;
        s.set_abort_on_close(false);

        let result = tokio::time::timeout(
            std::time::Duration::from_millis(50),
            s.read_body_or_idle(true),
        )
        .await;

        assert!(result.is_err(), "expected timeout (pending), got a result");
        assert!(s.is_half_closed());
    }

    #[tokio::test]
    async fn abort_on_close_error_message_before_response() {
        init_log();
        let mut s = session_with_eof().await;

        assert!(s.response_written().is_none());
        let err = s.read_body_or_idle(true).await.unwrap_err();
        let msg = format!("{err}");
        assert!(
            msg.contains("Prematurely before response header is sent"),
            "unexpected error message: {msg}"
        );
    }

    #[tokio::test]
    async fn abort_on_close_error_message_after_response_header() {
        init_log();
        let mut s = session_with_eof().await;

        // Simulate that a response header has already been sent.
        let resp = ResponseHeader::build(200, None).unwrap();
        s.response_written = Some(Box::new(resp));
        let err = s.read_body_or_idle(true).await.unwrap_err();
        let msg = format!("{err}");
        assert!(
            msg.contains("Prematurely before response body is complete"),
            "unexpected error message: {msg}"
        );
    }

    #[tokio::test]
    async fn no_body_expected_false_reads_body_then_idles() {
        init_log();
        let request = b"POST / HTTP/1.1\r\nHost: localhost\r\nContent-Length: 3\r\n\r\n";
        let mock_io = Builder::new().read(&request[..]).read(b"abc").build();
        let mut s = HttpSession::new(Box::new(mock_io));
        s.read_request().await.unwrap();

        // 1) no_body_expected = false should still read request body while not done.
        let body = s.read_body_or_idle(false).await.unwrap().unwrap();
        assert_eq!(body.as_ref(), b"abc");
        assert!(s.is_body_done());

        // 2) Once body is naturally done, it transitions to idle behavior on the next call.
        let err = s.read_body_or_idle(false).await.unwrap_err();
        assert_eq!(*err.etype(), ErrorType::ConnectionClosed);
        let msg = format!("{err}");
        assert!(
            msg.contains("Prematurely before response header is sent"),
            "unexpected error message: {msg}"
        );
    }

    #[tokio::test]
    async fn set_abort_on_close_toggles() {
        init_log();
        let mut s = session_with_eof().await;

        assert!(s.abort_on_close);
        s.set_abort_on_close(false);
        assert!(!s.abort_on_close);
        s.set_abort_on_close(true);
        assert!(s.abort_on_close);
    }
}

#[cfg(test)]
mod test_pipelining {
    //! Tests for HTTP/1.1 request pipelining support (RFC 9112 §9.3.2).
    //!
    //! Pipelining is an opt-in behavior: when enabled via
    //! [`HttpSession::set_pipelining_enabled`], the session tolerates
    //! overread bytes on reuse (they belong to the next request) and a new
    //! session can have them fed in via [`HttpSession::set_pipelined_prefix`].
    //!
    //! When disabled (default), overread bytes cause [`HttpSession::reuse`]
    //! to return `Ok(None)` so the connection closes — the historical
    //! behavior preserved for callers that do not opt in.

    use super::*;
    use rstest::rstest;
    use tokio_test::io::Builder;

    fn init_log() {
        let _ = env_logger::builder().is_test(true).try_init();
    }

    /// Default state: pipelining is off.
    #[tokio::test]
    async fn pipelining_disabled_by_default() {
        init_log();
        let mock_io = Builder::new().build();
        let s = HttpSession::new(Box::new(mock_io));
        assert!(!s.pipelining_enabled());
    }

    /// Toggling the pipelining flag is round-trippable.
    #[tokio::test]
    async fn set_pipelining_enabled_toggles() {
        init_log();
        let mock_io = Builder::new().build();
        let mut s = HttpSession::new(Box::new(mock_io));
        assert!(!s.pipelining_enabled());
        s.set_pipelining_enabled(true);
        assert!(s.pipelining_enabled());
        s.set_pipelining_enabled(false);
        assert!(!s.pipelining_enabled());
    }

    /// When pipelining is disabled (default), overread bytes must cause
    /// reuse to return `None`. Pipelining opt-in must not regress that
    /// compatibility behavior.
    #[rstest]
    #[case(true)] // pipelining explicitly off
    #[case(false)] // pipelining flag never set
    #[tokio::test]
    async fn reuse_rejects_overread_when_pipelining_disabled(#[case] explicit_off: bool) {
        init_log();
        let request =
            b"GET / HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\npipelined_next";
        let mock_io = Builder::new().read(request).build();
        let mut s = HttpSession::new(Box::new(mock_io));
        if explicit_off {
            s.set_pipelining_enabled(false);
        }
        s.read_request().await.unwrap();
        // Overread is captured when body reading initializes — poll the
        // body to trigger the init_content_length path.
        let _ = s.read_body_bytes().await.unwrap();
        assert!(s.body_reader.has_bytes_overread());
        let reused = s.reuse().await.unwrap();
        assert!(
            reused.is_none(),
            "reuse must return None without pipelining"
        );
    }

    /// When pipelining is enabled and overread bytes are present,
    /// reuse returns both the stream and the extracted prefix.
    #[tokio::test]
    async fn reuse_allows_overread_when_pipelining_enabled() {
        init_log();
        let request =
            b"GET / HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\npipelined_next";
        let mock_io = Builder::new().read(request).build();
        let mut s = HttpSession::new(Box::new(mock_io));
        s.set_pipelining_enabled(true);
        s.read_request().await.unwrap();
        let _ = s.read_body_bytes().await.unwrap();
        assert!(s.body_reader.has_bytes_overread());

        let reused = s.reuse().await.unwrap().expect("connection reusable");
        let (_stream, prefix) = reused.into_parts();
        let prefix = prefix.expect("overread must be returned as pipelined prefix");
        assert_eq!(prefix.as_ref(), b"pipelined_next");
    }

    /// Same-read pipelining with no prior body poll still extracts the prefix.
    #[tokio::test]
    async fn reuse_extracts_prefix_without_body_poll() {
        init_log();
        let req1 = b"GET /one HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut combined = Vec::with_capacity(req1.len() + req2.len());
        combined.extend_from_slice(req1);
        combined.extend_from_slice(req2);

        let mock_io = Builder::new().read(&combined).build();
        let mut a = HttpSession::new(Box::new(mock_io));
        a.set_pipelining_enabled(true);
        a.read_request().await.unwrap();
        assert_eq!(a.req_header().uri.path(), "/one");

        let reused = a.reuse().await.unwrap().expect("connection reusable");
        let (stream, prefix) = reused.into_parts();
        let prefix = prefix.expect("pipelined prefix must be extracted during reuse");
        assert_eq!(prefix.as_ref(), req2);

        let mut b = HttpSession::new(stream);
        b.set_pipelining_enabled(true);
        b.set_pipelined_prefix(prefix);
        b.read_request()
            .await
            .unwrap()
            .expect("pipelined request must parse");
        assert_eq!(b.req_header().uri.path(), "/two");
    }

    /// Content-Length: 0 has the same extraction requirement as absent length.
    #[tokio::test]
    async fn reuse_extracts_content_length_zero_prefix_without_body_poll() {
        init_log();
        let req1 = b"GET /one HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        let mut combined = Vec::with_capacity(req1.len() + req2.len());
        combined.extend_from_slice(req1);
        combined.extend_from_slice(req2);

        let mock_io = Builder::new().read(&combined).build();
        let mut a = HttpSession::new(Box::new(mock_io));
        a.set_pipelining_enabled(true);
        a.read_request().await.unwrap();
        assert_eq!(a.req_header().uri.path(), "/one");

        let reused = a.reuse().await.unwrap().expect("connection reusable");
        let (_stream, prefix) = reused.into_parts();
        let prefix = prefix.expect("pipelined prefix must be extracted during reuse");
        assert_eq!(prefix.as_ref(), req2);
    }

    /// The new session parses the pipelined prefix as the start of a
    /// request without issuing any stream read — the mock_io allows no
    /// reads, so if read_request() tried to pull from the stream it would
    /// panic. This is the essential pipelining property: a prefix that
    /// already contains a complete request is parsed without waiting for
    /// additional bytes.
    #[tokio::test]
    async fn read_request_consumes_complete_prefix_without_stream_read() {
        init_log();
        let prefix = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        // Mock IO that would panic on any read — ensures the parse is
        // wholly satisfied by the pipelined prefix.
        let mock_io = Builder::new().build();
        let mut s = HttpSession::new(Box::new(mock_io));
        s.set_pipelined_prefix(BytesMut::from(&prefix[..]));
        let n = s
            .read_request()
            .await
            .unwrap()
            .expect("request must parse from prefix alone");
        assert!(n > 0);
        assert_eq!(s.req_header().uri.path(), "/two");
    }

    /// When the prefix is only the beginning of a request, read_request()
    /// continues to read from the stream to complete the header.
    #[tokio::test]
    async fn read_request_falls_through_to_stream_for_partial_prefix() {
        init_log();
        let prefix = b"GET /two HTTP/1.1\r\nHost: ";
        let rest = b"pingora.org\r\nContent-Length: 0\r\n\r\n";
        let mock_io = Builder::new().read(rest).build();
        let mut s = HttpSession::new(Box::new(mock_io));
        s.set_pipelined_prefix(BytesMut::from(&prefix[..]));
        let n = s
            .read_request()
            .await
            .unwrap()
            .expect("request must parse across prefix + stream");
        assert!(n > 0);
        assert_eq!(s.req_header().uri.path(), "/two");
    }

    /// Body-pump path: request 2's bytes arrive in a SEPARATE read
    /// after request 1 has been fully consumed. The proxy's body-pump
    /// loop polls the downstream socket via
    /// [`HttpSession::read_body_or_idle`]`(true)` while request 1's
    /// response is still being written. The idle branch at
    /// `read_body_or_idle` currently raises
    /// `ConnectError("Sent data after end of body")` when the idle
    /// read returns > 0 bytes — which is exactly the shape pipelining
    /// traffic takes when requests span TCP segment boundaries.
    ///
    /// This covers the two-segment pipelining case: request 2's bytes
    /// arrive during the proxy's idle poll, not during request 1's body
    /// read. The reuse() overread path (already covered by the tests
    /// above) never fires because request 2's bytes were never in
    /// `body_buf_overread` to begin with.
    ///
    /// When pipelining is enabled on the session, this branch must
    /// NOT raise `ConnectError`. Instead, the byte(s) read by
    /// `idle()` must be stashed so the reuse() path can hand them
    /// to the next session via the standard `take_body_overread`
    /// extractor. `idle()` uses a 1-byte probe buffer, so the
    /// overread surface will typically hold 1 byte per idle poll —
    /// the remaining bytes of request 2 stay on the underlying
    /// stream and are read by the next session's `read_request`
    /// (which seeds itself with the pipelined prefix and continues
    /// reading from the stream to complete the header).
    #[tokio::test]
    async fn idle_read_stashes_bytes_when_pipelining_enabled() {
        init_log();
        let req1 = b"GET /one HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        // Only the first byte of req2 is queued — the idle-branch
        // read in `read_body_or_idle` uses a 1-byte probe buffer,
        // so that's all it will consume. The rest of req2 would
        // live on the kernel socket buffer in real traffic and be
        // drained by the next session.
        let req2_first = b"G";

        // No `.wait(...)` between the two reads — we want the
        // second read to be immediately available once the first
        // consumer polls. `tokio-test::io::Builder` delivers reads
        // one poll at a time regardless, which is what models a
        // TCP segment boundary for our purposes.
        let mock_io = Builder::new().read(&req1[..]).read(&req2_first[..]).build();

        let mut s = HttpSession::new(Box::new(mock_io));
        s.set_pipelining_enabled(true);

        // Consume request 1 fully. Body is zero-length so body_done
        // is true; no overread is captured in body_buf_overread
        // because req2's bytes were NOT in the same read as req1.
        s.read_request().await.unwrap();
        assert_eq!(s.req_header().uri.path(), "/one");
        let _ = s.read_body_bytes().await.unwrap();
        assert!(s.is_body_done());
        assert!(
            !s.body_reader.has_bytes_overread(),
            "precondition: req2 must arrive in a separate read, not as overread on req1"
        );

        // This is the proxy's body-pump poll. Post-fix, the idle
        // branch reads the byte, pushes it to the body reader's
        // overread surface, and stays pending — signaling the
        // body-pump `select!` loop that the downstream has no more
        // body activity to wait on (the loop exits via its other
        // branches when the upstream response completes).
        //
        // We assert the *causal* invariant, not a wall-clock one:
        // poll the future repeatedly, yielding between polls to
        // let the mock I/O stack drain, until either (a) it
        // resolves (which is a failure — it MUST stay pending) or
        // (b) we observe enough bookkeeping progress to know the
        // idle read has completed. The proxy_tasks channel via
        // `proxy_tasks_rx` isn't wired in this test, so "enough
        // progress" is signaled by tracking `poll_count` alone;
        // the actual overread presence is asserted after the
        // future is dropped.
        //
        // Scope the future in an async block so its borrow on `s`
        // ends when we exit the block — the body-reader check
        // needs a fresh borrow.
        {
            let fut = s.read_body_or_idle(true);
            tokio::pin!(fut);
            // Drive the future forward a bounded number of times.
            // Under the fix it will always stay Pending; a broken
            // fix resolves Ready in the first few polls.
            for _ in 0..10 {
                match futures::poll!(fut.as_mut()) {
                    std::task::Poll::Pending => {
                        tokio::task::yield_now().await;
                    }
                    std::task::Poll::Ready(Err(e)) => panic!(
                        "read_body_or_idle(true) must not raise an error when \
                         pipelining is enabled and the idle read returns > 0 bytes \
                         (those bytes are the start of pipelined request 2, not \
                         illegal trailing body). Got error: {e:?}"
                    ),
                    std::task::Poll::Ready(Ok(body)) => panic!(
                        "read_body_or_idle(true) must stay pending after stashing \
                         pipelined bytes (the body-pump `select!` exits via its \
                         other branches). Got body: {body:?}"
                    ),
                }
            }
            // Future still pending — exit the scope, which drops
            // `fut` and releases the mutable borrow on `s`.
        }

        // The byte must be extractable as overread, so the
        // standard reuse() + HttpPersistentSettings pipeline can
        // hand it to the next session.
        let overread = s
            .take_body_overread()
            .expect("pipelined request 2 byte must be retrievable as overread");
        assert_eq!(
            overread.as_ref(),
            req2_first,
            "stashed bytes must be the idle-read probe byte from request 2"
        );
    }

    /// Symmetric to the test above: pipelining OFF means the idle
    /// branch still raises `ConnectError` as it did pre-patch. This
    /// preserves upstream behavior for non-adopters.
    #[tokio::test]
    async fn idle_read_still_raises_when_pipelining_disabled() {
        init_log();
        let req1 = b"GET /one HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        // Single byte of req2 — idle-branch read uses a 1-byte probe
        // buffer, error path fires, mock is fully drained.
        let req2_first = b"G";

        let mock_io = Builder::new().read(&req1[..]).read(&req2_first[..]).build();

        let mut s = HttpSession::new(Box::new(mock_io));
        // Leave pipelining at the default (off).
        s.read_request().await.unwrap();
        let _ = s.read_body_bytes().await.unwrap();
        assert!(s.is_body_done());

        let err = s
            .read_body_or_idle(true)
            .await
            .expect_err("pipelining off: idle read > 0 must raise ConnectError");
        assert_eq!(
            *err.etype(),
            pingora_error::ErrorType::ConnectError,
            "non-adopter callers must still see ConnectError on surplus idle bytes"
        );
    }

    /// End-to-end: session A finishes with overread, bytes are extracted,
    /// session B consumes them via set_pipelined_prefix and parses the
    /// pipelined request without reading from the (empty) stream.
    #[tokio::test]
    async fn pipelined_request_chain_end_to_end() {
        init_log();

        // Session A: read request 1 with pipelined request 2 bytes appended.
        let req1 = b"GET /one HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 0\r\n\r\n";
        let mut combined = Vec::with_capacity(req1.len() + req2.len());
        combined.extend_from_slice(req1);
        combined.extend_from_slice(req2);

        let mock_io_a = Builder::new().read(&combined).build();
        let mut a = HttpSession::new(Box::new(mock_io_a));
        a.set_pipelining_enabled(true);
        a.read_request().await.unwrap();
        assert_eq!(a.req_header().uri.path(), "/one");
        // Poll the body to trigger init_content_length which captures
        // the bytes past Content-Length: 0 as overread.
        let _ = a.read_body_bytes().await.unwrap();
        assert!(a.body_reader.has_bytes_overread());

        let overread = a.take_body_overread().expect("overread present");

        // Session B: construct with an empty stream (pipelined prefix is
        // everything we need), feed the overread, parse the next request.
        let mock_io_b = Builder::new().build();
        let mut b = HttpSession::new(Box::new(mock_io_b));
        b.set_pipelining_enabled(true);
        b.set_pipelined_prefix(overread);
        b.read_request()
            .await
            .unwrap()
            .expect("pipelined request must parse");
        assert_eq!(b.req_header().uri.path(), "/two");
    }

    #[tokio::test]
    async fn bodyless_pipeline_transfers_prefix_without_copying() {
        init_log();
        let req1 = b"GET /one HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut prefix = BytesMut::with_capacity(req1.len() + req2.len());
        prefix.extend_from_slice(req1);
        prefix.extend_from_slice(req2);
        let base = prefix.as_ptr();

        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));
        session.set_pipelining_enabled(true);
        session.set_pipelined_prefix(prefix);
        session.read_request().await.unwrap();

        let reused = session.reuse().await.unwrap().expect("connection reusable");
        let (_, prefix) = reused.into_parts();
        let prefix = prefix.expect("second request remains buffered");
        assert_eq!(prefix.as_ptr(), unsafe { base.add(req1.len()) });
        assert_eq!(prefix.as_ref(), req2);
    }

    #[tokio::test]
    async fn content_length_pipeline_transfers_prefix_without_copying() {
        init_log();
        let req1 = b"POST /one HTTP/1.1\r\nHost: pingora.org\r\nContent-Length: 4\r\n\r\nbody";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut prefix = BytesMut::with_capacity(req1.len() + req2.len());
        prefix.extend_from_slice(req1);
        prefix.extend_from_slice(req2);
        let base = prefix.as_ptr();

        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));
        session.set_pipelining_enabled(true);
        session.set_pipelined_prefix(prefix);
        session.read_request().await.unwrap();

        let reused = session.reuse().await.unwrap().expect("connection reusable");
        let (_, prefix) = reused.into_parts();
        let prefix = prefix.expect("second request remains buffered");
        assert_eq!(prefix.as_ptr(), unsafe { base.add(req1.len()) });
        assert_eq!(prefix.as_ref(), req2);
    }

    #[tokio::test]
    async fn chunked_pipeline_with_trailers_transfers_prefix_without_copying() {
        init_log();
        let req1 = b"POST /one HTTP/1.1\r\nHost: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n1\r\na\r\n0\r\nX-Test: one\r\n\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut prefix = BytesMut::with_capacity(req1.len() + req2.len());
        prefix.extend_from_slice(req1);
        prefix.extend_from_slice(req2);
        let base = prefix.as_ptr();

        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));
        session.set_pipelining_enabled(true);
        session.set_pipelined_prefix(prefix);
        session.read_request().await.unwrap();

        let reused = session.reuse().await.unwrap().expect("connection reusable");
        let (_, prefix) = reused.into_parts();
        let prefix = prefix.expect("second request remains buffered");
        assert_eq!(prefix.as_ptr(), unsafe { base.add(req1.len()) });
        assert_eq!(prefix.as_ref(), req2);
    }

    #[tokio::test]
    async fn escaped_uri_pipeline_does_not_copy_following_requests() {
        init_log();
        let req1 = b"GET /one?q=a b HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut prefix = BytesMut::with_capacity(req1.len() + req2.len());
        prefix.extend_from_slice(req1);
        prefix.extend_from_slice(req2);
        let req2_ptr = unsafe { prefix.as_ptr().add(req1.len()) };

        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));
        session.set_pipelining_enabled(true);
        session.set_pipelined_prefix(prefix);
        session.read_request().await.unwrap();
        assert_eq!(session.get_path(), b"/one?q=a%20b");

        let reused = session.reuse().await.unwrap().expect("connection reusable");
        let (_, prefix) = reused.into_parts();
        let prefix = prefix.expect("second request remains buffered");
        assert_eq!(prefix.as_ptr(), req2_ptr);
        assert_eq!(prefix.as_ref(), req2);
    }

    /// `do_read_chunked_body` splits the post-last-chunk tail to the front of the body buffer,
    /// and `do_read_chunked_body_final` may then need several reads to find the end of the
    /// trailer section. Only the first of those passes may reuse the split buffer; the later
    /// ones reset it for fresh IO. This drives both passes with a pipelined request behind the
    /// trailers to prove neither the trailers nor the queued request are lost.
    #[tokio::test]
    async fn chunked_trailers_across_reads_keep_pipelined_request() {
        init_log();
        let req1_head =
            b"POST /one HTTP/1.1\r\nHost: pingora.org\r\nTransfer-Encoding: chunked\r\n\r\n";
        // Ends mid trailer section: the final CRLF that terminates it is still on the wire.
        let req1_tail = b"1\r\na\r\n0\r\nX-Test: one\r\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut rest = BytesMut::from(&b"\r\n"[..]);
        rest.extend_from_slice(req2);

        let mut prefix = BytesMut::with_capacity(req1_head.len() + req1_tail.len());
        prefix.extend_from_slice(req1_head);
        prefix.extend_from_slice(req1_tail);

        let mock_io = Builder::new().read(&rest).build();
        let mut session = HttpSession::new(Box::new(mock_io));
        session.set_pipelining_enabled(true);
        session.set_pipelined_prefix(prefix);
        session.read_request().await.unwrap();
        assert_eq!(session.req_header().uri.path(), "/one");

        let mut body = BytesMut::new();
        while let Some(chunk) = session.read_body_bytes().await.unwrap() {
            body.extend_from_slice(&chunk);
        }
        assert_eq!(body.as_ref(), b"a");

        let reused = session.reuse().await.unwrap().expect("connection reusable");
        let (stream, prefix) = reused.into_parts();
        let prefix = prefix.expect("second request remains buffered");
        assert_eq!(prefix.as_ref(), req2);

        let mut next = HttpSession::new(stream);
        next.set_pipelining_enabled(true);
        next.set_pipelined_prefix(prefix);
        next.read_request()
            .await
            .unwrap()
            .expect("pipelined request must parse");
        assert_eq!(next.req_header().uri.path(), "/two");
    }

    /// The URI-escape path detaches everything past the first CRLFCRLF, but httparse also
    /// accepts bare LF line endings, so the real header can end earlier than that. The detached
    /// suffix must be stitched back behind the leftover bytes, otherwise the queued request is
    /// silently dropped (or, worse, mis-attributed) instead of being served.
    #[tokio::test]
    async fn escaped_uri_with_bare_lf_keeps_all_pipelined_bytes() {
        init_log();
        let req1 = b"GET /one?q=a b HTTP/1.1\nHost: pingora.org\n\n";
        let req2 = b"GET /two HTTP/1.1\r\nHost: pingora.org\r\n\r\n";
        let mut prefix = BytesMut::with_capacity(req1.len() + req2.len());
        prefix.extend_from_slice(req1);
        prefix.extend_from_slice(req2);

        let mock_io = Builder::new().build();
        let mut session = HttpSession::new(Box::new(mock_io));
        session.set_pipelining_enabled(true);
        session.set_pipelined_prefix(prefix);
        session.read_request().await.unwrap();
        assert_eq!(session.get_path(), b"/one?q=a%20b");

        let reused = session.reuse().await.unwrap().expect("connection reusable");
        let (stream, prefix) = reused.into_parts();
        let prefix = prefix.expect("second request remains buffered");
        assert_eq!(prefix.as_ref(), req2);

        let mut next = HttpSession::new(stream);
        next.set_pipelining_enabled(true);
        next.set_pipelined_prefix(prefix);
        next.read_request()
            .await
            .unwrap()
            .expect("pipelined request must parse");
        assert_eq!(next.req_header().uri.path(), "/two");
    }

    #[tokio::test]
    async fn long_bodyless_pipeline_keeps_one_allocation() {
        init_log();
        const REQUESTS: usize = 256;
        let requests: Vec<_> = (0..REQUESTS)
            .map(|i| format!("GET /{i} HTTP/1.1\r\nHost: pingora.org\r\n\r\n"))
            .collect();
        let mut prefix = BytesMut::with_capacity(requests.iter().map(String::len).sum());
        for request in &requests {
            prefix.extend_from_slice(request.as_bytes());
        }
        let mut expected_ptr = prefix.as_ptr();
        let mock_io = Builder::new().build();
        let mut stream: Stream = Box::new(mock_io);

        for (i, request) in requests.iter().enumerate() {
            assert_eq!(prefix.as_ptr(), expected_ptr);
            let mut session = HttpSession::new(stream);
            session.set_pipelining_enabled(true);
            session.set_pipelined_prefix(prefix);
            session.read_request().await.unwrap();
            assert_eq!(session.req_header().uri.path(), format!("/{i}"));

            let reused = session.reuse().await.unwrap().expect("connection reusable");
            let (next_stream, next_prefix) = reused.into_parts();
            stream = next_stream;
            expected_ptr = unsafe { expected_ptr.add(request.len()) };
            prefix = next_prefix.unwrap_or_default();
        }

        assert!(prefix.is_empty());
    }
}
