// Copyright 2026 Cloudflare, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#[cfg(feature = "any_tls")]
use super::cert;
use async_trait::async_trait;
use clap::Parser;
use http::header::{ACCEPT_ENCODING, CONNECTION, CONTENT_LENGTH, TRANSFER_ENCODING, UPGRADE, VARY};
use http::HeaderValue;
use log::error;
use once_cell::sync::Lazy;
use pingora_cache::admission::{AdmissionPolicy, Decision};
use pingora_cache::cache_control::CacheControl;
use pingora_cache::hashtable::ConcurrentHashTable;
use pingora_cache::key::HashBinary;
use pingora_cache::lock::CacheKeyLockImpl;
use pingora_cache::storage::{HandleMiss, MissFinishType, Storage};
use pingora_cache::{
    eviction::simple_lru::Manager, filters::resp_cacheable, lock::CacheLock, predictor::Predictor,
    set_compression_dict_path, CacheKey, CacheMeta, CacheMetaDefaults, CachePhase, MemCache,
    NoCacheReason, RespCacheable,
};
use pingora_cache::{
    CacheOptionOverrides, ForcedFreshness, HitHandler, PurgeAction, PurgeType, VarianceBuilder,
};
use pingora_core::apps::{HttpServerApp, HttpServerOptions};
use pingora_core::modules::http::compression::ResponseCompression;
use pingora_core::protocols::{
    http::error_resp::gen_error_response, l4::socket::SocketAddr, Digest,
};
use pingora_core::server::configuration::Opt;
use pingora_core::services::{Service, ServiceWithDependents};
use pingora_core::upstreams::peer::{H1UpgradePolicy, HttpPeer, HttpUpstreamRequestPolicy};
use pingora_core::utils::tls::CertKey;
use pingora_error::{Error, ErrorSource, ErrorType::*, Result};
use pingora_http::{RequestHeader, ResponseHeader};
use pingora_proxy::{FailToProxy, ProxyHttp, ProxyWarnLogContext, Session};
use std::collections::{HashMap, HashSet};
use std::sync::{
    atomic::{AtomicUsize, Ordering},
    Arc,
};
use std::thread;
use std::time::{Duration, SystemTime};

pub struct ExampleProxyHttps {}

pub const TEST_PSK_IDENTITY: &str = "test-psk-identity";
pub const TEST_PSK_SECRET: &str = "i2Wx8jrYVi5Vt7HSL/fsk003+PnmfcFuwWMsUyQvcZ4=";

#[allow(clippy::upper_case_acronyms)]
#[derive(Default)]
pub struct CTX {
    conn_reused: bool,
    upstream_client_addr: Option<SocketAddr>,
    upstream_server_addr: Option<SocketAddr>,
}

// Common logic for both ProxyHttp(s) types
fn connected_to_upstream_common(
    reused: bool,
    digest: Option<&Digest>,
    ctx: &mut CTX,
) -> Result<()> {
    ctx.conn_reused = reused;
    let socket_digest = digest
        .expect("upstream connector digest should be set for HTTP sessions")
        .socket_digest
        .as_ref()
        .expect("socket digest should be set for HTTP sessions");
    ctx.upstream_client_addr = socket_digest.local_addr().cloned();
    ctx.upstream_server_addr = socket_digest.peer_addr().cloned();

    Ok(())
}

fn response_filter_common(
    session: &mut Session,
    response: &mut ResponseHeader,
    ctx: &mut CTX,
) -> Result<()> {
    if ctx.conn_reused {
        response.insert_header("x-conn-reuse", "1")?;
    }

    let client_addr = session.client_addr();
    let server_addr = session.server_addr();
    response.insert_header(
        "x-client-addr",
        client_addr.map_or_else(|| "unset".into(), |a| a.to_string()),
    )?;
    response.insert_header(
        "x-server-addr",
        server_addr.map_or_else(|| "unset".into(), |a| a.to_string()),
    )?;

    response.insert_header(
        "x-upstream-client-addr",
        ctx.upstream_client_addr
            .as_ref()
            .map_or_else(|| "unset".into(), |a| a.to_string()),
    )?;
    response.insert_header(
        "x-upstream-server-addr",
        ctx.upstream_server_addr
            .as_ref()
            .map_or_else(|| "unset".into(), |a| a.to_string()),
    )?;

    Ok(())
}

#[async_trait]
#[cfg(feature = "any_tls")]
impl ProxyHttp for ExampleProxyHttps {
    type CTX = CTX;
    fn new_ctx(&self) -> Self::CTX {
        CTX::default()
    }

    async fn upstream_peer(
        &self,
        session: &mut Session,
        _ctx: &mut Self::CTX,
    ) -> Result<Box<HttpPeer>> {
        let session = session.as_downstream();
        let req = session.req_header();

        let port = req
            .headers
            .get("x-port")
            .map_or("8443", |v| v.to_str().unwrap());
        let sni = req.headers.get("sni").map_or("", |v| v.to_str().unwrap());
        let alt = req
            .headers
            .get("alt")
            .map(|v| v.to_str().unwrap().to_string());

        let client_cert = session.get_header_bytes("client_cert");

        let mut peer = Box::new(HttpPeer::new(
            format!("127.0.0.1:{port}"),
            true,
            sni.to_string(),
        ));
        peer.options.alternative_cn = alt;

        let verify = session.get_header_bytes("verify") == b"1";
        peer.options.verify_cert = verify;

        let verify_host = session.get_header_bytes("verify_host") == b"1";
        peer.options.verify_hostname = verify_host;

        if matches!(client_cert, b"1" | b"2") {
            let (mut certs, key) = if client_cert == b"1" {
                (vec![cert::LEAF_CERT.clone()], cert::LEAF_KEY.clone())
            } else {
                (vec![cert::LEAF2_CERT.clone()], cert::LEAF2_KEY.clone())
            };
            if session.get_header_bytes("client_intermediate") == b"1" {
                certs.push(cert::INTERMEDIATE_CERT.clone());
            }
            #[cfg(feature = "s2n")]
            {
                let combined_pem = certs.into_iter().flatten().collect();
                peer.client_cert_key = Some(Arc::new(CertKey::new(combined_pem, key)));
            }
            #[cfg(not(feature = "s2n"))]
            {
                peer.client_cert_key = Some(Arc::new(CertKey::new(certs, key)));
            }
        }

        #[cfg(feature = "s2n")]
        if let Some(psk_identity) = req.headers.get("psk_identity") {
            use pingora_core::{
                protocols::tls::{Psk, PskConfig},
                tls::PskHmac,
            };

            let psk = Psk::new(
                psk_identity.to_str().unwrap().to_string(),
                TEST_PSK_SECRET.as_bytes().to_vec(),
                PskHmac::SHA256,
            );
            peer.options.psk = Some(Arc::new(PskConfig::new(vec![psk])));
        }

        if session.get_header_bytes("x-h2") == b"true" {
            // default is 1, 1
            peer.options.set_http_version(2, 2);
        }

        Ok(peer)
    }

    async fn response_filter(
        &self,
        session: &mut Session,
        upstream_response: &mut ResponseHeader,
        ctx: &mut Self::CTX,
    ) -> Result<()>
    where
        Self::CTX: Send + Sync,
    {
        response_filter_common(session, upstream_response, ctx)
    }

    async fn upstream_request_filter(
        &self,
        session: &mut Session,
        req: &mut RequestHeader,
        _ctx: &mut Self::CTX,
    ) -> Result<()> {
        let host = session.get_header_bytes("host-override");
        if host != b"" {
            req.insert_header("host", host)?;
        }
        Ok(())
    }

    async fn connected_to_upstream(
        &self,
        _http_session: &mut Session,
        reused: bool,
        _peer: &HttpPeer,
        #[cfg(unix)] _fd: std::os::unix::io::RawFd,
        #[cfg(windows)] _sock: std::os::windows::io::RawSocket,
        digest: Option<&Digest>,
        ctx: &mut CTX,
    ) -> Result<()> {
        connected_to_upstream_common(reused, digest, ctx)
    }
}

pub struct ExampleProxyHttp {}

static SUPPRESS_PROXY_WARN_LOG_CALLS: AtomicUsize = AtomicUsize::new(0);

pub fn reset_suppress_proxy_warn_log_calls() {
    SUPPRESS_PROXY_WARN_LOG_CALLS.store(0, Ordering::Relaxed);
}

pub fn suppress_proxy_warn_log_calls() -> usize {
    SUPPRESS_PROXY_WARN_LOG_CALLS.load(Ordering::Relaxed)
}

#[async_trait]
impl ProxyHttp for ExampleProxyHttp {
    type CTX = CTX;
    fn new_ctx(&self) -> Self::CTX {
        CTX::default()
    }

    async fn early_request_filter(
        &self,
        session: &mut Session,
        _ctx: &mut Self::CTX,
    ) -> Result<()> {
        let proxy_tasks_enabled = session
            .req_header()
            .headers
            .get("x-proxy-tasks-enabled")
            .is_some();
        if proxy_tasks_enabled {
            session.downstream_session.set_proxy_tasks_enabled(true);
        }
        let downstream_compression = session
            .req_header()
            .headers
            .get("x-downstream-compression")
            .is_some();
        if downstream_compression {
            session
                .downstream_modules_ctx
                .get_mut::<ResponseCompression>()
                .unwrap()
                .adjust_level(6);
        } else {
            // enable upstream compression for all requests by default
            session.upstream_compression.adjust_level(6);
        }
        Ok(())
    }

    async fn request_filter(&self, session: &mut Session, _ctx: &mut Self::CTX) -> Result<bool> {
        let req = session.req_header();

        let write_timeout = req
            .headers
            .get("x-write-timeout")
            .and_then(|v| v.to_str().ok().and_then(|v| v.parse().ok()));

        let min_rate = req
            .headers
            .get("x-min-rate")
            .and_then(|v| v.to_str().ok().and_then(|v| v.parse().ok()));

        let close_on_response_before_downstream_finish = req
            .headers
            .get("x-close-on-response-before-downstream-finish")
            .is_some();

        let downstream_compression = req.headers.get("x-downstream-compression").is_some();
        if !downstream_compression {
            // enable upstream compression for all requests by default
            session.upstream_compression.adjust_level(6);
            // also disable downstream compression in order to test the upstream one
            session
                .downstream_modules_ctx
                .get_mut::<ResponseCompression>()
                .unwrap()
                .adjust_level(0);
        }

        session.set_min_send_rate(min_rate);
        session.set_write_timeout(write_timeout.map(Duration::from_secs));
        session.set_close_on_response_before_downstream_finish(
            close_on_response_before_downstream_finish,
        );

        Ok(false)
    }

    async fn response_filter(
        &self,
        session: &mut Session,
        upstream_response: &mut ResponseHeader,
        ctx: &mut Self::CTX,
    ) -> Result<()> {
        response_filter_common(session, upstream_response, ctx)
    }

    async fn request_body_filter(
        &self,
        session: &mut Session,
        body: &mut Option<bytes::Bytes>,
        _end_of_stream: bool,
        _ctx: &mut Self::CTX,
    ) -> Result<()> {
        if session
            .req_header()
            .headers
            .contains_key("x-upstream-discard-body")
        {
            *body = None;
        }
        Ok(())
    }

    async fn upstream_request_filter(
        &self,
        session: &mut Session,
        req: &mut RequestHeader,
        _ctx: &mut Self::CTX,
    ) -> Result<()> {
        let host = session.get_header_bytes("host-override");
        if !host.is_empty() {
            req.insert_header("host", host)?;
        }
        if session
            .req_header()
            .headers
            .contains_key("x-upstream-delete-host")
        {
            req.remove_header(&http::header::HOST);
        }

        // Test-only hook: deliberately declare a larger outbound body than the valid
        // downstream HTTP request contains. Built-in HTTP downstream parsing would reject
        // a client that directly ended a shorter-than-declared body; this hook lets tests
        // exercise defense in depth for downstream sessions that do not report incomplete
        // body errors or upstream request mutations that reach that state.
        if let Some(content_length) = session
            .req_header()
            .headers
            .get("x-upstream-content-length")
        {
            req.insert_header(CONTENT_LENGTH, content_length.clone())?;
            req.remove_header(&TRANSFER_ENCODING);
        }
        if session
            .req_header()
            .headers
            .contains_key("x-upstream-strip-framing")
        {
            req.remove_header(&CONTENT_LENGTH);
            req.remove_header(&TRANSFER_ENCODING);
        }
        if session
            .req_header()
            .headers
            .contains_key("x-upstream-add-upgrade")
        {
            req.insert_header(CONNECTION, "Upgrade")?;
            req.insert_header(UPGRADE, "websocket")?;
        }
        Ok(())
    }

    async fn upstream_peer(
        &self,
        session: &mut Session,
        _ctx: &mut Self::CTX,
    ) -> Result<Box<HttpPeer>> {
        let req = session.req_header();
        #[cfg(unix)]
        if req.headers.contains_key("x-uds-peer") {
            return Ok(Box::new(HttpPeer::new_uds(
                "/tmp/pingora_nginx_test.sock",
                false,
                "".to_string(),
            )?));
        }
        let port = req
            .headers
            .get("x-port")
            .map_or("8000", |v| v.to_str().unwrap());

        let mut peer = Box::new(HttpPeer::new(
            format!("127.0.0.1:{port}"),
            false,
            "".to_string(),
        ));

        if session.get_header_bytes("x-h2") == b"true" {
            // default is 1, 1
            peer.options.set_http_version(2, 2);
        }

        if req
            .headers
            .contains_key("x-preserve-upstream-request-headers")
        {
            peer.options.http_upstream_request_policy = HttpUpstreamRequestPolicy::preserve();
        } else if req.headers.contains_key("x-preserve-upstream-upgrade") {
            peer.options.http_upstream_request_policy.h1_upgrade = H1UpgradePolicy::Preserve;
        } else if req.headers.contains_key("x-preserve-connection-nominated") {
            peer.options
                .http_upstream_request_policy
                .strip_connection_nominated = false;
        }

        if let Some(ms) = req
            .headers
            .get("x-read-timeout-ms")
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.parse::<u64>().ok())
        {
            peer.options.read_timeout = Some(std::time::Duration::from_millis(ms));
        }

        Ok(peer)
    }

    async fn connected_to_upstream(
        &self,
        _http_session: &mut Session,
        reused: bool,
        _peer: &HttpPeer,
        #[cfg(unix)] _fd: std::os::unix::io::RawFd,
        #[cfg(windows)] _sock: std::os::windows::io::RawSocket,
        digest: Option<&Digest>,
        ctx: &mut CTX,
    ) -> Result<()> {
        connected_to_upstream_common(reused, digest, ctx)
    }

    fn suppress_proxy_warn_log(
        &self,
        session: &Session,
        _ctx: &Self::CTX,
        _error: &Error,
        context: ProxyWarnLogContext,
    ) -> bool {
        if session.get_header_bytes("x-test-suppress-proxy-warn-log") == b"true"
            && context == ProxyWarnLogContext::UpstreamRetry
        {
            SUPPRESS_PROXY_WARN_LOG_CALLS.fetch_add(1, Ordering::Relaxed);
            true
        } else {
            false
        }
    }
}

static CACHE_BACKEND: Lazy<MemCache> = Lazy::new(MemCache::new);
static CACHE_FINISH_FAIL_BACKEND: FinishFailCache = FinishFailCache;
const CACHE_DEFAULT: CacheMetaDefaults =
    CacheMetaDefaults::new(|_| Some(Duration::from_secs(1)), 1, 1);
static CACHE_PREDICTOR: Lazy<Predictor<32>> = Lazy::new(|| Predictor::new(5, None));
static EVICTION_MANAGER: Lazy<Manager> = Lazy::new(|| Manager::new(8192)); // 8192 bytes
static CACHE_LOCK: Lazy<Box<CacheKeyLockImpl>> =
    Lazy::new(|| CacheLock::new_boxed(std::time::Duration::from_secs(2)));
static DEFER_ADMISSION_POLICY: DeferAdmissionPolicy = DeferAdmissionPolicy;
// Example of how one might restrict which fields can be varied on.
static CACHE_VARY_ALLOWED_HEADERS: Lazy<Option<HashSet<&str>>> =
    Lazy::new(|| Some(vec!["accept", "accept-encoding"].into_iter().collect()));

struct DeferAdmissionPolicy;

impl AdmissionPolicy for DeferAdmissionPolicy {
    fn observe(&self, _key: &CacheKey) -> Decision {
        Decision::Defer { observed: 1 }
    }
}

struct FinishFailCache;

#[async_trait]
impl Storage for FinishFailCache {
    async fn lookup(
        &'static self,
        _key: &CacheKey,
        _trace: &pingora_cache::trace::SpanHandle,
    ) -> Result<Option<(CacheMeta, HitHandler)>> {
        Ok(None)
    }

    async fn get_miss_handler(
        &'static self,
        _key: &CacheKey,
        _meta: &CacheMeta,
        _trace: &pingora_cache::trace::SpanHandle,
    ) -> Result<pingora_cache::MissHandler> {
        Ok(Box::new(FinishFailMissHandler))
    }

    async fn purge(
        &'static self,
        _target: pingora_cache::PurgeTarget<'_>,
        _purge_type: PurgeType,
        _trace: &pingora_cache::trace::SpanHandle,
    ) -> Result<pingora_cache::storage::PurgeOutcome> {
        Ok(pingora_cache::storage::PurgeOutcome::NotFound)
    }

    async fn update_meta(
        &'static self,
        _key: &CacheKey,
        _meta: &CacheMeta,
        _trace: &pingora_cache::trace::SpanHandle,
    ) -> Result<bool> {
        Ok(false)
    }

    fn as_any(&self) -> &(dyn std::any::Any + Send + Sync + 'static) {
        self
    }
}

struct FinishFailMissHandler;

#[async_trait]
impl HandleMiss for FinishFailMissHandler {
    async fn write_body(&mut self, _data: bytes::Bytes, _eof: bool) -> Result<()> {
        Ok(())
    }

    async fn finish(self: Box<Self>) -> Result<MissFinishType> {
        Error::e_explain(FileWriteError, "cache miss finalization failed")
    }
}

// #[allow(clippy::upper_case_acronyms)]
pub struct CacheCTX {
    upstream_status: Option<u16>,
}

pub struct ExampleProxyCache {}

static DOWNSTREAM_CACHE_WARN_LOG_CALLS: AtomicUsize = AtomicUsize::new(0);

/// How many times the cache proxy has reported a downstream error that it ignored in order
/// to let a cache fill finish.
///
/// Tests use this to wait for the proxy to actually observe a downstream error instead of
/// sleeping for an arbitrary duration.
pub fn downstream_cache_warn_log_calls() -> usize {
    DOWNSTREAM_CACHE_WARN_LOG_CALLS.load(Ordering::Relaxed)
}

#[async_trait]
impl ProxyHttp for ExampleProxyCache {
    type CTX = CacheCTX;
    fn new_ctx(&self) -> Self::CTX {
        CacheCTX {
            upstream_status: None,
        }
    }

    async fn early_request_filter(
        &self,
        session: &mut Session,
        _ctx: &mut Self::CTX,
    ) -> Result<()> {
        if session
            .req_header()
            .headers
            .get("x-downstream-compression")
            .is_some()
        {
            session
                .downstream_modules_ctx
                .get_mut::<ResponseCompression>()
                .unwrap()
                .adjust_level(6);
        }
        if session
            .req_header()
            .headers
            .get("x-downstream-decompression")
            .is_some()
        {
            session
                .downstream_modules_ctx
                .get_mut::<ResponseCompression>()
                .unwrap()
                .adjust_decompression(true);
        }
        Ok(())
    }

    async fn upstream_peer(
        &self,
        session: &mut Session,
        _ctx: &mut Self::CTX,
    ) -> Result<Box<HttpPeer>> {
        let req = session.req_header();
        let port = req
            .headers
            .get("x-port")
            .map_or("8000", |v| v.to_str().unwrap());

        let mut peer = Box::new(HttpPeer::new(
            format!("127.0.0.1:{}", port),
            false,
            "".to_string(),
        ));

        if session.get_header_bytes("x-h2") == b"true" {
            // default is 1, 1
            peer.options.set_http_version(2, 2);
        }

        Ok(peer)
    }

    fn request_cache_filter(&self, session: &mut Session, _ctx: &mut Self::CTX) -> Result<()> {
        // TODO: only allow GET & HEAD

        if session.get_header_bytes("x-bypass-cache") != b"" {
            return Ok(());
        }

        // turn on eviction only for some requests to avoid interference across tests
        let eviction = session.req_header().headers.get("x-eviction").map(|_| {
            &*EVICTION_MANAGER as &'static (dyn pingora_cache::eviction::EvictionManager + Sync)
        });
        let lock = session
            .req_header()
            .headers
            .get("x-lock")
            .map(|_| CACHE_LOCK.as_ref());
        let mut overrides = CacheOptionOverrides::default();
        overrides.wait_timeout = Some(Duration::from_secs(2));
        let storage = if session
            .req_header()
            .headers
            .contains_key("x-cache-fail-finish")
        {
            &CACHE_FINISH_FAIL_BACKEND as &'static (dyn Storage + Sync)
        } else {
            &*CACHE_BACKEND as &'static (dyn Storage + Sync)
        };

        session.cache.enable(
            storage,
            eviction,
            Some(&*CACHE_PREDICTOR),
            lock,
            Some(overrides),
        );

        if session
            .req_header()
            .headers
            .contains_key("x-defer-cache-admission")
        {
            session.cache.set_admission_policy(&DEFER_ADMISSION_POLICY);
        }

        if let Some(max_file_size_hdr) = session
            .req_header()
            .headers
            .get("x-cache-max-file-size-bytes")
        {
            let bytes = max_file_size_hdr
                .to_str()
                .unwrap()
                .parse::<usize>()
                .unwrap();
            session.cache.set_max_file_size_bytes(bytes);
        }

        Ok(())
    }

    /// Reference `cache_key_callback` implementation for integration tests.
    ///
    /// Builds the primary key as `{host}{path_and_query}` from the request.
    /// This is **not production ready**: it does not account for `Vary`, custom
    /// request filters, or scheme differences. See the rustdoc on
    /// [`ProxyHttp::cache_key_callback`] for details.
    fn cache_key_callback(&self, session: &Session, _ctx: &mut Self::CTX) -> Result<CacheKey> {
        let req_header = session.req_header();

        let host = req_header
            .headers
            .get(http::header::HOST)
            .and_then(|v| v.to_str().ok())
            .or_else(|| req_header.uri.authority().map(|a| a.as_str()))
            .unwrap_or("");

        let path_and_query = req_header
            .uri
            .path_and_query()
            .map(|pq| pq.as_str())
            .unwrap_or("/");

        Ok(CacheKey::new(
            format!("{host}{path_and_query}"),
            String::new(),
        ))
    }

    async fn cache_hit_filter(
        &self,
        session: &mut Session,
        _meta: &CacheMeta,
        _hit_handler: &mut HitHandler,
        is_fresh: bool,
        _ctx: &mut Self::CTX,
    ) -> Result<Option<ForcedFreshness>> {
        // allow test header to control force expiry/miss
        if session.get_header_bytes("x-force-miss") != b"" {
            return Ok(Some(ForcedFreshness::ForceMiss));
        }

        if !is_fresh {
            if session.get_header_bytes("x-force-fresh") != b"" {
                return Ok(Some(ForcedFreshness::ForceFresh));
            }
            // already expired
            return Ok(None);
        }

        if session.get_header_bytes("x-force-expire") != b"" {
            return Ok(Some(ForcedFreshness::ForceExpired));
        }

        if session.get_header_bytes("x-force-expire-serve-stale") != b"" {
            // `x-expired-secs-ago` backdates the expiry, which is how a test reaches an
            // asset whose serve stale window has already run out at the point it expired.
            let secs_ago = std::str::from_utf8(session.get_header_bytes("x-expired-secs-ago"))
                .ok()
                .and_then(|v| v.parse::<u64>().ok())
                .unwrap_or(0);
            return Ok(Some(ForcedFreshness::ForceExpiredServeStale {
                expired_at: SystemTime::now().checked_sub(Duration::from_secs(secs_ago)),
            }));
        }
        Ok(None)
    }

    fn cache_vary_filter(
        &self,
        meta: &CacheMeta,
        _ctx: &mut Self::CTX,
        req: &RequestHeader,
    ) -> Option<HashBinary> {
        let mut key = VarianceBuilder::new();

        // Vary per header from origin. Target headers are de-duplicated by key logic.
        let vary_headers_lowercased: Vec<String> = meta
            .headers()
            .get_all(VARY)
            .iter()
            // Filter out any unparseable vary headers.
            .flat_map(|vary_header| vary_header.to_str().ok())
            .flat_map(|vary_header| vary_header.split(','))
            .map(|s| s.trim().to_lowercase())
            .filter(|header_name| {
                // Filter only for allowed headers, if restricted.
                CACHE_VARY_ALLOWED_HEADERS
                    .as_ref()
                    .map(|al| al.contains(header_name.as_str()))
                    .unwrap_or(true)
            })
            .collect();

        vary_headers_lowercased.iter().for_each(|header_name| {
            // Add this header and value to be considered in the variance key.
            key.add_value(
                header_name,
                req.headers
                    .get(header_name)
                    .map(|v| v.as_bytes())
                    .unwrap_or(&[]),
            );
        });

        key.finalize()
    }

    async fn upstream_request_filter(
        &self,
        session: &mut Session,
        upstream_request: &mut RequestHeader,
        _ctx: &mut Self::CTX,
    ) -> Result<()> {
        if let Some(up_accept_encoding) = session
            .req_header()
            .headers
            .get("x-upstream-accept-encoding")
        {
            upstream_request.insert_header(&ACCEPT_ENCODING, up_accept_encoding)?;
        }
        Ok(())
    }

    fn response_cache_filter(
        &self,
        session: &Session,
        resp: &ResponseHeader,
        _ctx: &mut Self::CTX,
    ) -> Result<RespCacheable> {
        // Allow testing the unlikely case of caching a 101 response
        if resp.status == 101
            && session
                .req_header()
                .headers
                .contains_key("x-cache-websocket")
        {
            return Ok(RespCacheable::Cacheable(CacheMeta::new(
                SystemTime::now() + Duration::from_secs(5),
                SystemTime::now(),
                0,
                0,
                resp.clone(),
            )));
        }

        let cc = CacheControl::from_resp_headers(resp);
        Ok(resp_cacheable(
            cc.as_ref(),
            resp.clone(),
            false,
            &CACHE_DEFAULT,
        ))
    }

    async fn upstream_response_filter(
        &self,
        session: &mut Session,
        upstream_response: &mut ResponseHeader,
        ctx: &mut Self::CTX,
    ) -> Result<()> {
        ctx.upstream_status = Some(upstream_response.status.into());
        if session
            .req_header()
            .headers
            .contains_key("x-upstream-fake-http10")
        {
            // TODO to simulate an actual http1.0 origin
            upstream_response.set_version(http::Version::HTTP_10);
            upstream_response.remove_header(&CONTENT_LENGTH);
            upstream_response.remove_header(&TRANSFER_ENCODING);
        }
        // Allow tests to inject Cache-Control into the upstream response
        if let Some(cc) = session.req_header().headers.get("x-set-cache-control") {
            upstream_response
                .insert_header(http::header::CACHE_CONTROL, cc)
                .unwrap();
        }
        Ok(())
    }

    async fn response_filter(
        &self,
        session: &mut Session,
        upstream_response: &mut ResponseHeader,
        ctx: &mut Self::CTX,
    ) -> Result<()>
    where
        Self::CTX: Send + Sync,
    {
        if session.cache.enabled() {
            match session.cache.phase() {
                CachePhase::Hit => upstream_response.insert_header("x-cache-status", "hit")?,
                CachePhase::Miss => upstream_response.insert_header("x-cache-status", "miss")?,
                CachePhase::Stale => upstream_response.insert_header("x-cache-status", "stale")?,
                CachePhase::StaleUpdating => {
                    upstream_response.insert_header("x-cache-status", "stale-updating")?
                }
                CachePhase::Expired => {
                    upstream_response.insert_header("x-cache-status", "expired")?
                }
                CachePhase::Revalidated | CachePhase::RevalidatedNoCache(_) => {
                    upstream_response.insert_header("x-cache-status", "revalidated")?
                }
                _ => upstream_response.insert_header("x-cache-status", "invalid")?,
            }
        } else {
            match session.cache.phase() {
                CachePhase::Disabled(NoCacheReason::Deferred) => {
                    upstream_response.insert_header("x-cache-status", "deferred")?;
                }
                _ => upstream_response.insert_header("x-cache-status", "no-cache")?,
            }
        }
        if let Some(d) = session.cache.lock_duration() {
            upstream_response.insert_header("x-cache-lock-time-ms", format!("{}", d.as_millis()))?
        }
        if let Some(up_stat) = ctx.upstream_status {
            upstream_response.insert_header("x-upstream-status", up_stat.to_string())?;
        }
        Ok(())
    }

    async fn fail_to_proxy(
        &self,
        session: &mut Session,
        e: &Error,
        _ctx: &mut Self::CTX,
    ) -> FailToProxy
    where
        Self::CTX: Send + Sync,
    {
        // default OSS fail_to_proxy with added headers
        let code = match e.etype() {
            HTTPStatus(code) => *code,
            _ => {
                match e.esource() {
                    ErrorSource::Upstream => 502,
                    ErrorSource::Downstream => {
                        match e.etype() {
                            WriteError | ReadError | ConnectionClosed => {
                                /* conn already dead */
                                0
                            }
                            _ => 400,
                        }
                    }
                    ErrorSource::Internal | ErrorSource::Unset => 500,
                }
            }
        };
        if code > 0 {
            let mut resp = gen_error_response(code);
            // any relevant metadata headers to add
            if let Some(d) = session.cache.lock_duration() {
                resp.insert_header("x-cache-lock-time-ms", format!("{}", d.as_millis()))
                    .unwrap();
            }
            session
                .write_response_header(Box::new(resp), true)
                .await
                .unwrap_or_else(|e| {
                    error!("failed to send error response to downstream: {e}");
                });
        }

        FailToProxy {
            error_code: code,
            // default to no reuse, which is safest
            can_reuse_downstream: false,
        }
    }

    fn should_serve_stale(
        &self,
        _session: &mut Session,
        _ctx: &mut Self::CTX,
        error: Option<&Error>, // None when it is called during stale while revalidate
    ) -> bool {
        // enable serve stale while updating
        error.is_none_or(|e| e.esource() == &ErrorSource::Upstream)
    }

    fn is_purge(&self, session: &Session, _ctx: &Self::CTX) -> bool {
        session.req_header().method == "PURGE"
    }

    fn purge_action(&self, session: &Session, _ctx: &Self::CTX) -> PurgeAction {
        if session.get_header_bytes("x-purge-action") == b"expire" {
            PurgeAction::Expire
        } else {
            PurgeAction::Delete
        }
    }

    fn suppress_proxy_warn_log(
        &self,
        _session: &Session,
        _ctx: &Self::CTX,
        _error: &Error,
        context: ProxyWarnLogContext,
    ) -> bool {
        if context == ProxyWarnLogContext::DownstreamCache {
            DOWNSTREAM_CACHE_WARN_LOG_CALLS.fetch_add(1, Ordering::Relaxed);
        }
        // only observing, keep the logging behavior unchanged
        false
    }
}

fn test_main() {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

    let opts: Vec<String> = vec![
        "pingora-proxy".into(),
        "-c".into(),
        "tests/pingora_conf.yaml".into(),
    ];
    let mut my_server =
        pingora_core::server::Server::new(Some(Opt::parse_from_args(opts))).unwrap();
    my_server.bootstrap();

    let mut proxy_service_http =
        pingora_proxy::http_proxy_service(&my_server.configuration, ExampleProxyHttp {});
    proxy_service_http.add_tcp("0.0.0.0:6147");
    #[cfg(unix)]
    proxy_service_http.add_uds("/tmp/pingora_proxy.sock", None);

    let mut proxy_service_http_connect =
        pingora_proxy::http_proxy_service(&my_server.configuration, ExampleProxyHttp {});
    let http_logic = proxy_service_http_connect.app_logic_mut().unwrap();
    let mut http_server_options = HttpServerOptions::default();
    http_server_options.allow_connect_method_proxying = true;
    http_logic.server_options = Some(http_server_options);
    proxy_service_http_connect.add_tcp("0.0.0.0:6160");

    let mut proxy_service_h2c =
        pingora_proxy::http_proxy_service(&my_server.configuration, ExampleProxyHttp {});

    let http_logic = proxy_service_h2c.app_logic_mut().unwrap();
    let mut http_server_options = HttpServerOptions::default();
    http_server_options.h2c = true;
    http_logic.server_options = Some(http_server_options);
    proxy_service_h2c.add_tcp("0.0.0.0:6146");

    let mut proxy_service_https_opt: Option<Box<dyn ServiceWithDependents>> = None;

    #[cfg(feature = "any_tls")]
    {
        let mut proxy_service_https =
            pingora_proxy::http_proxy_service(&my_server.configuration, ExampleProxyHttps {});
        proxy_service_https.add_tcp("0.0.0.0:6149");
        let cert_path = format!("{}/tests/keys/server.crt", env!("CARGO_MANIFEST_DIR"));
        let key_path = format!("{}/tests/keys/key.pem", env!("CARGO_MANIFEST_DIR"));
        let mut tls_settings =
            pingora_core::listeners::tls::TlsSettings::intermediate(&cert_path, &key_path).unwrap();
        tls_settings.enable_h2();
        proxy_service_https.add_tls_with_settings("0.0.0.0:6150", None, tls_settings);
        proxy_service_https_opt = Some(Box::new(proxy_service_https))
    }

    let mut proxy_service_cache =
        pingora_proxy::http_proxy_service(&my_server.configuration, ExampleProxyCache {});
    proxy_service_cache.add_tcp("0.0.0.0:6148");

    // H2C-enabled cache proxy on port 6154
    let mut proxy_service_cache_h2c =
        pingora_proxy::http_proxy_service(&my_server.configuration, ExampleProxyCache {});
    let cache_h2c_logic = proxy_service_cache_h2c.app_logic_mut().unwrap();
    let mut cache_h2c_options = HttpServerOptions::default();
    cache_h2c_options.h2c = true;
    cache_h2c_logic.server_options = Some(cache_h2c_options);
    proxy_service_cache_h2c.add_tcp("0.0.0.0:6154");

    #[cfg(feature = "any_tls")]
    {
        let cert_path = format!("{}/tests/keys/server.crt", env!("CARGO_MANIFEST_DIR"));
        let key_path = format!("{}/tests/keys/key.pem", env!("CARGO_MANIFEST_DIR"));

        let mut tls_settings =
            pingora_core::listeners::tls::TlsSettings::intermediate(&cert_path, &key_path).unwrap();
        tls_settings.enable_h2();
        proxy_service_cache.add_tls_with_settings("0.0.0.0:6153", None, tls_settings);
    }

    let mut services: Vec<Box<dyn ServiceWithDependents>> = vec![
        Box::new(proxy_service_h2c),
        Box::new(proxy_service_http),
        Box::new(proxy_service_http_connect),
        Box::new(proxy_service_cache),
        Box::new(proxy_service_cache_h2c),
    ];

    if let Some(proxy_service_https) = proxy_service_https_opt {
        services.push(proxy_service_https)
    }

    set_compression_dict_path("tests/headers.dict");
    my_server.add_services(services);
    my_server.run_forever();
}

pub struct Server {
    pub handle: thread::JoinHandle<()>,
}

impl Server {
    pub fn start() -> Self {
        let server_handle = thread::spawn(|| {
            test_main();
        });
        Server {
            handle: server_handle,
        }
    }
}

#[cfg(feature = "s2n")]
pub struct PskTlsServer {
    pub handle: thread::JoinHandle<()>,
}

#[cfg(feature = "s2n")]
impl PskTlsServer {
    pub fn start() -> Self {
        use std::sync::mpsc;
        use std::time::Duration;

        // Use a channel to wait for the server to bind its port.
        // A TCP probe can't be used here because the TLS acceptor would
        // try to handshake the probe connection, fail, and panic.
        let (tx, rx) = mpsc::channel();
        let server_handle = thread::spawn(move || {
            let rt = tokio::runtime::Runtime::new().unwrap();
            rt.block_on(Self::run_server(tx));
        });

        // Wait up to 10s for the server to signal it has bound the port.
        rx.recv_timeout(Duration::from_secs(10))
            .expect("PSK TLS server failed to start within 10s");

        PskTlsServer {
            handle: server_handle,
        }
    }

    async fn run_server(ready_tx: std::sync::mpsc::Sender<()>) {
        use pingora_core::{protocols::tls::S2NConnectionBuilder, tls::TlsAcceptor};
        use pingora_core::{
            protocols::tls::{Psk, PskConfig, PskType},
            tls::{Config, PskHmac, S2NPolicy, DEFAULT_TLS13},
        };
        use tokio::net::TcpListener;

        let psk = Psk::new(
            TEST_PSK_IDENTITY.to_string(),
            TEST_PSK_SECRET.as_bytes().to_vec(),
            PskHmac::SHA256,
        );
        let psk_config = Arc::new(PskConfig::new(vec![psk]));

        let addr: std::net::SocketAddr = "127.0.0.1:6151".parse().unwrap();
        let listener = TcpListener::bind(addr).await.unwrap();
        let _ = ready_tx.send(()); // signal: port is bound

        let mut config_builder = Config::builder();
        unsafe {
            config_builder.disable_x509_verification();
        }
        config_builder.set_security_policy(&DEFAULT_TLS13).unwrap();
        let config = config_builder.build().unwrap();

        let connection_builder = S2NConnectionBuilder {
            config: config.clone(),
            psk_config: Some(psk_config.clone()),
            security_policy: None,
        };

        let acceptor = TlsAcceptor::new(connection_builder);

        loop {
            use tokio::io::AsyncWriteExt;
            let (tcp_stream, _) = listener.accept().await.unwrap();
            // Don't panic on handshake failure — a stale connection or probe
            // shouldn't take down the server for subsequent real connections.
            let mut stream = match acceptor.clone().accept(tcp_stream).await {
                Ok(s) => s,
                Err(e) => {
                    log::warn!("PSK TLS server: handshake failed: {e}");
                    continue;
                }
            };
            let response = b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello";
            let _ = stream.write_all(response).await;
            let _ = stream.shutdown().await;
        }
    }
}

// FIXME: this still allows multiple servers to spawn across integration tests
pub static TEST_SERVER: Lazy<Server> = Lazy::new(Server::start);
#[cfg(feature = "s2n")]
pub static TEST_PSK_TLS_SERVER: Lazy<PskTlsServer> = Lazy::new(PskTlsServer::start);
use super::mock_origin::MOCK_ORIGIN;

pub fn init() {
    let _ = *TEST_SERVER;
    let _ = *MOCK_ORIGIN;
    #[cfg(feature = "s2n")]
    let _ = *TEST_PSK_TLS_SERVER;
}
