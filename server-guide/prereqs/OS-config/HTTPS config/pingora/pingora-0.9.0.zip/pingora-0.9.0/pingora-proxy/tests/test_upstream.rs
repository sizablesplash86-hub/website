// Copyright 2026 Cloudflare, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

mod utils;

use utils::server_utils::init;
use utils::websocket::{WS_ECHO, WS_ECHO_RAW};

use bytes::Bytes;
use futures::{SinkExt, StreamExt};
use http::header::{HeaderName, HeaderValue};
use http_body_util::BodyExt;
use pingora_http::ResponseHeader;
use reqwest::{StatusCode, Version};
use std::sync::{
    atomic::{AtomicUsize, Ordering},
    Arc,
};
use std::time::{Duration, Instant};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::oneshot;
use tokio::time::timeout;
use tokio_tungstenite::tungstenite::{client::IntoClientRequest, Message};

#[tokio::test]
async fn test_ip_binding() {
    init();
    let res = reqwest::get("http://127.0.0.1:6147/client_ip")
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let headers = res.headers();
    assert_eq!(headers["x-client-ip"], "127.0.0.2");
}

#[tokio::test]
async fn test_duplex() {
    init();
    // NOTE: this doesn't really verify that we are in full duplex mode as reqwest
    // won't allow us control when req body is sent
    let client = reqwest::Client::new();
    let res = client
        .post("http://127.0.0.1:6147/duplex/")
        .body("b".repeat(1024 * 1024)) // 1 MB upload
        .timeout(Duration::from_secs(5))
        .send()
        .await
        .unwrap();
    let headers = res.headers();
    assert_eq!(headers["Connection"], "keep-alive");
    assert_eq!(res.status(), StatusCode::OK);
    let body = res.text().await.unwrap();
    assert_eq!(body.len(), 64 * 5);
}

#[tokio::test]
async fn test_connection_die() {
    init();
    let res = reqwest::get("http://127.0.0.1:6147/connection_die")
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = res.text().await;
    // reqwest doesn't allow us to inspect the partial body
    assert!(body.is_err());
}

// This test is ignored because it has a fundamental timing dependency.
//
// The nginx origin sends a 200 response and flushes it, then sleeps 1s
// and kills the connection (RST). The test expects the client to always
// receive the 200 before the connection dies.
//
// This fails under CI load because the 15MB request body takes longer
// than 1s to write. The proxy's select! loop is busy writing body chunks
// upstream and can't read the 200 response concurrently. When the 1s
// expires and nginx sends a TCP RST, the RST discards all buffered data
// (including the 200) per TCP semantics. The proxy then sees an upstream
// error and resets the client connection.
//
// The underlying issue is that TCP RST discards unread buffered data,
// so the 200 response is lost even though it was sent before the RST.
// Fixing this would require the proxy to read the response before or
// concurrently with the body write completing, which is a deeper
// architectural change.
#[ignore]
#[tokio::test]
async fn test_upload_connection_die() {
    init();
    let client = reqwest::Client::new();
    let res = client
        .post("http://127.0.0.1:6147/upload_connection_die/")
        .body("b".repeat(15 * 1024 * 1024)) // 15 MB upload
        .timeout(Duration::from_secs(5))
        .send()
        .await
        .unwrap();
    // should get 200 status before connection dies
    assert_eq!(res.status(), StatusCode::OK);
    let _ = res.text().await;

    // try h2
    let client = reqwest::Client::new();
    let res = client
        .post("http://127.0.0.1:6147/upload_connection_die/")
        .body("b".repeat(15 * 1024 * 1024)) // 15 MB upload
        .timeout(Duration::from_secs(5))
        .header("x-h2", "true")
        .send()
        .await
        .unwrap();
    // should get 200 status before connection dies
    assert_eq!(res.status(), StatusCode::OK);
    let _ = res.text().await;
}

#[tokio::test]
async fn test_upload() {
    init();
    let client = reqwest::Client::new();
    let res = client
        .post("http://127.0.0.1:6147/upload/")
        .body("b".repeat(15 * 1024 * 1024)) // 15 MB upload
        .timeout(Duration::from_secs(5))
        .send()
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = res.text().await.unwrap();
    assert_eq!(body.len(), 64 * 5);
}

#[tokio::test]
async fn test_close_on_response_before_downstream_finish() {
    init();
    let client = reqwest::Client::new();
    let res = client
        .post("http://127.0.0.1:6147/test2")
        .header("x-close-on-response-before-downstream-finish", "1")
        .body("b".repeat(15 * 1024 * 1024)) // 15 MB upload
        .timeout(Duration::from_secs(5))
        .send()
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let headers = res.headers();
    assert_eq!(headers["Connection"], "close");
    let body = res.text().await.unwrap();
    assert_eq!(body.len(), 11);
}

#[tokio::test]
async fn test_h1_upstream_not_reused_after_request_body_finish_error() {
    init();

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let origin_port = listener.local_addr().unwrap().port();
    let accepted = Arc::new(AtomicUsize::new(0));
    let server_accepted = Arc::clone(&accepted);

    tokio::spawn(async move {
        loop {
            let Ok((mut stream, _)) = listener.accept().await else {
                return;
            };
            let connection_number = server_accepted.fetch_add(1, Ordering::SeqCst);

            tokio::spawn(async move {
                let mut request = Vec::new();
                let mut buf = [0; 1024];
                while !request.windows(4).any(|window| window == b"\r\n\r\n") {
                    let n = stream.read(&mut buf).await.unwrap();
                    if n == 0 {
                        return;
                    }
                    request.extend_from_slice(&buf[..n]);
                }

                if connection_number == 0 {
                    // Respond before the declared request body is complete. The connection must
                    // not receive another request after the proxy fails to finish this body.
                    stream
                        .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nfirst")
                        .await
                        .unwrap();
                    tokio::time::sleep(Duration::from_secs(5)).await;
                } else {
                    stream
                        .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 6\r\n\r\nsecond")
                        .await
                        .unwrap();
                }
            });
        }
    });

    let client = reqwest::Client::new();
    let url = "http://127.0.0.1:6147/request-body-finish-error";

    let first = client
        .post(url)
        .header("x-port", origin_port.to_string())
        // The downstream body is valid; the test-only upstream filter deliberately makes its
        // outbound Content-Length larger in order to exercise defense in depth.
        .header("x-upstream-content-length", "32")
        .body("short")
        .send()
        .await
        .unwrap();
    assert_eq!(first.status(), StatusCode::OK);
    assert_eq!(first.text().await.unwrap(), "first");

    let second = timeout(
        Duration::from_secs(2),
        client
            .get(url)
            .header("x-port", origin_port.to_string())
            .send(),
    )
    .await
    .expect("second request should use a new upstream connection")
    .unwrap();
    assert_eq!(second.status(), StatusCode::OK);
    assert_eq!(second.text().await.unwrap(), "second");
    assert_eq!(accepted.load(Ordering::SeqCst), 2);
}

#[tokio::test]
async fn test_ws_server_ends_conn() {
    init();
    let _ = *WS_ECHO;

    // server gracefully closes connection

    let mut req = "ws://127.0.0.1:6147".into_client_request().unwrap();
    req.headers_mut()
        .insert("x-port", HeaderValue::from_static("9283"));

    let (mut ws_stream, _) = tokio_tungstenite::connect_async(req).await.unwrap();
    // gracefully close connection
    ws_stream.send("test".into()).await.unwrap();
    ws_stream.next().await.unwrap().unwrap();
    ws_stream.send("graceful".into()).await.unwrap();
    let msg = ws_stream.next().await.unwrap().unwrap();
    // assert graceful close
    assert!(matches!(msg, Message::Close(None)));
    // test may hang here if downstream doesn't close when upstream does
    assert!(ws_stream.next().await.is_none());

    // server abruptly closes connection

    let mut req = "ws://127.0.0.1:6147".into_client_request().unwrap();
    req.headers_mut()
        .insert("x-port", HeaderValue::from_static("9283"));

    let (mut ws_stream, _) = tokio_tungstenite::connect_async(req).await.unwrap();
    // abrupt close connection
    ws_stream.send("close".into()).await.unwrap();
    // test will hang here if downstream doesn't close when upstream does
    assert!(ws_stream.next().await.unwrap().is_err());

    // client gracefully closes connection

    let mut req = "ws://127.0.0.1:6147".into_client_request().unwrap();
    req.headers_mut()
        .insert("x-port", HeaderValue::from_static("9283"));

    let (mut ws_stream, _) = tokio_tungstenite::connect_async(req).await.unwrap();
    ws_stream.send("test".into()).await.unwrap();
    // sender initiates close
    ws_stream.close(None).await.unwrap();
    let msg = ws_stream.next().await.unwrap().unwrap();
    // assert echo
    assert_eq!(msg.into_text().unwrap(), "test");
    let msg = ws_stream.next().await.unwrap().unwrap();
    // assert graceful close
    assert!(matches!(msg, Message::Close(None)));
    assert!(ws_stream.next().await.is_none());
}

fn parse_response_header(buf: &[u8]) -> ResponseHeader {
    let mut headers = vec![httparse::EMPTY_HEADER; 256];
    let mut parsed = httparse::Response::new(&mut headers);
    match parsed.parse(buf).unwrap() {
        httparse::Status::Complete(_) => {
            let mut resp =
                ResponseHeader::build(parsed.code.unwrap(), Some(parsed.headers.len())).unwrap();
            for header in parsed.headers.iter() {
                resp.append_header(header.name.to_string(), header.value)
                    .unwrap();
            }
            resp
        }
        _ => panic!("expects a whole response header"),
    }
}

/// Read response header and return it along with any preread body data
async fn read_response_header(stream: &mut tokio::net::TcpStream) -> (ResponseHeader, Vec<u8>) {
    let mut response = vec![];
    let mut header_end = 0;
    let mut buf = [0; 1024];
    loop {
        let n = stream.read(&mut buf).await.unwrap();
        response.extend_from_slice(&buf[..n]);
        let mut end_of_response = false;
        for (i, w) in response.windows(4).enumerate() {
            if w == b"\r\n\r\n" {
                end_of_response = true;
                header_end = i + 4;
                break;
            }
        }
        if end_of_response {
            break;
        }
    }
    let response_header = parse_response_header(&response[..header_end]);
    let preread_body = response[header_end..].to_vec();
    (response_header, preread_body)
}

/// Read remaining body bytes from stream until expected_body_len is reached
async fn read_response_body(
    stream: &mut tokio::net::TcpStream,
    mut body: Vec<u8>,
    expected_body_len: usize,
) -> Vec<u8> {
    let mut buf = [0; 1024];
    while body.len() < expected_body_len {
        let n = stream.read(&mut buf).await.unwrap();
        body.extend_from_slice(&buf[..n]);
    }
    if body.len() > expected_body_len {
        panic!("more body bytes than expected");
    }
    body
}

async fn read_response(
    stream: &mut tokio::net::TcpStream,
    expected_body_len: usize,
) -> (ResponseHeader, Vec<u8>) {
    let (response_header, body) = read_response_header(stream).await;
    let body = read_response_body(stream, body, expected_body_len).await;
    (response_header, body)
}

async fn capture_upstream_request(
    request_end: &'static [u8],
    response: &'static [u8],
) -> (u16, oneshot::Receiver<Vec<u8>>) {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();

    tokio::spawn(async move {
        let (mut stream, _) = listener.accept().await.unwrap();
        let mut request = Vec::new();
        let mut buf = [0; 1024];
        while !request.windows(request_end.len()).any(|w| w == request_end) {
            let n = stream.read(&mut buf).await.unwrap();
            if n == 0 {
                break;
            }
            request.extend_from_slice(&buf[..n]);
        }
        // A panic here would be swallowed: this task is detached.
        let _ = tx.send(request);
        stream.write_all(response).await.unwrap();
        stream.flush().await.unwrap();
    });

    (port, rx)
}

// Send h2c with independently controlled `:authority` and `Host`.
// A direct h2 client is required because higher-level clients make them agree.
async fn send_h2c_authority_request(
    upstream_port: u16,
    authority: Option<&str>,
    host: Option<&str>,
) -> StatusCode {
    let tcp = TcpStream::connect("127.0.0.1:6146").await.unwrap();
    let (h2, connection) = h2::client::handshake(tcp).await.unwrap();
    tokio::spawn(async move {
        let _ = connection.await;
    });

    let target = match authority {
        Some(authority) => format!("http://{authority}/test"),
        None => "/test".to_string(),
    };
    let mut request = http::Request::builder()
        .method("GET")
        .uri(target)
        .header("x-port", upstream_port.to_string());
    if let Some(host) = host {
        request = request.header(http::header::HOST, host);
    }

    let mut h2 = h2.ready().await.unwrap();
    let (response, _) = h2.send_request(request.body(()).unwrap(), true).unwrap();
    // Rejections are sent with END_STREAM, so no reset races the response.
    timeout(Duration::from_secs(5), response)
        .await
        .expect("timed out waiting for the h2 response")
        .expect("h2 stream failed instead of returning a response")
        .status()
}

// Send H2 downstream with a filter-only `Host` override.
async fn send_h2c_host_override_request(
    upstream_port: u16,
    upstream_h2: bool,
    host_override: &str,
) -> StatusCode {
    let tcp = TcpStream::connect("127.0.0.1:6146").await.unwrap();
    let (h2, connection) = h2::client::handshake(tcp).await.unwrap();
    tokio::spawn(async move {
        let _ = connection.await;
    });

    let mut request = http::Request::builder()
        .method("GET")
        .uri("http://client.example/test")
        .header("x-port", upstream_port.to_string())
        .header("host-override", host_override);
    if upstream_h2 {
        request = request.header("x-h2", "true");
    }

    let mut h2 = h2.ready().await.unwrap();
    let (response, _) = h2.send_request(request.body(()).unwrap(), true).unwrap();
    timeout(Duration::from_secs(5), response)
        .await
        .expect("timed out waiting for the host-override response")
        .expect("h2 stream failed instead of returning a response")
        .status()
}

fn capture_h1_upstream() -> impl std::future::Future<Output = (u16, oneshot::Receiver<Vec<u8>>)> {
    capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
}

// Ambiguous H2 authority must not reach upstream.
#[tokio::test]
async fn test_h2_ambiguous_authority_never_reaches_h1_upstream() {
    init();

    // With only `:authority` to go on, the downgrade synthesizes a matching `Host`.
    let (port, received) = capture_h1_upstream().await;
    let status = send_h2c_authority_request(port, Some("authority.example"), None).await;
    assert_eq!(status, StatusCode::OK);
    let upstream = timeout(Duration::from_secs(5), received)
        .await
        .expect("upstream was never contacted for the control request")
        .unwrap();
    let upstream = String::from_utf8(upstream).unwrap().to_ascii_lowercase();
    assert!(
        upstream.contains("\r\nhost: authority.example\r\n"),
        "{upstream}"
    );

    for (case, authority, host) in [
        (
            "conflicting Host",
            Some("authority.example"),
            Some("other.example"),
        ),
        ("userinfo", Some("user@authority.example"), None),
        (
            "conflicting Host against an authority with a port",
            Some("authority.example:443"),
            Some("other.example"),
        ),
        // Host is the only authority here.
        (
            "userinfo in Host without :authority",
            None,
            Some("user@evil.example"),
        ),
    ] {
        let (port, mut received) = capture_h1_upstream().await;
        let status = send_h2c_authority_request(port, authority, host).await;

        // Checked first so a regression reports what reached the upstream, not just the
        // status. Borrowed so the receiver stays alive for the check below.
        match timeout(Duration::from_millis(500), &mut received).await {
            // No connection arrived, or the capture ended without one.
            Err(_) | Ok(Err(_)) => {}
            Ok(Ok(request)) => panic!(
                "{case} reached the upstream: {:?}",
                String::from_utf8_lossy(&request)
            ),
        }
        assert_eq!(status, StatusCode::BAD_REQUEST, "{case}");

        // The wait can finish before a slow connection lands.
        if let Ok(request) = received.try_recv() {
            panic!(
                "{case} reached the upstream after it was answered: {:?}",
                String::from_utf8_lossy(&request)
            );
        }
    }
}

#[tokio::test]
async fn test_h2_downstream_host_override_selects_upstream_authority() {
    init();

    let (port, received) = capture_h1_upstream().await;
    assert_eq!(
        send_h2c_host_override_request(port, false, "origin.example").await,
        StatusCode::OK
    );
    let request = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(request.contains("\r\nhost: origin.example\r\n"));

    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();
    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        tx.send((
            request.uri().authority().unwrap().to_string(),
            request.uri().path_and_query().unwrap().to_string(),
        ))
        .unwrap();
        let response = http::Response::builder().status(200).body(()).unwrap();
        respond.send_response(response, true).unwrap();
        let _ = timeout(Duration::from_millis(100), connection.accept()).await;
    });

    assert_eq!(
        send_h2c_host_override_request(port, true, "origin.example").await,
        StatusCode::OK
    );
    let (authority, path_and_query) = rx.await.unwrap();
    assert_eq!(authority, "origin.example");
    assert_eq!(path_and_query, "/test");
}

#[tokio::test]
async fn test_post_filter_userinfo_authority_never_reaches_upstream() {
    init();

    let (port, mut received) = capture_h1_upstream().await;
    let status = send_h2c_host_override_request(port, false, "user@evil.example").await;

    match timeout(Duration::from_millis(500), &mut received).await {
        Err(_) | Ok(Err(_)) => {}
        Ok(Ok(request)) if request.is_empty() => {}
        Ok(Ok(request)) => panic!(
            "post-filter userinfo reached the upstream: {:?}",
            String::from_utf8_lossy(&request)
        ),
    }
    assert_eq!(status, StatusCode::INTERNAL_SERVER_ERROR);
    if let Ok(request) = received.try_recv() {
        assert!(
            request.is_empty(),
            "post-filter userinfo reached the upstream after the response: {:?}",
            String::from_utf8_lossy(&request)
        );
    }
}

// Send raw H1 that normal clients cannot express; `{port}` selects upstream.
async fn send_h1_raw_request(upstream_port: u16, request: &str) -> String {
    let request = request.replace("{port}", &upstream_port.to_string());
    send_h1_raw_bytes(request.as_bytes()).await
}

async fn send_h1_raw_bytes(request: &[u8]) -> String {
    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();
    stream.write_all(request).await.unwrap();
    stream.flush().await.unwrap();

    // Read only the status line so a keepalive response does not block until timeout.
    let mut response = Vec::new();
    let mut buf = [0; 256];
    while !response.windows(2).any(|w| w == b"\r\n") {
        let read = timeout(Duration::from_secs(5), stream.read(&mut buf))
            .await
            .expect("timed out waiting for the h1 response")
            .unwrap();
        if read == 0 {
            break;
        }
        response.extend_from_slice(&buf[..read]);
    }
    String::from_utf8_lossy(&response)
        .lines()
        .next()
        .unwrap_or_default()
        .to_string()
}

#[cfg(feature = "patched_http1")]
#[tokio::test]
async fn test_hostless_non_utf8_h1_target_is_rejected_before_h2_serialization() {
    init();

    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();
    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let received = timeout(Duration::from_secs(1), connection.accept()).await;
        let _ = tx.send(matches!(received, Ok(Some(Ok(_)))));
    });

    let mut request = b"GET /\xff HTTP/1.0\r\nx-port: ".to_vec();
    request.extend_from_slice(port.to_string().as_bytes());
    request.extend_from_slice(b"\r\nx-h2: true\r\n\r\n");
    let status = send_h1_raw_bytes(&request).await;

    assert!(status.contains("400 Bad Request"), "{status}");
    assert!(!rx.await.unwrap(), "non-UTF-8 target reached H2 upstream");
}

#[tokio::test]
async fn test_h1_absolute_form_to_h2_upstream_sends_path_and_query() {
    init();

    // An H1 upstream receives the absolute-form target verbatim from raw_path(), but
    // `:path` carries only the path and query (RFC 9113 section 8.3.1), so the two
    // upstreams see different request targets for the same downstream request.
    //
    // The other two absolute-form H2 tests drive a host-override filter and a hostless
    // target; this is the plain shape, with a matching Host and a query.
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();
    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        let _ = tx.send(request.uri().clone());
        respond
            .send_response(http::Response::new(()), true)
            .unwrap();
        let _ = timeout(Duration::from_millis(100), connection.accept()).await;
    });

    let request = concat!(
        "GET http://client.example/test?q=1 HTTP/1.1\r\n",
        "Host: client.example\r\n",
        "x-port: {port}\r\n",
        "x-h2: true\r\n",
        "\r\n",
    );
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let uri = rx.await.unwrap();
    assert_eq!(uri.path_and_query().unwrap(), "/test?q=1");
}

#[tokio::test]
async fn test_h1_absolute_form_host_override_rewrites_target_authority() {
    init();

    let request = concat!(
        "GET http://client.example/test HTTP/1.1\r\n",
        "Host: client.example\r\n",
        "host-override: origin.example\r\n",
        "x-port: {port}\r\n",
        "\r\n",
    );
    let (port, received) = capture_h1_upstream().await;
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let received = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(received.starts_with("get http://origin.example/test http/1.1\r\n"));
    assert!(received.contains("\r\nhost: origin.example\r\n"));

    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();
    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        tx.send(request.uri().clone()).unwrap();
        let response = http::Response::builder().status(200).body(()).unwrap();
        respond.send_response(response, true).unwrap();
        let _ = timeout(Duration::from_millis(100), connection.accept()).await;
    });

    let request = concat!(
        "GET http://client.example/test HTTP/1.1\r\n",
        "Host: client.example\r\n",
        "host-override: origin.example\r\n",
        "x-port: {port}\r\n",
        "x-h2: true\r\n",
        "\r\n",
    );
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let uri = rx.await.unwrap();
    assert_eq!(uri.authority().unwrap(), "origin.example");
    assert_eq!(uri.path_and_query().unwrap(), "/test");
}

#[tokio::test]
async fn test_h1_absolute_form_host_is_restored_after_filter_deletion() {
    init();

    let request = concat!(
        "GET http://client.example/test HTTP/1.1\r\n",
        "Host: client.example\r\n",
        "x-upstream-delete-host: true\r\n",
        "x-port: {port}\r\n",
        "\r\n",
    );
    let (port, received) = capture_h1_upstream().await;
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let received = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(received.starts_with("get http://client.example/test http/1.1\r\n"));
    assert!(received.contains("\r\nhost: client.example\r\n"));
}

#[tokio::test]
async fn test_origin_form_host_deletion_is_handled_before_upstream() {
    init();

    let request = concat!(
        "GET /test HTTP/1.1\r\n",
        "Host: client.example\r\n",
        "x-upstream-delete-host: true\r\n",
        "x-port: {port}\r\n",
        "\r\n",
    );
    let (port, received) = capture_h1_upstream().await;
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let received = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(received.starts_with("get /test http/1.1\r\n"));
    assert!(received.contains("\r\nhost: \r\n"));

    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();
    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let received = timeout(Duration::from_secs(1), connection.accept()).await;
        let _ = tx.send(matches!(received, Ok(Some(Ok(_)))));
    });

    let request = concat!(
        "GET /test HTTP/1.1\r\n",
        "Host: client.example\r\n",
        "x-upstream-delete-host: true\r\n",
        "x-port: {port}\r\n",
        "x-h2: true\r\n",
        "\r\n",
    );
    let status = send_h1_raw_request(port, request).await;
    assert!(status.contains("500 Internal Server Error"), "{status}");
    assert!(!rx.await.unwrap(), "Host-less request reached H2 upstream");
}

#[tokio::test]
async fn test_hostless_h1_absolute_form_uses_target_authority() {
    init();

    let request = concat!(
        "GET http://client.example/test HTTP/1.0\r\n",
        "x-port: {port}\r\n",
        "\r\n",
    );
    let (port, received) = capture_h1_upstream().await;
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let received = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(received.starts_with("get http://client.example/test http/1.1\r\n"));
    assert!(received.contains("\r\nhost: client.example\r\n"));

    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();
    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        let _ = tx.send(request.uri().clone());
        respond
            .send_response(http::Response::new(()), true)
            .unwrap();
        let _ = timeout(Duration::from_millis(100), connection.accept()).await;
    });

    let request = concat!(
        "GET http://client.example/test HTTP/1.0\r\n",
        "x-port: {port}\r\n",
        "x-h2: true\r\n",
        "\r\n",
    );
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));
    let uri = rx.await.unwrap();
    assert_eq!(uri.authority().unwrap(), "client.example");
    assert_eq!(uri.path_and_query().unwrap(), "/test");
}

#[tokio::test]
async fn test_hostless_http10_request_remains_hostless_upstream() {
    init();

    let (port, received) = capture_h1_upstream().await;
    let request = "GET /test HTTP/1.0\r\nx-port: {port}\r\n\r\n";
    assert!(send_h1_raw_request(port, request).await.contains("200 OK"));

    let received = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(received.starts_with("get /test http/1.1\r\n"));
    assert!(!received.contains("\r\nhost:"));
}

// Ambiguous H1 authority must not reach upstream.
#[tokio::test]
async fn test_h1_ambiguous_authority_never_reaches_upstream() {
    init();

    // A single valid Host is proxied, and "@" outside an authority is ordinary data.
    for (case, request) in [
        (
            "single Host",
            "GET /test HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\n\r\n",
        ),
        (
            "\"@\" in the path",
            "GET /users/foo@bar.example HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\n\r\n",
        ),
        // Only a scheme at the start of the target makes it absolute form.
        (
            "an absolute URL inside the query",
            "GET /redirect?next=http://user@evil.example/ HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\n\r\n",
        ),
        (
            "\"@\" in a fragment-like target",
            "GET /test#user@evil.example HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\n\r\n",
        ),
    ] {
        let (port, received) = capture_h1_upstream().await;
        let status = send_h1_raw_request(port, request).await;
        assert!(status.contains("200 OK"), "{case}: {status}");
        timeout(Duration::from_secs(5), received)
            .await
            .unwrap_or_else(|_| panic!("{case}: upstream was never contacted"))
            .unwrap();
    }

    for (case, request) in [
        (
            "duplicate Host",
            "GET /test HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\nHost: other.example\r\n\r\n",
        ),
        (
            "identical duplicate Host",
            "GET /test HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\nHost: authority.example\r\n\r\n",
        ),
        (
            "userinfo in Host",
            "GET /test HTTP/1.1\r\nx-port: {port}\r\nHost: user@authority.example\r\n\r\n",
        ),
        (
            "userinfo in an absolute-form target",
            "GET http://user@authority.example/test HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\n\r\n",
        ),
        (
            "encoded backslash in absolute-form authority",
            "GET http://good.example%5Cevil.example/test HTTP/1.1\r\nx-port: {port}\r\nHost: good.example%5Cevil.example\r\n\r\n",
        ),
        (
            "encoded userinfo in absolute-form authority",
            "GET http://user%40authority.example/test HTTP/1.1\r\nx-port: {port}\r\nHost: user%40authority.example\r\n\r\n",
        ),
        (
            "encoded slash in absolute-form authority",
            "GET http://a%2f.example/test HTTP/1.1\r\nx-port: {port}\r\nHost: a%2f.example\r\n\r\n",
        ),
        (
            "multiple ports in absolute-form authority",
            "GET http://authority.example:443:8080/test HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example:443:8080\r\n\r\n",
        ),
        (
            "invalid absolute-form scheme",
            "GET ht_tp://authority.example/test HTTP/1.1\r\nx-port: {port}\r\nHost: authority.example\r\n\r\n",
        ),
        (
            "empty absolute-form authority",
            "GET http:///test HTTP/1.1\r\nx-port: {port}\r\nHost: \r\n\r\n",
        ),
    ] {
        let (port, mut received) = capture_h1_upstream().await;
        let status = send_h1_raw_request(port, request).await;

        // Checked first so a regression reports what reached the upstream. Borrowed so the
        // receiver stays alive for the check below.
        match timeout(Duration::from_millis(500), &mut received).await {
            Err(_) | Ok(Err(_)) => {}
            Ok(Ok(request)) => panic!(
                "{case} reached the upstream: {:?}",
                String::from_utf8_lossy(&request)
            ),
        }
        assert!(status.contains("400 Bad Request"), "{case}: {status}");

        // The wait can finish before a slow connection lands.
        if let Ok(request) = received.try_recv() {
            panic!(
                "{case} reached the upstream after it was answered: {:?}",
                String::from_utf8_lossy(&request)
            );
        }
    }
}

async fn send_raw_request_to_test_proxy(request: String) -> ResponseHeader {
    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();
    stream.write_all(request.as_bytes()).await.unwrap();
    stream.flush().await.unwrap();
    timeout(Duration::from_secs(5), read_response_header(&mut stream))
        .await
        .unwrap()
        .0
}

#[tokio::test]
async fn test_h1_upstream_strips_hop_by_hop_and_connection_nominated_headers() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: keep-alive, X-Private-Hop\r\n",
            "Keep-Alive: timeout=5\r\n",
            "Proxy-Connection: keep-alive\r\n",
            "Proxy-Authenticate: Basic realm=test\r\n",
            "Proxy-Authorization: Basic dGVzdA==\r\n",
            "TE: trailers\r\n",
            "Trailer: X-Trailer\r\n",
            "X-Private-Hop: secret\r\n",
            "X-Regular: keep\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\nconnection:"));
    assert!(!upstream.contains("\r\nkeep-alive:"));
    assert!(!upstream.contains("\r\nproxy-connection:"));
    assert!(!upstream.contains("\r\nproxy-authenticate:"));
    assert!(!upstream.contains("\r\nproxy-authorization:"));
    assert!(!upstream.contains("\r\nte:"));
    assert!(!upstream.contains("\r\ntrailer:"));
    assert!(!upstream.contains("\r\nx-private-hop:"));
    assert!(upstream.contains("\r\nx-regular: keep\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_rejects_sensitive_fields_nominated_by_connection() {
    init();
    for nominated in [
        "Host",
        "X-Forwarded-For",
        "X-Forwarded-Host",
        "X-Forwarded-Proto",
        ":authority",
    ] {
        let (port, received) =
            capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
                .await;

        let req = format!(
            concat!(
                "GET / HTTP/1.1\r\n",
                "Host: intended.example\r\n",
                "X-Port: {port}\r\n",
                "X-Forwarded-For: 198.51.100.1\r\n",
                "X-Forwarded-Host: intended.example\r\n",
                "X-Forwarded-Proto: https\r\n",
                "Connection: {nominated}\r\n",
                "\r\n",
            ),
            port = port,
            nominated = nominated,
        );

        assert_eq!(
            send_raw_request_to_test_proxy(req).await.status,
            400,
            "nominated {nominated}"
        );
        let upstream = timeout(Duration::from_secs(1), received)
            .await
            .unwrap()
            .unwrap();
        assert!(
            upstream.is_empty(),
            "a request nominating {nominated} must not be sent upstream"
        );
    }
}

#[tokio::test]
async fn test_h1_upstream_rejects_excessive_connection_nominations() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: X-1, X-2, X-3, X-4, X-5, X-6, X-7, X-8, X-9, X-10\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 400);
    assert!(received.await.unwrap().is_empty());
}

#[tokio::test]
async fn test_h1_upstream_preserves_chunked_framing_after_sanitizing_headers() {
    init();
    let (port, received) = capture_upstream_request(
        b"0\r\n\r\n",
        b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: Transfer-Encoding, X-Private-Hop\r\n",
            "Transfer-Encoding: chunked\r\n",
            "X-Private-Hop: secret\r\n",
            "\r\n",
            "5\r\nhello\r\n0\r\n\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap()).unwrap();
    let upstream_lower = upstream.to_ascii_lowercase();
    assert!(!upstream_lower.contains("\r\nconnection:"));
    assert!(!upstream_lower.contains("\r\nx-private-hop:"));
    assert!(upstream_lower.contains("\r\ntransfer-encoding: chunked\r\n"));
    assert!(upstream.ends_with("\r\n\r\n5\r\nhello\r\n0\r\n\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_synthesizes_chunked_when_content_length_is_nominated() {
    init();
    let (port, received) = capture_upstream_request(
        b"0\r\n\r\n",
        b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: Content-Length\r\n",
            "Content-Length: 5\r\n",
            "\r\n",
            "hello",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap()).unwrap();
    let upstream_lower = upstream.to_ascii_lowercase();
    assert!(!upstream_lower.contains("\r\nconnection:"));
    assert!(!upstream_lower.contains("\r\ncontent-length:"));
    assert!(upstream_lower.contains("\r\ntransfer-encoding: chunked\r\n"));
    assert!(upstream.ends_with("\r\n\r\n5\r\nhello\r\n0\r\n\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_forwards_only_normalized_websocket_upgrade_metadata() {
    init();
    let (port, received) = capture_upstream_request(
        b"\r\n\r\n",
        b"HTTP/1.1 101 Switching Protocols\r\nConnection: upgrade\r\nUpgrade: websocket\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: keep-alive, Upgrade, X-Private-Hop\r\n",
            "Upgrade: websocket\r\n",
            "X-Private-Hop: secret\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 101);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(upstream.contains("\r\nconnection: upgrade\r\n"));
    assert!(upstream.contains("\r\nupgrade: websocket\r\n"));
    assert!(!upstream.contains("\r\nx-private-hop:"));
    assert!(!upstream.contains("keep-alive"));
}

#[tokio::test]
async fn test_h1_upstream_normalizes_websocket_upgrade_without_connection_token() {
    init();
    let (port, received) = capture_upstream_request(
        b"\r\n\r\n",
        b"HTTP/1.1 101 Switching Protocols\r\nConnection: upgrade\r\nUpgrade: websocket\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Upgrade: websocket\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 101);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(upstream.contains("\r\nconnection: upgrade\r\n"));
    assert!(upstream.contains("\r\nupgrade: websocket\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_normalizes_mixed_case_websocket_upgrade() {
    init();
    let (port, received) = capture_upstream_request(
        b"\r\n\r\n",
        b"HTTP/1.1 101 Switching Protocols\r\nConnection: upgrade\r\nUpgrade: websocket\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Upgrade: WebSocket\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 101);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(upstream.contains("\r\nconnection: upgrade\r\n"));
    assert!(upstream.contains("\r\nupgrade: websocket\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_does_not_upgrade_http10_websocket_request() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.0\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Upgrade: websocket\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\nconnection: upgrade\r\n"));
    assert!(!upstream.contains("\r\nupgrade: websocket\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_denies_h2c_upgrade_metadata_by_default() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: Upgrade, HTTP2-Settings\r\n",
            "Upgrade: h2c\r\n",
            "HTTP2-Settings: AAQAAP__\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\nconnection:"));
    assert!(!upstream.contains("\r\nupgrade:"));
    assert!(!upstream.contains("\r\nhttp2-settings:"));
}

#[tokio::test]
async fn test_h1_upstream_denied_upgrade_does_not_tunnel_unsolicited_101_body() {
    init();
    let (port, received) = capture_upstream_request(
        b"\r\n\r\n",
        b"HTTP/1.1 101 Switching Protocols\r\nConnection: upgrade\r\nUpgrade: h2c\r\n\r\ntunneled",
    )
    .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: Upgrade, HTTP2-Settings\r\n",
            "Upgrade: h2c\r\n",
            "HTTP2-Settings: AAQAAP__\r\n",
            "\r\n",
        ),
        port = port,
    );

    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();
    stream.write_all(req.as_bytes()).await.unwrap();
    stream.flush().await.unwrap();
    let (response, mut downstream_body) =
        timeout(Duration::from_secs(5), read_response_header(&mut stream))
            .await
            .unwrap();
    assert_eq!(response.status, 502);

    if downstream_body.is_empty() {
        let mut buf = [0; 32];
        if let Ok(Ok(n)) = timeout(Duration::from_millis(200), stream.read(&mut buf)).await {
            downstream_body.extend_from_slice(&buf[..n]);
        }
    }
    assert!(
        downstream_body.is_empty(),
        "a denied upgrade must not switch to tunneled body forwarding"
    );

    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\nupgrade:"));
}

#[tokio::test]
async fn test_h1_upstream_accepts_101_when_neither_side_requested_upgrade() {
    init();
    let (port, _received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 101 Switching Protocols\r\n\r\n").await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 101);
}

#[tokio::test]
async fn test_h1_upstream_rejects_101_when_filter_adds_upgrade_without_downstream_upgrade() {
    init();
    let (port, _received) = capture_upstream_request(
        b"\r\n\r\n",
        b"HTTP/1.1 101 Switching Protocols\r\nConnection: upgrade\r\nUpgrade: websocket\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-Upstream-Add-Upgrade: true\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 502);
}

#[tokio::test]
async fn test_h1_upstream_normalizes_transfer_coding_to_chunked_when_sanitizing() {
    init();
    let (port, received) = capture_upstream_request(
        b"0\r\n\r\n",
        b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: Transfer-Encoding\r\n",
            "Transfer-Encoding: gzip, chunked\r\n",
            "\r\n",
            "5\r\ncoded\r\n0\r\n\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap()).unwrap();
    let upstream_lower = upstream.to_ascii_lowercase();
    assert!(!upstream_lower.contains("\r\nconnection:"));
    assert!(upstream_lower.contains("\r\ntransfer-encoding: chunked\r\n"));
    assert!(!upstream_lower.contains("\r\ntransfer-encoding: gzip, chunked\r\n"));
    assert!(upstream.ends_with("\r\n\r\n5\r\ncoded\r\n0\r\n\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_synthesizes_chunked_after_filter_removes_framing() {
    init();
    let (port, received) = capture_upstream_request(
        b"0\r\n\r\n",
        b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-Upstream-Strip-Framing: true\r\n",
            "Content-Length: 5\r\n",
            "\r\n",
            "hello",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap()).unwrap();
    let upstream_lower = upstream.to_ascii_lowercase();
    assert!(!upstream_lower.contains("\r\ncontent-length:"));
    assert!(upstream_lower.contains("\r\ntransfer-encoding: chunked\r\n"));
    assert!(upstream.ends_with("\r\n\r\n5\r\nhello\r\n0\r\n\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_does_not_synthesize_framing_for_empty_body() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "Connection: Content-Length\r\n",
            "Content-Length: 0\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\ncontent-length:"));
    assert!(!upstream.contains("\r\ntransfer-encoding:"));
}

#[tokio::test]
async fn test_h1_upstream_does_not_synthesize_framing_without_downstream_body_headers() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\ncontent-length:"));
    assert!(!upstream.contains("\r\ntransfer-encoding:"));
}

#[tokio::test]
async fn test_h1_upstream_finishes_chunked_body_when_filter_discards_body() {
    init();
    let (port, received) = capture_upstream_request(
        b"0\r\n\r\n",
        b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n",
    )
    .await;

    let req = format!(
        concat!(
            "POST / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-Upstream-Strip-Framing: true\r\n",
            "X-Upstream-Discard-Body: true\r\n",
            "Content-Length: 5\r\n",
            "\r\n",
            "hello",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap()).unwrap();
    let upstream_lower = upstream.to_ascii_lowercase();
    assert!(!upstream_lower.contains("\r\ncontent-length:"));
    assert!(upstream_lower.contains("\r\ntransfer-encoding: chunked\r\n"));
    assert!(
        upstream.ends_with("\r\n\r\n0\r\n\r\n"),
        "upstream request: {upstream:?}"
    );
}

#[tokio::test]
async fn test_h1_upstream_can_retain_connection_nominated_fields_separately() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-Preserve-Connection-Nominated: true\r\n",
            "Connection: X-Private-Hop\r\n",
            "X-Private-Hop: retained\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(!upstream.contains("\r\nconnection:"));
    assert!(upstream.contains("\r\nx-private-hop: retained\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_does_not_validate_nominations_when_removal_disabled() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: intended.example\r\n",
            "X-Port: {port}\r\n",
            "X-Preserve-Connection-Nominated: true\r\n",
            "Connection: Host\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(upstream.contains("\r\nhost: intended.example\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_always_sends_http11_request_version() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.0\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    assert!(String::from_utf8(received.await.unwrap())
        .unwrap()
        .starts_with("GET / HTTP/1.1\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_legacy_preset_preserves_upgrade_and_nominated_fields() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-Preserve-Upstream-Request-Headers: true\r\n",
            "Connection: Upgrade, HTTP2-Settings, X-Private-Hop\r\n",
            "Upgrade: h2c\r\n",
            "HTTP2-Settings: AAQAAP__\r\n",
            "X-Private-Hop: retained\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(upstream.contains("\r\nconnection: upgrade, http2-settings, x-private-hop\r\n"));
    assert!(upstream.contains("\r\nupgrade: h2c\r\n"));
    assert!(upstream.contains("\r\nhttp2-settings: aaqaap__\r\n"));
    assert!(upstream.contains("\r\nx-private-hop: retained\r\n"));
}

#[tokio::test]
async fn test_h1_upstream_preserve_upgrade_retains_complete_handshake_metadata() {
    init();
    let (port, received) =
        capture_upstream_request(b"\r\n\r\n", b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
            .await;

    let req = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-Preserve-Upstream-Upgrade: true\r\n",
            "Connection: Upgrade, HTTP2-Settings, X-Upgrade-Param\r\n",
            "Upgrade: h2c\r\n",
            "HTTP2-Settings: AAQAAP__\r\n",
            "X-Upgrade-Param: retained\r\n",
            "\r\n",
        ),
        port = port,
    );

    assert_eq!(send_raw_request_to_test_proxy(req).await.status, 200);
    let upstream = String::from_utf8(received.await.unwrap())
        .unwrap()
        .to_ascii_lowercase();
    assert!(upstream.contains("\r\nconnection: upgrade, http2-settings, x-upgrade-param\r\n"));
    assert!(upstream.contains("\r\nupgrade: h2c\r\n"));
    assert!(upstream.contains("\r\nhttp2-settings: aaqaap__\r\n"));
    assert!(upstream.contains("\r\nx-upgrade-param: retained\r\n"));
}

#[tokio::test]
async fn test_h2_upstream_strips_connection_nominated_fields() {
    init();
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let (tx, rx) = oneshot::channel();

    tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut connection = h2::server::handshake(tcp).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        tx.send(request.headers().clone()).unwrap();
        let response = http::Response::builder().status(200).body(()).unwrap();
        respond.send_response(response, true).unwrap();
        let _ = timeout(Duration::from_millis(100), connection.accept()).await;
    });

    let request = format!(
        concat!(
            "GET / HTTP/1.1\r\n",
            "Host: example.test\r\n",
            "X-Port: {port}\r\n",
            "X-H2: true\r\n",
            "Connection: X-Private-Hop\r\n",
            "X-Private-Hop: secret\r\n",
            "\r\n",
        ),
        port = port,
    );
    assert_eq!(send_raw_request_to_test_proxy(request).await.status, 200);

    let headers = rx.await.unwrap();
    assert!(headers.get("connection").is_none());
    assert!(headers.get("x-private-hop").is_none());
}

#[tokio::test]
async fn test_h2_upstream_rejects_sensitive_fields_nominated_by_connection() {
    init();
    for nominated in ["Host", "X-Forwarded-For", ":authority"] {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let (tx, rx) = oneshot::channel();

        tokio::spawn(async move {
            let (tcp, _) = listener.accept().await.unwrap();
            let mut connection = h2::server::handshake(tcp).await.unwrap();
            let received_request =
                match timeout(Duration::from_millis(200), connection.accept()).await {
                    Ok(Some(Ok((_request, mut respond)))) => {
                        let response = http::Response::builder().status(200).body(()).unwrap();
                        respond.send_response(response, true).unwrap();
                        true
                    }
                    _ => false,
                };
            tx.send(received_request).unwrap();
        });

        let request = format!(
            concat!(
                "GET / HTTP/1.1\r\n",
                "Host: intended.example\r\n",
                "X-Port: {port}\r\n",
                "X-H2: true\r\n",
                "X-Forwarded-For: 198.51.100.1\r\n",
                "Connection: {nominated}\r\n",
                "\r\n",
            ),
            port = port,
            nominated = nominated,
        );
        assert_eq!(
            send_raw_request_to_test_proxy(request).await.status,
            400,
            "nominated {nominated}"
        );
        assert!(
            !rx.await.unwrap(),
            "request nominating {nominated} must not be sent upstream"
        );
    }
}

#[tokio::test]
async fn test_upgrade_smoke() {
    init();

    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();

    let req = concat!(
        "GET /upgrade HTTP/1.1\r\n",
        "Host: 127.0.0.1\r\n",
        "Upgrade: websocket\r\n",
        "Connection: Upgrade\r\n",
        "\r\n"
    );
    stream.write_all(req.as_bytes()).await.unwrap();
    stream.flush().await.unwrap();

    let expected_payload = b"hello\n";
    let fut = read_response(&mut stream, expected_payload.len());
    let (resp_header, resp_body) = timeout(Duration::from_secs(5), fut).await.unwrap();

    assert_eq!(resp_header.status, 101);
    assert_eq!(resp_header.headers["Upgrade"], "websocket");
    assert_eq!(resp_header.headers["Connection"], "upgrade");
    assert_eq!(resp_body, expected_payload);
}

#[tokio::test]
async fn test_upgrade_body() {
    init();

    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();

    let req = concat!(
        "POST /upgrade_echo_body HTTP/1.1\r\n",
        "Host: 127.0.0.1\r\n",
        "Upgrade: websocket\r\n",
        "Connection: Upgrade\r\n",
        "Content-Length: 1024\r\n",
        "\r\n"
    );
    stream.write_all(req.as_bytes()).await.unwrap();
    stream.flush().await.unwrap();
    stream.write_all("b".repeat(1024).as_bytes()).await.unwrap();
    stream.flush().await.unwrap();

    let fut = read_response(&mut stream, 1024);
    let (resp_header, resp_body) = timeout(Duration::from_secs(5), fut).await.unwrap();
    assert_eq!(resp_header.status, 101);
    assert_eq!(resp_header.headers["Upgrade"], "websocket");
    assert_eq!(resp_header.headers["Connection"], "upgrade");

    let body = "b".repeat(1024);
    assert_eq!(resp_body, body.as_bytes());
}

#[tokio::test]
async fn test_upgrade_body_after_101() {
    // test content-length body is passed through after 101,
    // and that ws payload is passed through afterwards
    // use websocket server that flushes 101 after reading header
    init();
    let _ = *WS_ECHO_RAW;

    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();

    let req = concat!(
        "POST /upgrade_echo_body HTTP/1.1\r\n",
        "Host: 127.0.0.1\r\n",
        "Upgrade: websocket\r\n",
        "Connection: Upgrade\r\n",
        "X-Port: 9284\r\n",
        "Content-Length: 5120\r\n",
        "X-Expected-Body-Len: 5125\r\n", // include ws payload
        "\r\n"
    );
    stream.write_all(req.as_bytes()).await.unwrap();
    stream.flush().await.unwrap();
    stream
        .write_all("b".repeat(5 * 1024).as_bytes())
        .await
        .unwrap();
    stream.flush().await.unwrap();

    // Read response header and any preread body first (before sending ws_payload)
    let fut = read_response_header(&mut stream);
    let (resp_header, resp_body) = timeout(Duration::from_secs(5), fut).await.unwrap();
    assert_eq!(resp_header.status, 101);
    assert_eq!(resp_header.headers["Upgrade"], "websocket");
    assert_eq!(resp_header.headers["Connection"], "upgrade");

    // Now send the websocket payload after receiving 101
    let ws_payload = "hello";
    stream.write_all(ws_payload.as_bytes()).await.unwrap();
    stream.flush().await.unwrap();

    // Read the rest of the bytes (body + ws payload), subtracting preread body length
    let expected_total_len = 5 * 1024 + ws_payload.len();
    let fut = read_response_body(&mut stream, resp_body, expected_total_len);
    let resp_body = timeout(Duration::from_secs(5), fut).await.unwrap();

    let body = "b".repeat(5 * 1024) + ws_payload;
    assert_eq!(resp_body, body.as_bytes());
}

#[tokio::test]
async fn test_download_timeout() {
    init();
    use tokio::time::sleep;

    let client = hyper_util::client::legacy::Client::builder(hyper_util::rt::TokioExecutor::new())
        .build_http::<http_body_util::Empty<Bytes>>();
    let uri: http::Uri = "http://127.0.0.1:6147/download_large/".parse().unwrap();
    let req = http::Request::builder()
        .uri(uri)
        .header("x-write-timeout", "1")
        .body(http_body_util::Empty::<Bytes>::new())
        .unwrap();
    let mut res = client.request(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);

    let mut err = false;
    sleep(Duration::from_secs(2)).await;
    while let Some(chunk) = res.body_mut().frame().await {
        if chunk.is_err() {
            err = true;
        }
    }
    assert!(err);
}

#[tokio::test]
async fn test_download_timeout_min_rate() {
    init();
    use tokio::time::sleep;

    let client = hyper_util::client::legacy::Client::builder(hyper_util::rt::TokioExecutor::new())
        .build_http::<http_body_util::Empty<Bytes>>();
    let uri: http::Uri = "http://127.0.0.1:6147/download/".parse().unwrap();
    let req = http::Request::builder()
        .uri(uri)
        .header("x-write-timeout", "1")
        .header("x-min-rate", "10000")
        .body(http_body_util::Empty::<Bytes>::new())
        .unwrap();
    let mut res = client.request(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK);

    let mut err = false;
    sleep(Duration::from_secs(2)).await;
    while let Some(chunk) = res.body_mut().frame().await {
        if chunk.is_err() {
            err = true;
        }
    }
    assert!(!err);
}

// When an H2 origin sends all Content-Length bytes in a DATA frame but times out
// before sending END_STREAM, a subsequent downstream h1 request may be blocked
#[tokio::test]
async fn test_h2_upstream_no_end_stream_read_timeout() {
    init();

    // Spawn a custom H2 origin:
    //   Request 1: sends Content-Length body WITHOUT END_STREAM, then goes quiet
    //   Request 2+: responds instantly with body + END_STREAM
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let origin_port = listener.local_addr().unwrap().port();

    tokio::spawn(async move {
        loop {
            let Ok((tcp, _addr)) = listener.accept().await else {
                break;
            };
            tokio::spawn(async move {
                let mut conn = match h2::server::handshake(tcp).await {
                    Ok(c) => c,
                    Err(e) => {
                        eprintln!("h2 handshake error: {e}");
                        return;
                    }
                };

                let request_count = std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0));
                while let Some(result) = conn.accept().await {
                    let (request, mut respond) = match result {
                        Ok(r) => r,
                        Err(e) => {
                            eprintln!("h2 accept error: {e}");
                            return;
                        }
                    };
                    let _ = request;
                    let count = request_count.fetch_add(1, std::sync::atomic::Ordering::SeqCst) + 1;

                    // Spawn handler so conn.accept() keeps driving the h2 connection
                    tokio::spawn(async move {
                        let resp = http::Response::builder()
                            .status(200)
                            .header(http::header::CONTENT_LENGTH, "11")
                            .body(())
                            .unwrap();

                        if count == 1 {
                            // Request 1: send body WITHOUT end_of_stream, then go quiet.
                            let mut send_stream = respond.send_response(resp, false).unwrap();
                            send_stream
                                .send_data(bytes::Bytes::from("hello world"), false)
                                .unwrap();
                            // Hold the stream open — simulates an origin that sent all CL
                            // bytes but hasn't closed the stream.
                            tokio::time::sleep(Duration::from_secs(30)).await;
                        } else {
                            // Request 2+: respond instantly with body + END_STREAM
                            let mut send_stream = respond.send_response(resp, false).unwrap();
                            send_stream
                                .send_data(bytes::Bytes::from("hello world"), true)
                                .unwrap();
                        }
                    });
                }
            });
        }
    });

    // The listener was bound before the spawn (line 426), so the kernel
    // is already accepting connections into the backlog. No readiness
    // wait needed.
    let client = reqwest::Client::new();
    let url = "http://127.0.0.1:6147/test";

    let resp1 = client
        .get(url)
        .header("x-port", origin_port.to_string())
        .header("x-h2", "true")
        .header("x-read-timeout-ms", "4000")
        .send()
        .await
        .unwrap();
    assert_eq!(resp1.status(), StatusCode::OK);
    assert_eq!(resp1.text().await.unwrap(), "hello world");

    // Request 2: reqwest reuses the H1 connection
    // but if blocked / stalled, the proxy can't read this request
    // until read_timeout fires (~4s)
    let start = Instant::now();
    let resp2 = timeout(
        Duration::from_secs(10),
        client
            .get(url)
            .header("x-port", origin_port.to_string())
            .header("x-h2", "true")
            .send(),
    )
    .await;
    let elapsed = start.elapsed();

    match resp2 {
        Ok(Ok(resp)) => {
            assert_eq!(resp.status(), StatusCode::OK);
            assert_eq!(resp.text().await.unwrap(), "hello world");
            assert!(
                elapsed < Duration::from_secs(2),
                "Second request on reused H1 connection took {elapsed:?}, \
                 expected < 2s (may be blocked on H2 upstream to end stream)"
            );
        }
        Ok(Err(e)) => {
            panic!("Second request failed: {e}");
        }
        Err(_) => {
            panic!("Second request timed out after 10s.");
        }
    }
}

/// Mock origin that sends 100 Continue then a final response for any request.
/// Returns the port the server is listening on.
async fn mock_100_continue_server() -> u16 {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();

    tokio::spawn(async move {
        if let Ok((mut stream, _addr)) = listener.accept().await {
            // Read the request (just drain it)
            let mut buf = [0u8; 4096];
            let _ = stream.read(&mut buf).await.unwrap();

            // Send 100 Continue
            stream
                .write_all(b"HTTP/1.1 100 Continue\r\n\r\n")
                .await
                .unwrap();
            // Small delay so the client reads the 100 separately
            tokio::time::sleep(Duration::from_millis(100)).await;

            // Send final 200 OK with Content-Length (but no body for HEAD)
            stream
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 42\r\n\r\n")
                .await
                .unwrap();
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
    });

    port
}

#[tokio::test]
async fn test_head_with_100_continue() {
    init();

    let port = mock_100_continue_server().await;

    let mut stream = TcpStream::connect("127.0.0.1:6147").await.unwrap();
    stream
        .write_all(
            format!("HEAD / HTTP/1.1\r\nHost: localhost\r\nx-port: {port}\r\n\r\n").as_bytes(),
        )
        .await
        .unwrap();

    // Read through any 1xx until we get the final (non-1xx) response
    let result = timeout(Duration::from_secs(5), async {
        let mut resp;
        let mut body;
        loop {
            (resp, body) = read_response_header(&mut stream).await;
            if resp.status.as_u16() >= 200 {
                return (resp, body);
            }
        }
    })
    .await
    .expect("should not time out waiting for final response");

    let (resp, body) = result;
    assert_eq!(resp.status.as_u16(), 200);
    // HEAD responses have no body even with Content-Length
    assert!(body.is_empty(), "HEAD response should have no body");
}

mod test_cache {
    use super::*;
    use std::str::FromStr;
    use tokio::time::sleep;

    #[tokio::test]
    async fn test_basic_caching() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_basic_caching/now";

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_expired_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "expired");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert!(cache_expired_epoch > cache_hit_epoch);
    }

    #[tokio::test]
    async fn test_deferred_cache_admission_fetches_from_upstream() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_deferred_cache_admission/now";
        let client = reqwest::Client::new();

        for _ in 0..2 {
            let res = client
                .get(url)
                .header("x-defer-cache-admission", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            assert_eq!(res.headers()["x-cache-status"], "deferred");
            assert_eq!(res.text().await.unwrap(), "hello world");
        }

        let res = client.get(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        let cache_miss_epoch = res.headers()["x-epoch"].to_str().unwrap().to_owned();
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = client.get(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.headers()["x-epoch"], cache_miss_epoch);
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_miss_finish_error_does_not_break_response() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_cache_miss_finish_error/now";

        let client = reqwest::Client::new();
        let res = client
            .get(url)
            .header("x-cache-fail-finish", "true")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = client.get(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_purge() {
        init();
        let res = reqwest::get("http://127.0.0.1:6148/unique/test_purge/test2")
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::get("http://127.0.0.1:6148/unique/test_purge/test2")
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::Client::builder()
            .build()
            .unwrap()
            .request(
                reqwest::Method::from_bytes(b"PURGE").unwrap(),
                "http://127.0.0.1:6148/unique/test_purge/test2",
            )
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.text().await.unwrap(), "");

        let res = reqwest::Client::builder()
            .build()
            .unwrap()
            .request(
                reqwest::Method::from_bytes(b"PURGE").unwrap(),
                "http://127.0.0.1:6148/unique/test_purge/test2",
            )
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_FOUND);
        assert_eq!(res.text().await.unwrap(), "");

        let res = reqwest::get("http://127.0.0.1:6148/unique/test_purge/test2")
            .await
            .unwrap();
        let headers = res.headers();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_purge_expire_revalidates_instead_of_refetching() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_purge_expire/revalidate_now";
        let client = reqwest::Client::new();
        // The default test TTL is 1s, which this test would outlive: the asset would go stale on
        // its own and the final assertions would pass whether or not the purge did anything.
        let get = || {
            client
                .get(url)
                .header("x-set-cache-control", "public, max-age=60")
                .send()
        };

        let res = get().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        let stored_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(res.text().await.unwrap(), "hello world");

        // still fresh, so anything stale later is the purge's doing rather than the clock's
        let res = get().await.unwrap();
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = client
            .request(reqwest::Method::from_bytes(b"PURGE").unwrap(), url)
            .header("x-purge-action", "expire")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);

        // the asset is stale rather than gone, so this revalidates against the origin and
        // reuses the stored body on the 304
        let res = get().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(headers["x-upstream-status"], "304");
        assert_eq!(
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap(),
            stored_epoch,
            "expiring must keep the stored asset, not replace it"
        );
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    /// The counterpart to the test above. With a serve stale window configured, an expiring
    /// purge must leave it open: the asset goes out of cache immediately and refreshes behind
    /// the request instead of making the reader wait on the origin.
    #[tokio::test]
    async fn test_purge_expire_keeps_serving_stale_while_it_revalidates() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_purge_expire_stale/revalidate_now";
        let client = reqwest::Client::new();
        // The window has to come from the response, and serving stale needs the cache lock.
        let get = || {
            client
                .get(url)
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=600",
                )
                .header("x-lock", "true")
                .send()
        };

        let res = get().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        let stored_epoch = res.headers()["x-epoch"]
            .to_str()
            .unwrap()
            .parse::<f64>()
            .unwrap();
        assert_eq!(res.text().await.unwrap(), "hello world");

        // still fresh, so anything stale later is the purge's doing rather than the clock's
        let res = get().await.unwrap();
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = client
            .request(reqwest::Method::from_bytes(b"PURGE").unwrap(), url)
            .header("x-purge-action", "expire")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);

        // served out of cache without waiting on the origin, where the test above blocks on a
        // revalidation because it has no window to serve from
        let res = get().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "stale-updating");
        assert_eq!(
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap(),
            stored_epoch,
            "the stale body has to be the one that was stored"
        );
        assert_eq!(res.text().await.unwrap(), "hello world");

        // and the revalidation running behind it clears the expiry
        sleep(Duration::from_millis(100)).await;
        let res = get().await.unwrap();
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_purge_expire_reports_a_missing_asset_as_not_found() {
        init();
        let res = reqwest::Client::new()
            .request(
                reqwest::Method::from_bytes(b"PURGE").unwrap(),
                "http://127.0.0.1:6148/unique/test_purge_expire_absent/never_cached",
            )
            .header("x-purge-action", "expire")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn test_hit_filter_force_expire_serve_stale_serves_the_stale_body() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_force_expire_serve_stale/revalidate_now";
        let client = reqwest::Client::new();
        // The window has to come from the response, and serving stale needs the cache lock.
        let get = || {
            client
                .get(url)
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=600",
                )
                .header("x-lock", "true")
        };

        let res = get().send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        let stored_epoch = res.headers()["x-epoch"]
            .to_str()
            .unwrap()
            .parse::<f64>()
            .unwrap();
        assert_eq!(res.text().await.unwrap(), "hello world");

        // still fresh, so the staleness below is the forced expiry rather than the clock
        let res = get().send().await.unwrap();
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = get()
            .header("x-force-expire-serve-stale", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "stale-updating");
        assert_eq!(
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap(),
            stored_epoch,
            "the stale body has to be the one that was stored"
        );
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    /// The window runs from the expiry, not from the asset's original deadline. This asset
    /// has 60s of freshness left and a 2s window, so an expiry 5s back leaves nothing to
    /// serve even though it is still nowhere near its own deadline.
    #[tokio::test]
    async fn test_hit_filter_force_expire_serve_stale_measures_the_window_from_the_expiry() {
        init();
        let url =
            "http://127.0.0.1:6148/unique/test_force_expire_serve_stale_window/revalidate_now";
        let client = reqwest::Client::new();
        let get = || {
            client
                .get(url)
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=2",
                )
                .header("x-lock", "true")
        };

        let res = get().send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = get().send().await.unwrap();
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = get()
            .header("x-force-expire-serve-stale", "1")
            .header("x-expired-secs-ago", "5")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(
            res.headers()["x-cache-status"],
            "revalidated",
            "the window closed 3s before this request, so it has to wait on the origin"
        );
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_hit_filter_force_expire_waits_on_the_revalidation() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_force_expire_blocking/revalidate_now";
        let client = reqwest::Client::new();
        // Same generous window as the serve-stale case, so the only difference is the variant.
        let get = || {
            client
                .get(url)
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=600",
                )
                .header("x-lock", "true")
        };

        let res = get().send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = get().send().await.unwrap();
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // closing the windows leaves nothing to serve, so this one has to wait for the origin
        let res = get().header("x-force-expire", "1").send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "revalidated");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_miss_convert() {
        init();

        // test if-* header is stripped
        let client = reqwest::Client::new();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_miss_convert/no_if_headers")
            .header("if-modified-since", "Wed, 19 Jan 2022 18:39:12 GMT")
            .send()
            .await
            .unwrap();
        // 200 because last-modified not returned from upstream
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "no if headers detected\n");

        // test range header is stripped
        let client = reqwest::Client::new();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_miss_convert2/no_if_headers")
            .header("Range", "bytes=0-1")
            .send()
            .await
            .unwrap();
        // we have not implemented downstream range yet, it should be 206 once we have it
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "no if headers detected\n");
    }

    #[tokio::test]
    async fn test_cache_http10() {
        // allow caching http1.0 from origin, but proxy as h1.1 downstream
        init();
        let url = "http://127.0.0.1:6148/unique/test_cache_http10/now";

        let res = reqwest::Client::new()
            .get(url)
            .header("x-upstream-fake-http10", "1") // fake http1.0 in upstream response filter
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.version(), Version::HTTP_11);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["transfer-encoding"], "chunked");
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::Client::new()
            .get(url)
            .header("x-upstream-fake-http10", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.version(), Version::HTTP_11);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["transfer-encoding"], "chunked");
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::Client::new()
            .get(url)
            .header("x-upstream-fake-http10", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.version(), Version::HTTP_11);
        let headers = res.headers();
        let cache_expired_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["transfer-encoding"], "chunked");
        assert_eq!(headers["x-cache-status"], "expired");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert!(cache_expired_epoch > cache_hit_epoch);
    }

    #[tokio::test]
    async fn test_cache_downstream_compression() {
        init();

        // disable reqwest gzip support to check compression headers and body
        // otherwise reqwest will decompress and strip the headers
        let client = reqwest::ClientBuilder::new().gzip(false).build().unwrap();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_downstream_compression/no_compression")
            .header("x-downstream-compression", "1")
            .header("accept-encoding", "gzip")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["Content-Encoding"], "gzip");
        assert_eq!(headers["x-cache-status"], "miss");
        let body = res.bytes().await.unwrap();
        assert!(body.len() < 32);

        // should also apply on hit
        let client = reqwest::ClientBuilder::new().gzip(false).build().unwrap();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_downstream_compression/no_compression")
            .header("x-downstream-compression", "1")
            .header("accept-encoding", "gzip")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["Content-Encoding"], "gzip");
        assert_eq!(headers["x-cache-status"], "hit");
        let body = res.bytes().await.unwrap();
        assert!(body.len() < 32);
    }

    #[tokio::test]
    async fn test_cache_downstream_decompression() {
        init();

        // disable reqwest gzip support to check compression headers and body
        // otherwise reqwest will decompress and strip the headers
        let client = reqwest::ClientBuilder::new().gzip(false).build().unwrap();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_downstream_decompression/gzip/index.html")
            .header("x-downstream-decompression", "1")
            .header("x-upstream-accept-encoding", "gzip")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        // upstream should have received gzip, should decompress for downstream
        assert_eq!(headers["received-accept-encoding"], "gzip");
        assert!(headers.get("Content-Encoding").is_none());
        assert_eq!(headers["x-cache-status"], "miss");
        let body = res.bytes().await.unwrap();
        assert_eq!(body, "Hello World!\n");

        // should also apply on hit
        let client = reqwest::ClientBuilder::new().gzip(false).build().unwrap();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_downstream_decompression/gzip/index.html")
            .header("x-downstream-decompression", "1")
            .header("x-upstream-accept-encoding", "gzip")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert!(headers.get("Content-Encoding").is_none());
        assert_eq!(headers["x-cache-status"], "hit");
        let body = res.bytes().await.unwrap();
        assert_eq!(body, "Hello World!\n");

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        // should also apply on revalidated
        let client = reqwest::ClientBuilder::new().gzip(false).build().unwrap();
        let res = client
            .get("http://127.0.0.1:6148/unique/test_cache_downstream_decompression/gzip/index.html")
            .header("x-downstream-decompression", "1")
            .header("x-upstream-accept-encoding", "gzip")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert!(headers.get("Content-Encoding").is_none());
        assert_eq!(headers["x-cache-status"], "revalidated");
        let body = res.bytes().await.unwrap();
        assert_eq!(body, "Hello World!\n");
    }

    #[tokio::test]
    async fn test_network_error_mid_response() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_network_error_mid_response.txt";

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep
            .header("x-set-body-sleep", "0.1") // pause the body a bit before abort
            .header("x-abort-body", "true") // this will tell origin to kill the conn right away
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        // the connection dies
        assert!(res.text().await.is_err());

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep
            .header("x-set-body-sleep", "0.1") // pause the body a bit before abort
            .header("x-abort-body", "true") // this will tell origin to kill the conn right away
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        // the connection dies
        assert!(res.text().await.is_err());
    }

    #[tokio::test]
    async fn test_cache_upstream_revalidation() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_upstream_revalidation/revalidate_now";

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(headers.get("x-upstream-status").is_none());
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_expired_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(headers["x-upstream-status"], "304");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // still the old object
        assert_eq!(cache_expired_epoch, cache_hit_epoch);
    }

    #[tokio::test]
    async fn test_cache_upstream_revalidation_appends_headers() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_cache_upstream_revalidation_appends_headers/cache_control";

        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert_eq!(headers["cache-control"], "public, max-age=1");
        assert_eq!(headers.get_all("cache-control").into_iter().count(), 1);
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(headers.get("x-upstream-status").is_none());
        assert_eq!(headers.get_all("cache-control").into_iter().count(), 1);
        assert_eq!(res.text().await.unwrap(), "hello world");

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=1")
            .header("set-cache-control", "stale-while-revalidate=86400")
            .header("set-revalidated", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(headers["x-upstream-status"], "304");
        let mut cc = headers.get_all("cache-control").into_iter();
        assert_eq!(cc.next().unwrap(), "public, max-age=1");
        assert_eq!(cc.next().unwrap(), "stale-while-revalidate=86400");
        assert!(cc.next().is_none());
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_force_miss() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_froce_miss/revalidate_now";

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(headers.get("x-upstream-status").is_none());
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        let res = reqwest::Client::new()
            .get(url)
            .header("x-force-miss", "1")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_force_miss_stale() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_froce_miss_stale/revalidate_now";

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(headers.get("x-upstream-status").is_none());
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        // stale, but can be forced miss
        let res = reqwest::Client::new()
            .get(url)
            .header("x-force-miss", "1")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        let cache_miss_epoch2 = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert!(cache_miss_epoch != cache_miss_epoch2);
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_force_fresh() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_force_fresh/revalidate_now";

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(headers.get("x-upstream-status").is_none());
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        // stale, but can be forced fresh
        let res = reqwest::Client::new()
            .get(url)
            .header("x-force-fresh", "1")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(!headers.contains_key("x-upstream-status"));
        let cache_miss_epoch2 = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(cache_miss_epoch, cache_miss_epoch2);
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_downstream_revalidation_etag() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_downstream_revalidation_etag/revalidate_now";
        let client = reqwest::Client::new();

        // MISS + 304
        let res = client
            .get(url)
            .header("If-None-Match", "\"abcd\", \"foobar\"") // "abcd" is the fixed etag of this
            // endpoint
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), ""); // 304 no body

        // HIT + 304
        let res = client
            .get(url)
            .header("If-None-Match", "\"abcd\", \"foobar\"")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), ""); // 304 no body

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        // HIT + 200 (condition passed)
        let res = client
            .get(url)
            .header("If-None-Match", "\"foobar\"")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        // revalidated + 304
        let res = client
            .get(url)
            .header("If-None-Match", "\"abcd\", \"foobar\"")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        let cache_expired_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(res.text().await.unwrap(), ""); // 304 no body

        // still the old object
        assert_eq!(cache_expired_epoch, cache_hit_epoch);
    }

    #[tokio::test]
    async fn test_cache_downstream_revalidation_last_modified() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_downstream_revalidation_last_modified/revalidate_now";
        let client = reqwest::Client::new();

        // MISS + 304
        let res = client
            .get(url)
            .header("If-Modified-Since", "Tue, 03 May 2022 01:04:39 GMT") // fixed last-modified of
            // the endpoint
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), ""); // 304 no body

        // HIT + 304
        let res = client
            .get(url)
            .header("If-Modified-Since", "Tue, 03 May 2022 01:11:39 GMT")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), ""); // 304 no body

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        // HIT + 200 (condition passed)
        let res = client
            .get(url)
            .header("If-Modified-Since", "Tue, 03 May 2022 00:11:39 GMT")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        // revalidated + 304
        let res = client
            .get(url)
            .header("If-Modified-Since", "Tue, 03 May 2022 01:11:39 GMT")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        let cache_expired_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(res.text().await.unwrap(), ""); // 304 no body

        // still the old object
        assert_eq!(cache_expired_epoch, cache_hit_epoch);
    }

    #[tokio::test]
    async fn test_cache_downstream_head() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_downstream_head/revalidate_now";
        let client = reqwest::Client::new();

        // MISS + HEAD
        let res = client.head(url).send().await.unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), ""); // HEAD no body

        // HIT + HEAD
        let res = client.head(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), ""); // HEAD no body

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        // revalidated + HEAD
        let res = client.head(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_expired_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(res.text().await.unwrap(), ""); // HEAD no body

        // still the old object
        assert_eq!(cache_expired_epoch, cache_hit_epoch);
    }

    #[tokio::test]
    async fn test_purge_reject() {
        init();

        let res = reqwest::Client::builder()
            .build()
            .unwrap()
            .request(
                reqwest::Method::from_bytes(b"PURGE").unwrap(),
                "http://127.0.0.1:6148/",
            )
            .header("x-bypass-cache", "1") // not to cache this one
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::METHOD_NOT_ALLOWED);
        assert_eq!(res.text().await.unwrap(), "");
    }

    #[tokio::test]
    async fn test_cache_websocket_101() {
        // Test the unlikely scenario in which users may want to cache WS
        init();

        // First request - should be a miss
        let mut stream = TcpStream::connect("127.0.0.1:6148").await.unwrap();
        let req = concat!(
            "GET /unique/test_cache_websocket_101/upgrade HTTP/1.1\r\n",
            "Host: 127.0.0.1\r\n",
            "Upgrade: websocket\r\n",
            "Connection: Upgrade\r\n",
            "X-Cache-Websocket: 1\r\n",
            "\r\n"
        );
        stream.write_all(req.as_bytes()).await.unwrap();
        stream.flush().await.unwrap();

        let expected_payload = b"hello\n";
        let fut = read_response(&mut stream, expected_payload.len());
        let (resp_header, resp_body) = timeout(Duration::from_secs(5), fut).await.unwrap();

        assert_eq!(resp_header.status, 101);
        assert_eq!(resp_header.headers["Upgrade"], "websocket");
        assert_eq!(resp_header.headers["x-cache-status"], "miss");
        assert_eq!(resp_body, expected_payload);

        // Second request - should be a cache hit
        let mut stream = TcpStream::connect("127.0.0.1:6148").await.unwrap();
        let req = concat!(
            "GET /unique/test_cache_websocket_101/upgrade HTTP/1.1\r\n",
            "Host: 127.0.0.1\r\n",
            "Upgrade: websocket\r\n",
            "Connection: Upgrade\r\n",
            "X-Cache-Websocket: 1\r\n",
            "\r\n"
        );
        stream.write_all(req.as_bytes()).await.unwrap();
        stream.flush().await.unwrap();

        let fut = read_response(&mut stream, expected_payload.len());
        let (resp_header, resp_body) = timeout(Duration::from_secs(5), fut).await.unwrap();

        assert_eq!(resp_header.status, 101);
        assert_eq!(resp_header.headers["Upgrade"], "websocket");
        assert_eq!(resp_header.headers["x-cache-status"], "hit");
        assert_eq!(resp_body, expected_payload);
    }

    #[tokio::test]
    async fn test_1xx_caching() {
        // 1xx shouldn't interfere with HTTP caching

        // set up a one-off mock server
        // (warp / hyper don't have custom 1xx sending capabilities yet)
        // One-shot mock server that sends a 103 Early Hints then a final 200.
        // Binds to port 0 (OS-assigned) and returns the actual port via a
        // oneshot channel once the listener is ready.
        fn spawn_mock_1xx_server(cc_header: &'static str) -> tokio::sync::oneshot::Receiver<u16> {
            let (tx, rx) = tokio::sync::oneshot::channel();
            tokio::spawn(async move {
                use tokio::io::AsyncWriteExt;

                let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
                let port = listener.local_addr().unwrap().port();
                let _ = tx.send(port); // signal: port is bound
                if let Ok((mut stream, _addr)) = listener.accept().await {
                    stream.write_all(b"HTTP/1.1 103 Early Hints\r\nLink: <https://foo.bar>; rel=preconnect\r\n\r\n").await.unwrap();
                    sleep(Duration::from_millis(100)).await;
                    stream.write_all(format!("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nCache-Control: {}\r\n\r\nhello", cc_header).as_bytes()).await.unwrap();
                    sleep(Duration::from_millis(100)).await;
                }
            });
            rx
        }

        init();

        let url = "http://127.0.0.1:6148/unique/test_1xx_caching";

        let port = spawn_mock_1xx_server("max-age=5").await.unwrap();

        let client = reqwest::Client::new();
        let res = client
            .get(url)
            .header("x-port", port.to_string())
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello");

        // Second request to the same URL should be a cache hit (no server needed)
        let res = client
            .get(url)
            .header("x-port", port.to_string())
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello");

        // 1xx shouldn't interfere with bypass
        let url = "http://127.0.0.1:6148/unique/test_1xx_bypass";

        let port = spawn_mock_1xx_server("private, no-store").await.unwrap();

        let res = client
            .get(url)
            .header("x-port", port.to_string())
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello");

        // restart the one-off server - still uncacheable
        let port = spawn_mock_1xx_server("private, no-store").await.unwrap();

        let res = client
            .get(url)
            .header("x-port", port.to_string())
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello");
    }

    #[tokio::test]
    async fn test_bypassed_became_cacheable() {
        init();

        let url = "http://127.0.0.1:6148/unique/test_bypassed/cache_control";

        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "private, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cc = headers.get("Cache-Control").unwrap();
        assert_eq!(cc, "private, max-age=0");
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // request should bypass cache, but became cacheable (cache fill)
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // HIT
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_bypassed_304() {
        init();

        let url = "http://127.0.0.1:6148/unique/test_bypassed_304/cache_control";

        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "private, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cc = headers.get("Cache-Control").unwrap();
        assert_eq!(cc, "private, max-age=0");
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // cacheable without private cache-control
        // note this will be a 304 and not a 200, we will cache on _next_ request
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .header("set-revalidated", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "deferred");

        // should be cache fill
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // HIT
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_bypassed_uncacheable_304() {
        init();

        let url = "http://127.0.0.1:6148/unique/test_bypassed_private_304/cache_control";

        // cache fill
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cc = headers.get("Cache-Control").unwrap();
        assert_eq!(cc, "public, max-age=0");
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // cache stale
        // upstream returns 304, but response became uncacheable
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "private")
            .header("set-revalidated", "1")
            .send()
            .await
            .unwrap();
        // should see the response body because we didn't send conditional headers
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "revalidated");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // we bypass cache for this next request
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .header("set-revalidated", "1") // non-200 status to get bypass phase
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_MODIFIED);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "deferred");
    }

    #[tokio::test]
    async fn test_bypassed_head() {
        init();

        let url = "http://127.0.0.1:6148/unique/test_bypassed_head/cache_control";

        // uncacheable, should bypass
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "private, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // we bypass cache for this next request, becomes cacheable
        let res = reqwest::Client::new()
            .head(url)
            .header("set-cache-control", "public, max-age=10")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        // should not cache the response
        assert_eq!(headers["x-cache-status"], "deferred");

        // MISS
        let res = reqwest::Client::new()
            .get(url)
            .header("set-cache-control", "public, max-age=10")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_eviction() {
        init();
        let url = "http://127.0.0.1:6148/file_maker/test_eviction".to_owned();

        // admit asset 1
        let res = reqwest::Client::new()
            .get(url.clone() + "1")
            .header("x-set-size", "3000")
            .header("x-eviction", "1") // tell test proxy to use eviction manager
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap().len(), 3000);

        // admit asset 2
        let res = reqwest::Client::new()
            .get(url.clone() + "2")
            .header("x-set-size", "3000")
            .header("x-eviction", "1") // tell test proxy to use eviction manager
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap().len(), 3000);

        // touch asset 2
        let res = reqwest::Client::new()
            .get(url.clone() + "2")
            .header("x-set-size", "3000")
            .header("x-eviction", "1") // tell test proxy to use eviction manager
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap().len(), 3000);

        // touch asset 1
        let res = reqwest::Client::new()
            .get(url.clone() + "1")
            .header("x-set-size", "3000")
            .header("x-eviction", "1") // tell test proxy to use eviction manager
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap().len(), 3000);

        // admit asset 3
        let res = reqwest::Client::new()
            .get(url.clone() + "3")
            .header("x-set-size", "6000")
            .header("x-eviction", "1") // tell test proxy to use eviction manager
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap().len(), 6000);

        // check asset 2, it should be evicted already because admitting asset 3 made it full
        let res = reqwest::Client::new()
            .get(url.clone() + "2")
            .header("x-set-size", "3000")
            .header("x-eviction", "1") // tell test proxy to use eviction manager
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss"); // evicted
        assert_eq!(res.text().await.unwrap().len(), 3000);
    }

    #[tokio::test]
    async fn test_cache_lock_miss_hit() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_miss_hit.txt";

        // no lock, parallel fetches to a slow origin are all misses
        tokio::spawn(async move {
            let res = reqwest::Client::new().get(url).send().await.unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        tokio::spawn(async move {
            let res = reqwest::Client::new().get(url).send().await.unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        tokio::spawn(async move {
            let res = reqwest::Client::new().get(url).send().await.unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        })
        .await
        .unwrap(); // wait for at least one of them to finish

        let res = reqwest::Client::new().get(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // try with lock
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_miss_hit2.txt";
        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;
        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "hit");
            let lock_time_ms: u32 = headers["x-cache-lock-time-ms"]
                .to_str()
                .unwrap()
                .parse()
                .unwrap();
            assert!(lock_time_ms > 900 && lock_time_ms < 1000);
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        let task3 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "hit");
            let lock_time_ms: u32 = headers["x-cache-lock-time-ms"]
                .to_str()
                .unwrap()
                .parse()
                .unwrap();
            assert!(lock_time_ms > 900 && lock_time_ms < 1000);
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        task1.await.unwrap();
        task2.await.unwrap();
        task3.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_lock_expired() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_expired.txt";

        // cache one
        let res = reqwest::Client::new()
            .get(url)
            .header("x-no-stale-revalidate", "true")
            .header(
                "x-set-cache-control",
                "public, max-age=1, stale-while-revalidate=0",
            )
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
        // let it stale
        sleep(Duration::from_secs(1)).await;

        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-no-stale-revalidate", "true")
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=0",
                )
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "expired");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;
        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-no-stale-revalidate", "true")
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=0",
                )
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "hit");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        let task3 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-no-stale-revalidate", "true")
                .header(
                    "x-set-cache-control",
                    "public, max-age=60, stale-while-revalidate=0",
                )
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "hit");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        task1.await.unwrap();
        task2.await.unwrap();
        task3.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_lock_network_error() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_network_error.txt";

        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "0.3") // sometimes we hit the retry logic which is x3 slow
                .header("x-abort", "true") // this will tell origin to kill the conn right away
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), 502); // error happened
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;

        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            let status = headers["x-cache-status"].to_owned();
            assert_eq!(res.text().await.unwrap(), "hello world");
            status
        });
        let task3 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            let status = headers["x-cache-status"].to_owned();
            assert_eq!(res.text().await.unwrap(), "hello world");
            status
        });

        task1.await.unwrap();
        let status2 = task2.await.unwrap();
        let status3 = task3.await.unwrap();

        let mut count_miss = 0;
        if status2 == "miss" {
            count_miss += 1;
        }
        if status3 == "miss" {
            count_miss += 1;
        }
        assert_eq!(count_miss, 1);
    }

    #[tokio::test]
    async fn test_cache_lock_uncacheable() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_uncacheable.txt";

        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-no-store", "true") // tell origin to return CC: no-store
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), 200);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "no-cache");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;

        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "no-cache");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        let task3 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "no-cache");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        task1.await.unwrap();
        task2.await.unwrap();
        task3.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_lock_timeout() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_timeout.txt";

        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "3") // we have a 2 second cache lock timeout
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), 200);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;

        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "0.1") // tell origin to return faster
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            // cache lock timeout, try to replace lock
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        // send the 3rd request after the 2 second cache lock timeout where the
        // first request still holds the lock (3s delay in origin)
        sleep(Duration::from_millis(2200)).await;
        let task3 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "0.1")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            // this is now a hit because the second task cached from origin
            // successfully
            // and will fetch from origin successfully
            assert_eq!(headers["x-cache-status"], "hit");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        task1.await.unwrap();
        task2.await.unwrap();
        task3.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_lock_wait_timeout() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_wait_timeout.txt";

        let mut handles = vec![];
        const N_REQUESTS: u64 = 8;
        for _ in 0..N_REQUESTS {
            handles.push(tokio::spawn(async move {
                // Each task will attempt to wait for the origin's 1s sleep upon acquiring the
                // cache lock, before the origin disconnects.
                let res = reqwest::Client::new()
                    .get(url)
                    .header("x-lock", "true")
                    .header("x-set-sleep", "1") // we have a 2 second cache lock timeout
                    .header("x-abort", "1")
                    .send()
                    .await
                    .unwrap();
                assert_eq!(res.status(), 502);
                let headers = res.headers();
                headers
                    .get("x-cache-lock-time-ms")
                    .and_then(|ms| ms.to_str().ok().and_then(|s| s.parse::<u64>().ok()))
            }));
        }
        let mut waited_count = 0;
        for handle in handles {
            let lock_time_ms = handle.await.unwrap();
            if let Some(lock_time_ms) = lock_time_ms {
                // should not have waited more than 2s for each response
                waited_count += 1;
                assert!(lock_time_ms <= 2200);
            }
        }
        assert!(waited_count > 0, "at least one reader waited");
        // This whole process /should/ have taken no longer than 4s, as each reader has an
        // independently enforced 2s timeout
    }

    #[tokio::test]
    async fn test_cache_lock_retry_respects_force_fresh() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_retry_respects_force_fresh.txt";
        let cache_control = "public, max-age=0, stale-while-revalidate=0";

        let writer = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "0.2")
                .header("x-set-cache-control", cache_control)
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        sleep(Duration::from_millis(50)).await;

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-set-sleep", "0.2")
            .header("x-set-cache-control", cache_control)
            .header("x-force-fresh", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert!(headers.get("x-upstream-status").is_none());
        assert!(headers.get("x-cache-lock-time-ms").is_some());
        assert_eq!(res.text().await.unwrap(), "hello world");

        writer.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_lock_retry_respects_force_miss() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_lock_retry_respects_force_miss.txt";
        let cache_control = "public, max-age=60";

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-set-sleep", "0")
            .header("x-set-cache-control", cache_control)
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let writer = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "0.2")
                .header("x-set-cache-control", cache_control)
                .header("x-force-miss", "1")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(headers["x-upstream-status"], "200");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        sleep(Duration::from_millis(50)).await;

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-set-sleep", "0.2")
            .header("x-set-cache-control", cache_control)
            .header("x-force-miss", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["x-upstream-status"], "200");
        assert!(headers.get("x-cache-lock-time-ms").is_some());
        assert_eq!(res.text().await.unwrap(), "hello world");

        writer.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_serve_stale_network_error() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_serve_stale_network_error.txt";

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep we just reuse this endpoint
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep we just reuse this endpoint
            .header("x-abort", "true") // this will tell origin to kill the conn right away
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "stale");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_serve_stale_network_error_mid_response() {
        init();
        let url =
            "http://127.0.0.1:6148/sleep/test_cache_serve_stale_network_error_mid_response.txt";

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep we just reuse this endpoint
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep we just reuse this endpoint
            .header("x-set-body-sleep", "0.1") // pause the body a bit before abort
            .header("x-abort-body", "true") // this will tell origin to kill the conn right away
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "expired");
        // the connection dies
        assert!(res.text().await.is_err());
    }

    #[tokio::test]
    async fn test_cache_serve_stale_on_500() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_cache_serve_stale_on_500.txt";

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep we just reuse this endpoint
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0") // no need to sleep we just reuse this endpoint
            .header("x-error-header", "true") // this will tell origin to return 500
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "stale");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_stale_while_revalidate_many_readers() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_stale_while_revalidate_many_readers.txt";

        // cache one
        let res = reqwest::Client::new().get(url).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
        // let it stale
        sleep(Duration::from_secs(1)).await;

        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "stale-updating");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;
        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "stale-updating");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });
        let task3 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "stale-updating");
            assert_eq!(res.text().await.unwrap(), "hello world");
        });

        task1.await.unwrap();
        task2.await.unwrap();
        task3.await.unwrap();
    }

    #[tokio::test]
    async fn test_stale_while_revalidate_single_request() {
        init();
        let url = "http://127.0.0.1:6148/sleep/test_stale_while_revalidate_single_request.txt";

        // cache one
        let res = reqwest::Client::new()
            .get(url)
            .header("x-set-sleep", "0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
        // let it stale
        sleep(Duration::from_secs(1)).await;

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-set-sleep", "0") // by default /sleep endpoint will sleep 1s
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "stale-updating");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // wait for the background request to finish
        sleep(Duration::from_millis(100)).await;

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit"); // fresh
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_streaming_partial_body() {
        init();
        let url = "http://127.0.0.1:6148/slow_body/test_cache_streaming_partial_body.txt";
        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello world!");
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;

        let task2 = tokio::spawn(async move {
            let start = Instant::now();
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "hit");
            let lock_time_ms: u32 = headers["x-cache-lock-time-ms"]
                .to_str()
                .unwrap()
                .parse()
                .unwrap();
            let body = res.text().await.unwrap();
            let total_ms = start.elapsed().as_millis() as u32;
            // lock should cover only the header, not the full body streaming.
            // if the body were also under lock, lock_time would approach total_ms.
            assert!(
                lock_time_ms < total_ms / 2,
                "lock time {lock_time_ms}ms should be well under total request time {total_ms}ms"
            );
            assert_eq!(body, "hello world!");
        });
        let task3 = tokio::spawn(async move {
            let start = Instant::now();
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "hit");
            let lock_time_ms: u32 = headers["x-cache-lock-time-ms"]
                .to_str()
                .unwrap()
                .parse()
                .unwrap();
            let body = res.text().await.unwrap();
            let total_ms = start.elapsed().as_millis() as u32;
            // lock should cover only the header, not the full body streaming.
            // if the body were also under lock, lock_time would approach total_ms.
            assert!(
                lock_time_ms < total_ms / 2,
                "lock time {lock_time_ms}ms should be well under total request time {total_ms}ms"
            );
            assert_eq!(body, "hello world!");
        });

        task1.await.unwrap();
        task2.await.unwrap();
        task3.await.unwrap();
    }

    #[tokio::test]
    async fn test_cache_streaming_multiple_writers() {
        // multiple streaming writers don't conflict
        init();
        let url = "http://127.0.0.1:6148/slow_body/test_cache_streaming_multiple_writers.txt";
        let task1 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-set-hello", "everyone")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello everyone!");
        });

        let task2 = tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                // don't allow using the other streaming write's result
                .header("x-force-expire", "1")
                .header("x-set-hello", "todo el mundo")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            assert_eq!(res.text().await.unwrap(), "hello todo el mundo!");
        });

        task1.await.unwrap();
        task2.await.unwrap();
    }

    #[tokio::test]
    async fn test_range_request() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_range_request/now";

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        let cache_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "he");

        // full body is cached
        let res = reqwest::get(url).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_miss_epoch, cache_hit_epoch);

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "he");

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=1-0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::RANGE_NOT_SATISFIABLE);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "");

        let res = reqwest::Client::new()
            .head(url)
            .header("Range", "bytes=0-1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "");

        sleep(Duration::from_millis(1100)).await; // ttl is 1

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "expired");
        assert_eq!(res.text().await.unwrap(), "he");
    }

    #[tokio::test]
    async fn test_multipart_range_request() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_multipart_range_request/now";

        // 1st multipart range request - uncached

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-1, 6-8") // he wor
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers().clone();
        let content_type = headers.get("content-type").unwrap().to_str().unwrap();
        // Grab boundary to verify full response
        let boundary = content_type
            .split("boundary=")
            .nth(1)
            .expect("Expected to have a boundary");
        assert_eq!(
            content_type,
            format!("multipart/byteranges; boundary={boundary}")
        );
        assert_eq!(headers["x-cache-status"], "miss");

        let body = res.text().await.unwrap();

        let expected_body = format!(
            "\r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 0-1/11\r\n\
            \r\n\
            he\
            \r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 6-8/11\r\n\
            \r\n\
            wor\
            \r\n--{boundary}--\r\n\
        "
        );
        assert_eq!(body, expected_body);

        // 2nd request, cached

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=2-3, 8-10") // ll rld
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers().clone();
        let content_type = headers.get("content-type").unwrap().to_str().unwrap();
        let boundary = content_type
            .split("boundary=")
            .nth(1)
            .expect("Expected to have a boundary");
        assert_eq!(
            content_type,
            format!("multipart/byteranges; boundary={boundary}")
        );
        assert_eq!(headers["x-cache-status"], "hit");

        let body = res.text().await.unwrap();

        let expected_body = format!(
            "\r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 2-3/11\r\n\
            \r\n\
            ll\
            \r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 8-10/11\r\n\
            \r\n\
            rld\
            \r\n--{boundary}--\r\n\
        "
        );
        assert_eq!(body, expected_body);

        // 3rd request, cached

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=1-2, 3-4, 8-10") // el lo rld
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers().clone();
        let content_type = headers.get("content-type").unwrap().to_str().unwrap();
        let boundary = content_type
            .split("boundary=")
            .nth(1)
            .expect("Expected to have a boundary");
        assert_eq!(
            content_type,
            format!("multipart/byteranges; boundary={boundary}")
        );
        assert_eq!(headers["x-cache-status"], "hit");

        let body = res.text().await.unwrap();

        let expected_body = format!(
            "\r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 1-2/11\r\n\
            \r\n\
            el\
            \r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 3-4/11\r\n\
            \r\n\
            lo\
            \r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 8-10/11\r\n\
            \r\n\
            rld\
            \r\n--{boundary}--\r\n\
        "
        );
        assert_eq!(body, expected_body);

        // 4th request - cached and poorly formed request header

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=2-3, 8-10, 3-5")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers().clone();
        assert_eq!(headers["content-type"], "text/plain");
        assert_eq!(headers["x-cache-status"], "hit");

        let body = res.text().await.unwrap();
        assert_eq!(body, "hello world");

        // 5th request: Single range GET

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-2")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");

        let body = res.text().await.unwrap();
        assert_eq!(body, "hel");

        // 6th request invalid range

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=20-22, 30-40")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::RANGE_NOT_SATISFIABLE);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "");

        // 7th request: Single range HEAD

        let res = reqwest::Client::new()
            .head(url)
            .header("Range", "bytes=3-7")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");

        let body = res.text().await.unwrap();
        assert_eq!(body, "");
    }

    #[tokio::test]
    async fn test_single_then_mutltipart_range_request() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_single_then_multipart_range_request/now";

        // 1st request - single range request

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-4")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");

        let body = res.text().await.unwrap();
        assert_eq!(body, "hello");

        // 2nd request - multipart range request

        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-3, 6-7") // hell wo
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers().clone();
        let content_type = headers.get("content-type").unwrap().to_str().unwrap();
        let boundary = content_type
            .split("boundary=")
            .nth(1)
            .expect("Expected to have a boundary");
        assert_eq!(
            content_type,
            format!("multipart/byteranges; boundary={boundary}")
        );
        assert_eq!(headers["x-cache-status"], "hit");

        let body = res.text().await.unwrap();

        let expected_body = format!(
            "\r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 0-3/11\r\n\
            \r\n\
            hell\
            \r\n--{boundary}\r\n\
            Content-Type: text/plain\r\n\
            Content-Range: bytes 6-7/11\r\n\
            \r\n\
            wo\
            \r\n--{boundary}--\r\n\
        "
        );
        assert_eq!(body, expected_body);

        // 3rd request - Multipart request with one valid range
        let res = reqwest::Client::new()
            .get(url)
            .header("Range", "bytes=0-4, 12-14, 16-18") // hello
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        let content_type = headers.get("content-type").unwrap().to_str().unwrap();
        assert!(!content_type.contains("multipart/byteranges; boundary="));
        assert_eq!(headers["x-cache-status"], "hit");

        assert_eq!(res.text().await.unwrap(), "hello");
    }

    #[tokio::test]
    async fn test_caching_when_downstream_bails() {
        init();
        let url = "http://127.0.0.1:6148/slow_body/test_caching_when_downstream_bails/";

        tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-cache-control", "public, max-age=60")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "miss");
            // exit without res.text().await so that we bail early
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-set-cache-control", "public, max-age=60")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        let lock_time_ms: u32 = headers["x-cache-lock-time-ms"]
            .to_str()
            .unwrap()
            .parse()
            .unwrap();
        // the entire body should need 2 extra seconds, here the test shows that
        // only the header is under cache lock and the body should be streamed
        assert!(lock_time_ms > 900 && lock_time_ms < 1000);
        assert_eq!(res.text().await.unwrap(), "hello world!");
    }

    #[tokio::test]
    async fn test_caching_when_downstream_bails_uncacheable() {
        init();
        let url = "http://127.0.0.1:6148/slow_body/test_caching_when_downstream_bails_uncacheable/";

        tokio::spawn(async move {
            let res = reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-no-store", "1")
                .send()
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::OK);
            let headers = res.headers();
            assert_eq!(headers["x-cache-status"], "no-cache");
            // exit without res.text().await so that we bail early
        });
        // sleep just a little to make sure the req above gets the cache lock
        sleep(Duration::from_millis(50)).await;

        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        // entirely new request made to upstream, since the response was uncacheable
        assert_eq!(headers["x-cache-status"], "no-cache"); // due to cache lock give up
        assert_eq!(res.text().await.unwrap(), "hello world!");
    }

    #[tokio::test]
    async fn test_caching_when_downstream_bails_header() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_caching_when_downstream_bails_header/sleep";

        tokio::spawn(async move {
            // this should always time out
            reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "2")
                .timeout(Duration::from_secs(1))
                .send()
                .await
                .unwrap_err()
        });
        // sleep after cache fill
        sleep(Duration::from_millis(2500)).await;

        // next request should be a cache hit
        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_caching_when_downstream_bails_header_uncacheable() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_caching_when_downstream_bails_header_uncacheable/sleep";

        tokio::spawn(async move {
            // this should always time out
            reqwest::Client::new()
                .get(url)
                .header("x-lock", "true")
                .header("x-set-sleep", "2")
                .header("x-no-store", "1")
                .timeout(Duration::from_secs(1))
                .send()
                .await
                .unwrap_err()
            // note that while the downstream error is ignored,
            // once the response is uncacheable we will still attempt to write
            // downstream and find a broken connection that terminates the request
        });
        // sleep after cache fill
        sleep(Duration::from_millis(2500)).await;

        // next request should be a cache miss, as the previous fill was uncacheable
        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    #[ignore = "flaky in CI due to timing/resource contention"]
    async fn test_caching_when_downstream_stalls() {
        use std::net::ToSocketAddrs;
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        use tokio::net::TcpStream;

        init();
        let url = "http://127.0.0.1:6148/unique/test_caching_when_downstream_stalls/download/";

        // Connection 1: read 10KiB then stall, holding the cache lock while
        // the proxy populates cache from upstream.
        let slow_task = tokio::spawn(async move {
            let addr = "127.0.0.1:6148".to_socket_addrs().unwrap().next().unwrap();
            let mut stream = TcpStream::connect(&addr).await.unwrap();

            let request = concat!(
                "GET /unique/test_caching_when_downstream_stalls/download/ HTTP/1.1\r\n",
                "Host: 127.0.0.1:6148\r\n",
                "x-lock: true\r\n",
                "x-set-cache-control: public, max-age=60\r\n",
                "\r\n",
            );
            stream.write_all(request.as_bytes()).await.unwrap();

            let mut buf = [0; 10 * 1024];
            let mut b = &mut buf[..];
            while !b.is_empty() {
                let n = stream.read(b).await.unwrap();
                b = &mut b[n..]
            }

            // Hold the stalled connection open long enough
            sleep(Duration::from_secs(10)).await;
        });

        // Give connection 1 time to acquire the cache lock
        sleep(Duration::from_secs(1)).await;

        // Connection 2: should get a cache hit once the proxy finishes
        // populating cache from upstream (independent of stall).
        let start = tokio::time::Instant::now();
        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-set-cache-control", "public, max-age=60")
            .timeout(Duration::from_secs(8))
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");

        // If the cache was populated fast enough (before connection 2 arrived),
        // there is no lock contention and x-cache-lock-time-ms is absent.
        // If there was contention, the wait should be short.
        if let Some(lock_ms) = headers.get("x-cache-lock-time-ms") {
            let ms: u64 = lock_ms.to_str().unwrap().parse().unwrap();
            assert!(
                ms < 2000,
                "lock wait {ms}ms should be well under the 2s timeout"
            );
        }

        assert_eq!(
            res.text().await.unwrap(),
            String::from("A").repeat(4 * 1024 * 1024)
        );

        let elapsed = start.elapsed();
        assert!(
            elapsed < Duration::from_secs(5),
            "second request took {elapsed:?}, should be fast"
        );

        // Don't wait for the slow connection
        slow_task.abort();
    }

    // Same as test_caching_when_downstream_stalls but the proxy connects
    // to the origin over H2 (via the x-h2 header).
    //
    #[tokio::test]
    #[ignore = "flaky in CI due to timing/resource contention"]
    async fn test_caching_h2_upstream_when_downstream_stalls() {
        use std::net::ToSocketAddrs;
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        use tokio::net::TcpStream;

        init();
        let url = "http://127.0.0.1:6148/unique/test_caching_h2_upstream_when_downstream_stalls/download/";

        let slow_task = tokio::spawn(async move {
            let addr = "127.0.0.1:6148".to_socket_addrs().unwrap().next().unwrap();
            let mut stream = TcpStream::connect(&addr).await.unwrap();

            let request = concat!(
                "GET /unique/test_caching_h2_upstream_when_downstream_stalls/download/ HTTP/1.1\r\n",
                "Host: 127.0.0.1:6148\r\n",
                "x-h2: true\r\n",
                "x-lock: true\r\n",
                "x-set-cache-control: public, max-age=60\r\n",
                "\r\n",
            );
            stream.write_all(request.as_bytes()).await.unwrap();

            let mut buf = [0; 10 * 1024];
            let mut b = &mut buf[..];
            while !b.is_empty() {
                let n = stream.read(b).await.unwrap();
                b = &mut b[n..]
            }

            sleep(Duration::from_secs(10)).await;
        });

        sleep(Duration::from_secs(1)).await;

        let start = tokio::time::Instant::now();
        let res = reqwest::Client::new()
            .get(url)
            .header("x-h2", "true")
            .header("x-lock", "true")
            .header("x-set-cache-control", "public, max-age=60")
            .timeout(Duration::from_secs(8))
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(
            res.text().await.unwrap(),
            String::from("A").repeat(4 * 1024 * 1024)
        );

        let elapsed = start.elapsed();
        assert!(
            elapsed < Duration::from_secs(5),
            "second request took {elapsed:?}, should be fast (upstream-speed-bound)"
        );

        slow_task.abort();
    }

    async fn send_vary_req_with_headers_with_dups(
        url: &str,
        vary_field: &str,
        headers: Vec<(&str, &str)>,
        dup_headers: Vec<(&str, &str)>,
    ) -> reqwest::Response {
        let req_headers = headers
            .iter()
            .map(|(name, value)| {
                (
                    HeaderName::from_str(name).unwrap(),
                    HeaderValue::from_str(value).unwrap(),
                )
            })
            .collect();
        let mut req_builder = reqwest::Client::new()
            .get(url)
            .headers(req_headers)
            .header("set-vary", vary_field);

        // Apply any duplicate headers
        for (key, value) in dup_headers {
            req_builder = req_builder.header(key, value);
        }

        req_builder.send().await.unwrap()
    }

    async fn send_vary_req_with_headers(
        url: &str,
        vary_field: &str,
        headers: Vec<(&str, &str)>,
    ) -> reqwest::Response {
        send_vary_req_with_headers_with_dups(url, vary_field, headers, vec![]).await
    }

    async fn send_vary_req(url: &str, vary_field: &str, value: &str) -> reqwest::Response {
        send_vary_req_with_headers(url, vary_field, vec![(vary_field, value)]).await
    }

    #[tokio::test]
    async fn test_vary_caching() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_vary_caching/vary";
        let vary_field = "Accept";

        let res = send_vary_req(url, vary_field, "image/png").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_a_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_vary_req(url, vary_field, "image/png").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_a_miss_epoch, cache_hit_epoch);

        let res = send_vary_req(url, vary_field, "image/jpeg").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_b_miss_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_vary_req(url, vary_field, "image/jpeg").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let cache_hit_epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        assert_eq!(cache_b_miss_epoch, cache_hit_epoch);
        assert!(cache_a_miss_epoch != cache_b_miss_epoch);
    }

    #[tokio::test]
    async fn test_vary_caching_ignored_vary_header() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_vary_caching_ignored_vary_header/vary";
        let vary_field = "Some-Ignored-Vary-Header";

        // Asset into cache (png)
        let res = send_vary_req(url, vary_field, "image/png").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let epoch = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // HIT on png
        let res = send_vary_req(url, vary_field, "image/png").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(
            epoch,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Vary header ignored -> get png, not jpeg
        let res = send_vary_req(url, vary_field, "image/jpeg").await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(
            epoch,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );
        assert_eq!(headers["x-cache-status"], "hit");
    }

    #[tokio::test]
    async fn test_vary_some_ignored() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_vary_some_ignored/vary";
        let vary_header = "Accept, SomeIgnoredVaryHeader";

        // Make a request where we vary on some headers, and provide values for those.
        let res = send_vary_req_with_headers(
            url,
            vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "image/webp"),
                ("Accept", "image/webp"),
            ],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        let epoch1 = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Identical request should yield a HIT.
        let res = send_vary_req_with_headers(
            url,
            vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "image/webp"),
                ("Accept", "image/webp"),
            ],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(
            epoch1,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Hit when changing a header we don't vary on.
        let res = send_vary_req_with_headers(
            url,
            vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "definitely-not-webp"),
                ("Accept", "image/webp"),
            ],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(
            epoch1,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Get a secondary variant by changing Accept.
        let res = send_vary_req_with_headers(
            url,
            vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "definitely-not-webp"),
                ("Accept", "image/jpeg"),
            ],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        let epoch2 = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_ne!(epoch1, epoch2);
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Cache hit on secondary variant.
        let res = send_vary_req_with_headers(
            url,
            vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "definitely-not-webp"),
                ("Accept", "image/jpeg"),
            ],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(
            epoch2,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );

        // Cache hit on primary variant.
        let res = send_vary_req_with_headers(
            url,
            vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "definitely-not-webp"),
                ("Accept", "image/webp"),
            ],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(
            epoch1,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );
    }

    #[tokio::test]
    async fn test_vary_dup_header_some_ignored() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_vary_dup_header_some_ignored/vary";
        let first_vary_header = "SomeIgnoredVaryHeader";
        let dup_vary_header = "Accept";

        // Make a request where we vary on some headers, and provide values for those.
        let res = send_vary_req_with_headers_with_dups(
            url,
            first_vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "image/webp"),
                ("Accept", "image/webp"),
            ],
            vec![("set-vary", dup_vary_header)],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        let epoch1 = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Identical request should yield a HIT.
        let res = send_vary_req_with_headers_with_dups(
            url,
            first_vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "image/webp"),
                ("Accept", "image/webp"),
            ],
            vec![("set-vary", dup_vary_header)],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(
            epoch1,
            headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap()
        );
        assert_eq!(res.text().await.unwrap(), "hello world");

        // Get a secondary variant by changing Accept.
        let res = send_vary_req_with_headers_with_dups(
            url,
            first_vary_header,
            vec![
                ("SomeIgnoredVaryHeader", "image/webp"),
                ("Accept", "image/jpeg"),
            ],
            vec![("set-vary", dup_vary_header)],
        )
        .await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        let epoch2 = headers["x-epoch"].to_str().unwrap().parse::<f64>().unwrap();
        assert_ne!(epoch1, epoch2);
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_vary_purge() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_vary_purge/vary";
        let vary_field = "Accept";
        let opt1 = "image/png";
        let opt2 = "image/jpeg";

        send_vary_req(url, vary_field, opt1).await;
        let res = send_vary_req(url, vary_field, opt1).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");

        send_vary_req(url, vary_field, opt2).await;
        let res = send_vary_req(url, vary_field, opt2).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");

        //both variances are cached

        let res = reqwest::Client::builder()
            .build()
            .unwrap()
            .request(reqwest::Method::from_bytes(b"PURGE").unwrap(), url)
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.text().await.unwrap(), "");

        //both should be miss

        let res = send_vary_req(url, vary_field, opt1).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");

        let res = send_vary_req(url, vary_field, opt2).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
    }

    async fn send_max_file_size_req(
        url: &str,
        max_file_size_bytes: usize,
        range: Option<(usize, usize)>,
    ) -> reqwest::Response {
        let mut req = reqwest::Client::new().get(url).header(
            "x-cache-max-file-size-bytes",
            max_file_size_bytes.to_string(),
        );
        if let Some(r) = range {
            req = req.header("Range", format!("bytes={}-{}", r.0, r.1));
        }
        req.send().await.unwrap()
    }

    #[tokio::test]
    async fn test_cache_max_file_size() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_cache_max_file_size_100/now";

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["content-length"], "11");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let url = "http://127.0.0.1:6148/unique/test_cache_max_file_size_1/now";
        let res = send_max_file_size_req(url, 1, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 1, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // became cacheable
        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_max_file_size_chunked() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_cache_max_file_size_chunked_100/test3";

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["transfer-encoding"], "chunked");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let url = "http://127.0.0.1:6148/unique/test_cache_max_file_size_chunked_1/test3";
        let res = send_max_file_size_req(url, 1, None).await;
        // TODO: this can currently break with 500 when body arrives alongside header
        assert!(matches!(
            res.status(),
            StatusCode::INTERNAL_SERVER_ERROR | StatusCode::OK
        ));
        let headers = res.headers();
        assert!(headers
            .get("x-cache-status")
            .is_none_or(|s| s == "no-cache"));

        let res = send_max_file_size_req(url, 1, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // became cacheable
        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        // will get marked on the next request
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 100, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    /// A predictor bypass that had nothing to do with size must not be treated as one.
    ///
    /// `/test3` is chunked, so the cache cannot confirm the body size from the response
    /// header. That used to be enough to report `PredictedResponseTooLarge` and burn a
    /// bypass on every recovery, no matter why the key was bypassed in the first place.
    #[tokio::test]
    async fn test_cache_max_file_size_chunked_non_size_bypass() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_non_size_bypass_chunked/test3";

        // origin says private, so the key is remembered as uncacheable for OriginNotCache
        let res = reqwest::Client::new()
            .get(url)
            .header("x-cache-max-file-size-bytes", "1000")
            .header("x-set-cache-control", "private, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // same key, now cacheable. The bypass was never about size, so this request fills
        // the cache rather than spending itself confirming the body fits.
        let res = send_max_file_size_req(url, 1000, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(headers["transfer-encoding"], "chunked");
        assert_eq!(res.text().await.unwrap(), "hello world");

        let res = send_max_file_size_req(url, 1000, None).await;
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(res.headers()["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_max_file_size_range() {
        init();
        let url = "http://127.0.0.1:6148/unique/test_cache_max_file_size_range_100/now";

        let res = send_max_file_size_req(url, 100, Some((1, 4))).await;
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        let epoch1 = headers["x-epoch"].clone();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "ello");

        let res = send_max_file_size_req(url, 100, Some((1, 4))).await;
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        let epoch2 = headers["x-epoch"].clone();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "ello");
        assert_eq!(epoch1, epoch2);

        // disable downstream ranging on max file size exceeded
        let url = "http://127.0.0.1:6148/unique/test_cache_max_file_size_range_1/now";
        let res = send_max_file_size_req(url, 1, Some((1, 4))).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let epoch1 = headers["x-epoch"].clone();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");

        // predicted uncacheable (note upstream endpoint doesn't support range)
        let res = send_max_file_size_req(url, 1, Some((1, 4))).await;
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        let epoch2 = headers["x-epoch"].clone();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");
        assert!(epoch1 != epoch2);
    }

    #[tokio::test]
    async fn test_cache_h2_premature_end() {
        init();
        let url = "http://127.0.0.1:6148/set_content_length/test_cache_h2_premature_end.txt";
        // try to fill cache
        reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-h2", "true")
            .header("x-set-content-length", "13") // 2 more than "hello world"
            .send()
            .await
            .unwrap();
        // h2 protocol error with content length mismatch

        // did not get saved into cache, next request will be cache miss
        let res = reqwest::Client::new()
            .get(url)
            .header("x-lock", "true")
            .header("x-h2", "true")
            .header("x-set-content-length", "11")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_cache_bypass_downstream_range() {
        init();
        let test_url =
            "http://127.0.0.1:6148/unique/test_cache_bypass_downstream_range/cache_control/";

        let res = reqwest::Client::new()
            .get(test_url)
            .header("Range", "bytes=6-10")
            // We start this request as cacheable, and then this disables it.
            // We would expect the range body filter to run since we have
            // started to cache, and then disabled.
            .header("set-cache-control", "private, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::PARTIAL_CONTENT);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "world");

        // We're starting as uncacheable, so proxy origin to downstream
        // unchanged.
        let res = reqwest::Client::new()
            .get(test_url)
            // We pass this up to the upstream, but it ignores it.
            .header("Range", "bytes=0-4")
            .header("set-cache-control", "private, max-age=0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "no-cache");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[tokio::test]
    async fn test_downstream_head_miss_conn_close_h1() {
        init();

        let test_url =
            "http://127.0.0.1:6148/unique/test_cache_downstream_head_miss_conn_close/sleep/";

        let res = reqwest::Client::new()
            .head(test_url)
            .header("x-set-body-sleep", "1")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "");
        // closed connection does not impact next cache fill

        let res = reqwest::Client::new().get(test_url).send().await.unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    #[cfg(feature = "any_tls")]
    #[tokio::test]
    async fn test_downstream_head_miss_conn_close_h2() {
        init();

        let test_url =
            "https://127.0.0.1:6153/unique/test_cache_downstream_head_miss_conn_close/sleep/";

        let client = reqwest::Client::builder()
            .danger_accept_invalid_certs(true)
            .build()
            .unwrap();

        let res = client
            .head(test_url)
            .header("x-set-body-sleep", "0")
            .send()
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "miss");
        assert_eq!(res.text().await.unwrap(), "");
        // closed connection does not impact next cache fill

        let client = reqwest::Client::builder()
            .danger_accept_invalid_certs(true)
            .build()
            .unwrap();

        let res = client.get(test_url).send().await.unwrap();
        assert_eq!(res.status(), 200);
        let headers = res.headers();
        assert_eq!(headers["x-cache-status"], "hit");
        assert_eq!(res.text().await.unwrap(), "hello world");
    }

    // Ignored until H2 downstream gets the proxy task API
    // (write_response_tasks blocks on flow control today).
    // multi_thread needed for h2 connection driver tasks.
    #[tokio::test(flavor = "multi_thread")]
    #[ignore]
    async fn test_cache_h2_downstream_stalls() {
        init();

        use h2::client;
        use http::Request;
        use tokio::net::TcpStream;
        use tokio::time::{timeout, Duration};

        // Step 1: Connection 1 - Open h2 connection to h2c cache proxy (port 6154) and STALL
        let tcp1 = TcpStream::connect("127.0.0.1:6154").await.unwrap();
        let (mut h2_client1, h2_conn1) = client::handshake(tcp1).await.unwrap();

        tokio::spawn(async move {
            if let Err(e) = h2_conn1.await {
                eprintln!("H2 connection 1 error: {:?}", e);
            }
        });

        // Request the cached resource on connection 1
        let request1 = Request::builder()
            .uri("http://127.0.0.1/unique/test_h2_stall/download/")
            .body(())
            .unwrap();

        let (response1, _) = h2_client1.send_request(request1, true).unwrap();
        let response1 = response1.await.unwrap();
        assert_eq!(response1.status(), 200);
        assert_eq!(response1.headers()["x-cache-status"], "miss");

        let mut body1 = response1.into_body();

        // Read first chunk but don't release flow control to stall connection 1
        let first_chunk = body1.data().await.unwrap().unwrap();
        assert!(!first_chunk.is_empty());

        // Connection 2 - While conn 1 is stalled, try to get the same cached resource
        let tcp2 = TcpStream::connect("127.0.0.1:6154").await.unwrap();
        let (mut h2_client2, h2_conn2) = client::handshake(tcp2).await.unwrap();

        tokio::spawn(async move {
            if let Err(e) = h2_conn2.await {
                eprintln!("H2 connection 2 error: {:?}", e);
            }
        });

        let request2 = Request::builder()
            .uri("http://127.0.0.1/unique/test_h2_stall/download/")
            .body(())
            .unwrap();

        let (response2, _) = h2_client2.send_request(request2, true).unwrap();

        // Try to read, proxy should not be blocked
        let response2 = match timeout(Duration::from_secs(5), response2).await {
            Ok(Ok(resp)) => resp,
            Ok(Err(e)) => panic!("Connection 2 failed: {:?}", e),
            Err(_) => panic!("Connection 2 timed out - proxy blocked without proxy task API!"),
        };

        assert_eq!(response2.status(), 200);
        assert_eq!(response2.headers()["x-cache-status"], "hit");

        // Read full response from connection 2
        let mut body2 = response2.into_body();
        let mut received2 = Vec::new();
        while let Some(Ok(chunk)) = timeout(Duration::from_secs(5), body2.data())
            .await
            .expect("should not time out waiting for data")
        {
            let len = chunk.len();
            received2.extend_from_slice(&chunk);
            body2.flow_control().release_capacity(len).unwrap();
        }

        assert_eq!(
            received2.len(),
            4 * 1024 * 1024,
            "Connection 2 should receive full cached response"
        );

        // Clean up: unstall connection 1
        body1
            .flow_control()
            .release_capacity(first_chunk.len())
            .unwrap();
    }

    // Test cache population from H2 upstream origin with H1 downstream.
    #[tokio::test]
    async fn test_cache_upstream_h2_downstream_h1() {
        init();

        let test_url = "http://127.0.0.1:6148/unique/test_h2_upstream/download/";

        // Step 1: Populate cache from H2 origin (cache miss)
        let client = reqwest::Client::new();
        let res = client
            .get(test_url)
            .header("x-h2", "true")
            .header("x-lock", "true")
            .header("x-set-cache-control", "public, max-age=60")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), 200);
        assert_eq!(res.headers()["x-cache-status"], "miss");
        assert_eq!(res.headers()["origin-http2"], "h2c");

        let body = res.bytes().await.unwrap();
        assert_eq!(
            body.len(),
            4 * 1024 * 1024,
            "Should receive full 4MB response"
        );

        // Step 2: Request again and verify cache hit
        let res = client
            .get(test_url)
            .header("x-h2", "true")
            .header("x-set-cache-control", "public, max-age=60")
            .send()
            .await
            .unwrap();

        assert_eq!(res.status(), 200);
        assert_eq!(res.headers()["x-cache-status"], "hit");

        let body = res.bytes().await.unwrap();
        assert_eq!(
            body.len(),
            4 * 1024 * 1024,
            "Should receive full 4MB from cache"
        );
    }
}
